"""The setup screen under *Menu -> Plugins -> MQTT Bridge*.

Built on `ConfigListScreen` and nothing else. `Screens.Setup` needs an entry in
the image's `setup.xml`, which not every image will accept from a third-party
plugin and which some images rearrange between releases; `ConfigListScreen` has
been in every enigma2 flavour for a decade and needs no registration at all.

The status line is the point of the screen as much as the fields are: a box that
is idle because the broker address is empty looks exactly like a box that cannot
reach the broker, unless somebody says which it is.

The blue key opens "Plugin updates" (`updatescreen.py`): the versions the signed index offers,
a check, and an install - the television's half of the self-update, which needs neither
`update_check` nor `update_allowed` because the person holding the remote control is the
consent (ADR-0015 decision 4; SETUP.md, "Installing a release from the receiver").
"""

from Components.ActionMap import ActionMap
from Components.config import config, configfile, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen

from .i18n import _
from .log import get_logger
from .selfupdate import household_doors
from .updatescreen import MQTTBridgeUpdates

LOG = get_logger("setup")


def _wol_arm_label():
    """The Wake-on-LAN setting's label, which says so where it can do nothing.

    Asked every time the labels are, not once at import: it reads the image's
    own probe, and a label that promised a switch the receiver does not have
    would be a setting somebody turns on and then waits for.
    """
    label = _("Switch on the receiver's Wake-on-LAN")
    try:
        from .wol import supported

        if supported():
            return label
    except Exception:
        LOG.debug("the image's Wake-on-LAN could not be asked about")
    return label + " (" + _("Wake-on-LAN is not available on this receiver") + ")"


def setting_labels():
    """Setting name, and the label a household sees. The order is the screen's."""
    return (
        ("enabled", _("Enabled")),
        ("host", _("Broker address")),
        ("port", _("Broker port")),
        ("tls", _("Use TLS")),
        ("ca_file", _("CA certificate file")),
        ("username", _("Broker username")),
        ("password", _("Broker password")),
        ("node_id", _("Node id")),
        ("friendly_name", _("Device name")),
        ("base_topic", _("Base topic")),
        ("ha_discovery_prefix", _("Home Assistant discovery prefix")),
        ("ha_mode", _("Home Assistant mode")),
        ("publish_keys", _("Publish remote key presses")),
        ("screenshot", _("Screenshots")),
        ("screenshot_interval", _("Screenshot interval (seconds)")),
        ("screenshot_delay", _("Screenshot delay after a zap (seconds)")),
        ("osd_toast", _("Show discreet on-screen messages")),
        ("cam_telemetry", _("Publish conditional-access telemetry")),
        ("oscam_telemetry", _("Publish OSCam server telemetry")),
        ("oscam_port", _("OSCam WebIf port")),
        ("oscam_username", _("OSCam WebIf username")),
        ("oscam_password", _("OSCam WebIf password")),
        ("bouquets_for_select", _("Bouquets for the channel list")),
        ("deep_standby_allowed", _("Allow deep standby and reboot")),
        ("wol_arm", _wol_arm_label()),
        ("cec_standby_workaround", _("Close the channel list when the TV asks for standby")),
        ("softcam_restart_allowed", _("Allow restarting the softcam")),
        ("softcam_autoheal", _("Restart the softcam when it stops decoding")),
        ("softcam_autoheal_seconds", _("Wait before an automatic softcam restart (seconds)")),
        ("epg_import_allowed", _("Allow starting an EPG import")),
        ("uninstall_allowed", _("Allow removing the plugin remotely")),
        ("update_check", _("Check daily for plugin updates")),
        ("update_allowed", _("Allow plugin updates over MQTT")),
        ("log_level", _("Log level")),
        ("epg_grid_events", _("EPG grid events per channel")),
        ("recording_delete_allowed", _("Allow deleting recordings (into the trash)")),
        ("menu_allowed", _("Allow the Home Assistant menu")),
        ("menu_hotkey", _("Key that opens the Home Assistant menu")),
        ("menu_transparency", _("Menu background transparency")),
        ("menu_combo_key", _("Key pressed several times to open the menu")),
        ("menu_combo_presses", _("Presses that open the menu")),
        ("menu_combo_gap_ms", _("Longest pause between two presses")),
    )


def section_headings():
    """Setting name, and the heading the screen shows above it: where a section begins."""
    return {
        "recording_delete_allowed": _("Recordings"),
        "menu_allowed": _("Home Assistant menu"),
    }


def is_heading(entry):
    """Whether a list entry is a heading - `(text,)`, with no setting behind it.

    The images' own setup screens write a section heading this way, and their `ConfigList`
    skips an entry of one item when it selects, saves, cancels and asks what changed. This
    screen does the same in every loop it runs over its entries.
    """
    return not isinstance(entry, (tuple, list)) or len(entry) < 2


# The images' ConfigListScreen methods that read the selected entry's setting, `[1]`, and are
# reached from a key or a timer. Read in the sources of OpenViX, OpenPLi, OpenATV and OpenBH:
# OpenATV guards none of `getCurrentItem`, `getCurrentValue` and `keyMenu`, and its list's
# `handleKey` none either; OpenViX and OpenBH leave `keyMenu`; OpenPLi and OpenViX leave the
# callbacks after `keyText`; every image leaves `ConfigList.toggle`. And a key's action map can
# stay enabled from the setting before: moving onto a heading does not run `handleInputHelpers`.
# On this screen every one of them does nothing on a heading and is the image's own anywhere
# else; one the image does not have is nothing.
HEADING_GUARDED = (
    "keySelect", "keyLeft", "keyRight", "keyFirst", "keyLast", "keyNumberGlobal", "keyGotAscii",
    "keyBackspace", "keyDelete", "keyErase", "keyToggle", "keyMenu", "keyText",
    "handleInputHelpers",
)
# What a getter answers on a heading, as the images that guard it do.
HEADING_GETTERS = {"getCurrentItem": None, "getCurrentValue": ""}
# The list widget's own methods, guarded on the instance: a timer of the image's (the one that
# ends typing a number) calls `handleKey` too, after the selection may have moved.
LIST_GUARDED = ("handleKey", "toggle")


def _current(widget):
    try:
        return widget.getCurrent()
    except Exception:
        return None


def guard_list(widget):
    """Make the list widget's key handling do nothing while a heading is selected."""
    for name in LIST_GUARDED:
        original = getattr(widget, name, None)
        if not callable(original):
            continue

        def guarded(*arguments, _original=original, **keywords):
            if is_heading(_current(widget)):
                return None
            return _original(*arguments, **keywords)

        try:
            setattr(widget, name, guarded)
        except Exception:
            LOG.debug("the list's %s could not be guarded against a heading", name)


def build_entries(settings):
    entries = []
    headings = section_headings()
    for name, label in setting_labels():
        element = getattr(settings, name, None)
        if element is None:
            LOG.warning("no such setting: %s", name)
            continue
        if name in headings:
            entries.append((headings[name],))
        entries.append(getConfigListEntry(label, element))
    return entries


def setting_entries(entries):
    """The entries that hold a setting: every one but the headings."""
    return [entry for entry in entries if not is_heading(entry)]


def status_text(bridge, settings):
    node = (settings.node_id.value or "").strip()
    if not settings.enabled.value:
        state = _("Disabled")
    elif bridge is None:
        state = _("Disconnected")
    elif bridge.idle_reason:
        state = _("Idle")
    elif bridge.connected:
        state = _("Connected")
    else:
        state = _("Disconnected")
    return state + "  ·  " + (_("Node: %s") % (node or "-"))


def _uninstalling(bridge):
    """Whether `cmd/uninstall` is under way on this bridge. Anything unreadable is „no"."""
    try:
        return bool(bridge.uninstaller.underway)
    except Exception:
        return False


def _updating(bridge):
    """Whether an update has closed the plugin's doors. Anything unreadable is "no"."""
    try:
        return bool(bridge.self_update.closed)
    except Exception:
        return False


class MQTTBridgeSetup(Screen, ConfigListScreen):
    # The blue key is wider than the others because its label is the screen's own name,
    # "Aktualizacje wtyczki" and "Plugin-Aktualisierungen": this screen has no yellow key, so it
    # takes that room rather than a shorter name (`test_the_words_fit_the_screen`).
    skin = """
        <screen name="MQTTBridgeSetup" position="center,center" size="900,600" title="MQTT Bridge">
            <widget name="config" position="20,20" size="860,470" scrollbarMode="showOnDemand" />
            <widget name="status" position="20,500" size="860,30" font="Regular;22" />
            <widget name="key_red" position="20,550" size="200,30" font="Regular;22"
                    foregroundColor="red" />
            <widget name="key_green" position="230,550" size="200,30" font="Regular;22"
                    foregroundColor="green" />
            <widget name="key_blue" position="540,550" size="340,30" font="Regular;22"
                    foregroundColor="blue" />
        </screen>
    """

    def __init__(self, session, settings=None, bridge=None):
        Screen.__init__(self, session)
        self.settings = settings if settings is not None else config.plugins.mqttbridge
        self._bridge = bridge

        self.entries = build_entries(self.settings)
        try:
            ConfigListScreen.__init__(
                self, self.entries, session=session, on_change=self._entry_changed
            )
        except TypeError:
            # Older images' ConfigListScreen takes no `on_change`. The screen
            # still works; its status line simply stops refreshing as fields are
            # edited, which is cosmetic.
            LOG.debug("this image's ConfigListScreen has no on_change")
            ConfigListScreen.__init__(self, self.entries, session=session)
        guard_list(self["config"])

        self["status"] = Label(status_text(self._bridge_or_running(), self.settings))
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Save"))
        self["key_blue"] = Label(_("Plugin updates"))
        self["mqttbridgeActions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "save": self.keySave,
                "green": self.keySave,
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "blue": self.keyUpdates,
            },
            -2,
        )
        try:
            # Not every flavour of Screen has it, and none of them need it.
            self.setTitle(_("MQTT Bridge"))
        except Exception:
            LOG.debug("this image's Screen has no usable setTitle")

    def _bridge_or_running(self):
        if self._bridge is not None:
            return self._bridge
        try:
            from .plugin import get_bridge

            return get_bridge()
        except Exception:
            return None

    def _entry_changed(self):
        """Keep the status line honest while the fields are being edited."""
        try:
            self["status"].setText(status_text(self._bridge_or_running(), self.settings))
        except Exception:
            # Called once before the label exists on some images, and a status
            # line is never worth an exception in front of a user.
            LOG.debug("the status line could not be refreshed")

    def _on_heading(self):
        """Whether the selection is on a heading, where a key meant for a setting finds none."""
        try:
            return is_heading(self["config"].getCurrent())
        except Exception:
            return False

    def keyDefault(self, *arguments, **keywords):
        """Nothing, on any entry: no key on this screen puts every setting back to its default.

        OpenATV binds it where a screen asks for defaults, and its own loops over every entry
        reading the setting behind it - which a heading does not have. And one key that resets the
        broker's address and credentials with everything else is not a key this screen offers.
        """
        return None

    def _anything_changed(self):
        for entry in setting_entries(self.entries):
            element = entry[1]
            checker = getattr(element, "isChanged", None)
            try:
                # enigma2 keeps `saved_value` as a string, so only the element
                # itself can answer this; the comparison is the fallback for a
                # stub or an image that does not offer `isChanged`.
                changed = bool(checker()) if checker is not None else (
                    element.value != element.saved_value
                )
            except Exception:
                changed = element.value != element.saved_value
            if changed:
                return True
        return False

    def keySave(self):
        for entry in setting_entries(self.entries):
            element = entry[1]
            try:
                element.save()
            except Exception:
                LOG.exception("could not save a setting")
        try:
            configfile.save()
        except Exception:
            LOG.exception("could not write enigma2's settings file")

        bridge = self._bridge_or_running()
        if bridge is not None and _updating(bridge):
            # Kept, not applied, for the uninstall's reason below: a reload would open a
            # session under the update's closed doors, and a change applied live would publish
            # behind them. The update ends in a restart, which starts from them.
            LOG.warning("settings saved during an update; not applying them now")
            self._tell_and_close(household_doors(bridge.self_update))
            return
        if bridge is not None and _uninstalling(bridge):
            # 🔴 A reload now would open a fresh session and republish
            # everything underneath a removal that has just retracted it. The
            # settings are kept, not refused: they were typed on a remote
            # control, they are what a reinstall will start from, and if the
            # removal stops its own failure path reloads the bridge - with
            # them. So nothing is lost and nothing is applied twice; the
            # household is told why the change does not show yet.
            LOG.warning("settings saved during an uninstall; not applying them now")
            self._tell_and_close(_(
                "Settings saved. The plugin is being removed from this receiver, so they "
                "are not applied now; they take effect if the removal stops or the plugin "
                "is installed again."
            ))
            return
        if bridge is not None:
            try:
                # A reconnect only when the connection changed or the plugin was switched off
                # or on; anything else applies under the open session.
                bridge.apply_saved_settings()
            except Exception:
                LOG.exception("the bridge could not apply the new settings")
        self.close(True)

    def keyUpdates(self):
        """Blue: the "Plugin updates" screen - or, behind an update's closed doors, only why not.

        Unsaved edits on this screen stay as they are: the updates screen changes no setting,
        and closing it comes back here.
        """
        try:
            bridge = self._bridge_or_running()
            if bridge is not None and _updating(bridge):
                self.session.open(MessageBox, household_doors(bridge.self_update),
                                  getattr(MessageBox, "TYPE_INFO", 1))
                return
            self.session.open(MQTTBridgeUpdates, bridge=bridge)
        except Exception:
            LOG.exception("the plugin updates screen could not be opened")

    def _tell_and_close(self, text):
        try:
            self.session.openWithCallback(
                lambda *_answer: self.close(True),
                MessageBox,
                text,
                getattr(MessageBox, "TYPE_INFO", 1),
            )
        except Exception:
            LOG.exception("could not say why the settings were not applied")
            self.close(True)

    def keyCancel(self):
        """Red or Exit. Ask first when there is something to lose.

        A broker password typed on a remote control with the on-screen keyboard
        is minutes of somebody's evening, and Exit is next to the arrow keys.
        The question is the image's own standard one, so it reads like the rest
        of the receiver.
        """
        if not self._anything_changed():
            self._discard()
            return
        try:
            self.session.openWithCallback(
                self._cancel_answered,
                MessageBox,
                _("Really close without saving settings?"),
                getattr(MessageBox, "TYPE_YESNO", 0),
            )
        except Exception:
            # No dialog on this image is not a reason to trap the user in the
            # screen: fall back to the old behaviour.
            LOG.exception("could not ask about the unsaved settings")
            self._discard()

    def _cancel_answered(self, confirmed):
        if confirmed:
            self._discard()

    def _discard(self):
        for entry in setting_entries(self.entries):
            element = entry[1]
            try:
                element.cancel()
            except Exception:
                LOG.exception("could not restore a setting")
        self.close(False)


def _heading_safe(name, answer=None):
    """`name` of the image's ConfigListScreen, doing nothing - answering `answer` - on a heading."""

    def method(self, *arguments, **keywords):
        if self._on_heading():
            return answer
        parent = getattr(ConfigListScreen, name, None)
        if parent is None:
            return answer
        return parent(self, *arguments, **keywords)

    method.__name__ = name
    return method


for _name in HEADING_GUARDED:
    setattr(MQTTBridgeSetup, _name, _heading_safe(_name))
for _name, _answer in HEADING_GETTERS.items():
    setattr(MQTTBridgeSetup, _name, _heading_safe(_name, _answer))
del _name, _answer
