"""The bridge itself: enigma2 on one side, the broker on the other.

Three rules shape everything below.

**The receiver comes first.** `start` cannot raise. An invalid configuration
produces one log line and an idle plugin, never a retry storm and never a
dialog, because the graphical interface must come up whatever the state of the
broker.

**`on_connect` publishes everything, every time** - availability, the full
snapshot, the announcement, and in discovery mode the discovery payloads. Not
once at start-up: a daemon that announces only at start-up never registers what
it learned after it last connected, and a broker that lost its retained store
never gets it back.

**What was published retained is remembered**, so that it can be retracted later
even from a fresh process. That record is `discovery.StateStore`.

Publishers are how this file grows without being rewritten: a publisher has a
name, which becomes a capability, a `start()` that binds its enigma2 hooks and
says whether the image provided them, and a `snapshot()` that is called on
connect and on reset.

**A publisher publishes on change.** `publish_state` compares what it is about
to send with what went out last and drops a repeat, because a receiver that
re-publishes the same volume every five seconds writes a row into somebody's
recorder database every five seconds. The snapshot is the deliberate exception:
`on_connect` forgets everything it knows and sends the lot.

**A field the payload stamps from the clock is not part of that comparison.** A
publisher names such fields in `volatile`, and they ride in every payload while
staying out of the change test. Left in, they answer „did the code run again?"
rather than „did the receiver change?", and a topic rebuilt by a timer would
then republish itself for as long as the box is switched on.
"""

import json
import time
from collections import OrderedDict

from . import boxinfo, buildid, discovery, wol
from . import config as settings_module
from .cec import TOPIC as CEC_TOPIC
from .cec import CecPublisher
from .commands import CommandDispatcher, clean_id
from .diagnostics import LoopMonitor
from .enigma2 import Ticker
from .log import configure as configure_logging
from .log import get_logger, register_secret
from .mqttclient import BrokerSettings, MqttClient, accepted
from .publisher import Publisher
from .selfupdate import CAPABILITY as SELF_UPDATE_CAPABILITY
from .selfupdate import SelfUpdater
from .stream import CLIENTS_TOPIC as STREAM_CLIENTS_TOPIC
from .stream import TOPIC as STREAM_TOPIC
from .stream import StreamPublisher
from .uninstall import DEFERRED as UNINSTALL_DEFERRED
from .uninstall import RUNNING as UNINSTALL_RUNNING
from .uninstall import Uninstaller
from .updatecheck import RELEASE_INDEX_TOPIC, UpdateChecker
from .updatecheck import SUFFIX as UPDATE_SUFFIX
from .updatecheck import VOLATILE as UPDATE_VOLATILE
from .version import CONTRACT, __version__

# `Publisher` is re-exported: it is part of this module's interface - every
# publisher subclasses it and the tests import it from here - and it lives in
# its own module only to keep the imports acyclic.
__all__ = ["Bridge", "Publisher"]

LOG = get_logger("bridge")


def _capped(text, limit):
    """`text` in at most `limit` characters, visibly cut when it was too long."""
    text = str(text or "")
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "\u2026"


def _sendable(text):
    """`text` as UTF-8 can carry it: what it has no bytes for is written as its escape.

    A JSON payload can spell half a surrogate pair, and a handler that echoes
    it hands over a sentence the client cannot encode. Any other text comes
    back as the object it was.
    """
    try:
        text.encode("utf-8")
    except UnicodeEncodeError:
        return text.encode("utf-8", "backslashreplace").decode("utf-8")
    return text


def _encoded(payload):
    """The canonical JSON for a payload: one dictionary, always the same bytes."""
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _change_key(encoded, payload, volatile):
    """What „has this changed?" is asked about: the payload without its own stamps.

    A field a payload writes from the wall clock moves whether or not the
    receiver did, so comparing bytes that carry one answers „did this run
    again?" instead of „is this different?". On a retained topic rebuilt by a
    timer that means a republish every time the timer fires however little has
    moved - a state change delivered to every consumer and a row in somebody's
    recorder, for a payload saying exactly what it said before - and nothing
    bounds it, because the timer does not stop.

    So the named fields are left out of the comparison and kept in what goes
    out. A consumer still reads a stamp; what the stamp means is now when the
    payload last differed, which is the question it was being asked anyway.
    """
    if not volatile or not isinstance(payload, dict):
        return encoded
    return _encoded(
        dict((name, value) for name, value in payload.items() if name not in volatile)
    )


ONLINE = "online"
OFFLINE = "offline"

# The contract: state topics are retained at QoS 0, commands arrive at QoS 1.
STATE_QOS = 0
COMMAND_QOS = 1

# The will is the one publish nobody gets to retry, so it is asked for at QoS 1.
WILL_QOS = 1

# Capabilities are the feature-area names in docs/TOPICS.md and nothing else -
# `power`, `service`, `epg`, `tuner`, ... - each added by the publisher that bound
# its hooks. The connection itself is not a capability, so this tuple is empty
# and stays empty: everything in the list got there by working.
CORE_CAPABILITIES = ()

# The one capability with no publisher behind it. `message` is a command, so
# what makes it real is the popup machinery being importable, not a hook.
MESSAGE_CAPABILITY = "message"

# Claimed where the package manager installed this very copy of the plugin
# (`uninstall.py`), and by nothing else - there is no publisher behind it.
UNINSTALL_CAPABILITY = "uninstall"

# Claimed by every plugin that opens the envelope a command's id comes in
# (`commands.unwrap`), so by this one always. It is not a feature area: it tells
# a consumer that the envelope is safe to send, which an older plugin would take
# for the command's own payload.
COMMAND_ID_CAPABILITY = "command_id"

SHUTDOWN_FLUSH_SECONDS = 1.0

# What a session is: where the broker is, who logs in, how, and under which
# name. A save that changed one of these, or switched the plugin off or on,
# reloads; every other save is applied under the open session. The reload says
# `offline` first, except on a rename: the last two name the will's topic, which
# makes a change to them a rename (see `reload`).
IDENTITY_CONNECTION_SETTING_NAMES = ("node_id", "base_topic")
CONNECTION_SETTING_NAMES = (
    "host", "port", "tls", "ca_file", "username", "password",
) + IDENTITY_CONNECTION_SETTING_NAMES

# A save on the receiver - its setup screen or the OpenWebif page - reconnects only for one of
# these or for the plugin's own switch, `enabled` (`apply_saved_settings`). Every other setting
# is applied under the open session, as `cmd/config` applies its own.
#
# The settings `_replace_configurable_publishers` applies: `cmd/config`'s four publishers, and
# the OSCam login the OSCam publisher reads when it starts.
CONFIGURABLE_PUBLISHER_SETTING_NAMES = (
    "publish_keys", "screenshot", "screenshot_interval", "screenshot_delay",
    "cam_telemetry", "oscam_telemetry", "oscam_port", "oscam_username", "oscam_password",
)

# A command name comes off the topic, so its length is the publisher's choice.
# The retained `last_error` is not the place to store somebody's 4 KB topic.
LAST_ERROR_CMD_LIMIT = 64
SLOW_SNAPSHOT_PUBLISHER_SECONDS = 0.25
SLOW_SNAPSHOT_TOTAL_SECONDS = 1.0

# What the OpenWebif page is allowed to show of what went out: the last payload
# of each retained JSON topic, as a consumer received it. Bounded both ways,
# because a channel select's discovery payload alone can run to tens of
# kilobytes and the page lives in the GUI process.
REMEMBERED_TOPICS = 256
REMEMBERED_BYTES = 16384

# The largest MQTT packet this node sends. A broker that is handed a bigger one
# closes the connection: Mosquitto 2.1 at 2,000,000 bytes by default, other
# common brokers at 1 MiB, and MQTT 3.1.1 gives a client no way to learn the
# figure. The will then says `offline`, the client reconnects a second later
# and the snapshot sends the same payload again - for as long as the box is
# switched on. So the bound is this node's own, under both defaults, and a
# payload over it stays on the receiver (`publish_raw`).
MAX_PACKET_BYTES = 1000000

# What a PUBLISH at QoS 0 carries besides its topic and payload: the fixed
# header - one byte and up to four of remaining length - and the two bytes of
# the topic's length. Counted at its largest, so the estimate never runs short.
PACKET_OVERHEAD_BYTES = 1 + 4 + 2

# How long `info` waits after `not_published` changed before it says so, and
# the longest it waits when the changes keep coming. Topics become withheld in
# bursts - at a start the grids are built one after another - and an `info` for
# each of them is a state change delivered to every consumer several times in a
# few seconds, for a list that is only true at the end. Every change starts the
# wait again, up to the second figure, so a burst costs one `info`.
NOT_PUBLISHED_SETTLE_MILLISECONDS = 2000
NOT_PUBLISHED_LATEST_SECONDS = 10.0

_DEFAULT_MONITOR = object()


def _oversize(topic, payload):
    """The bytes of the packet this publish needs when that is over the bound, else 0.

    Bytes, not characters: a channel name in Polish or Greek is two bytes a
    letter. Text that fits even at four bytes a character is not encoded just
    to be measured - that covers every payload but the few worth measuring.
    """
    if isinstance(payload, (bytes, bytearray)):
        body = len(payload)
    else:
        text = "" if payload is None else str(payload)
        if PACKET_OVERHEAD_BYTES + (len(topic) + len(text)) * 4 <= MAX_PACKET_BYTES:
            return 0
        body = len(text.encode("utf-8"))
    size = PACKET_OVERHEAD_BYTES + len(topic.encode("utf-8")) + body
    return size if size > MAX_PACKET_BYTES else 0


class Bridge:
    def __init__(self, session=None, settings=None, client_factory=None, dispatcher=None,
                 state_store=None, provisioning_path=None, log_path=None,
                 loop_monitor=_DEFAULT_MONITOR, build=buildid.LOADED, build_path=None):
        self.session = session
        self.settings = settings if settings is not None else settings_module.settings
        self.client = None
        self.running = False
        self.idle_reason = None
        self._client_factory = client_factory
        self._dispatcher = dispatcher
        self._state_store = state_store
        self._provisioning_path = provisioning_path
        self._log_path = log_path
        self._loop_monitor = LoopMonitor() if loop_monitor is _DEFAULT_MONITOR else loop_monitor
        self._publishers = []
        self._commands = CommandDispatcher(self)
        # Built with the bridge, so that nothing the removal runs is a first
        # import after the package has gone.
        self._uninstaller = Uninstaller(self)
        # Built with the bridge as well, and kept across reloads: what it has
        # judged is the receiver's, not the session's, and its ten-minute limit
        # must not reset with every settings save.
        self._updates = UpdateChecker(self)
        # Built with the bridge, and kept across reloads, for both reasons above: a
        # transaction outlives every session opened while it runs, and nothing it runs
        # after the new files are on disk may be a first import.
        self._self_update = SelfUpdater(self)
        # A refusal that has to wait for a session to be published on: the
        # reason a removal failed, reported once the fresh session is up.
        self._pending_error = None
        self._last_error_published = False
        # Until this process has connected once: a `last_error` the state file
        # knows of then is an earlier run's (`_clear_earlier_runs_error`). Not
        # reset by a reload - a new session is not a new run.
        self._first_connect = True
        # topic -> the bytes last sent to it, so a repeat can be dropped.
        self._published = {}
        # topic -> the JSON last published to it, for the OpenWebif page. Not
        # `_published`: that holds the change key, which for a topic with
        # volatile fields is the payload *without* its timestamps. Raw topics
        # (`availability`, the screenshot) are only named, never kept.
        self._last_json = OrderedDict()
        self._raw_topics = set()
        # topic -> the packet size, when it was first measured, of a payload too big to send
        # (`MAX_PACKET_BYTES`): `info.not_published`. Not `_published`, and not
        # forgotten on a connect - a reconnect that forgot it would log the same
        # payload again every time. Beside it, the list `info` last carried on
        # this connection, or None before the first one.
        self._not_published = {}
        self._not_published_reported = None
        # The wait before `info` says that the list changed
        # (`_report_not_published`), and when the first change it is waiting
        # over was seen - None while it waits for nothing.
        self._not_published_ticker = Ticker(self._say_not_published, "not published")
        self._not_published_since = None
        # The build on disk the log last named (`check_build_on_disk`), so a
        # build that cannot be published is logged once and not at every check.
        self._build_logged = None
        # Whether the discovery payload last built had to leave the channel
        # select out to fit one packet (`_discovery_components`). Kept so that
        # the log says so when it starts, not on every connect.
        self._select_left_out = False
        # The last picture this process put on `screen`, and when it was taken,
        # for the OpenWebif page. Held here and not on the publisher, because
        # the publisher is replaced by every settings save while the retained
        # picture on the broker outlives all of them. The same bytes object the
        # publisher sent - no copy.
        self._screenshot = None
        self._screenshot_topic = None
        # The open session's will topic, and the settings it connected with:
        # what `reload` compares a save against.
        self._will_topic = None
        self._session_settings = None
        # Every setting as the open session last applied it - at its start, a `cmd/config`, an
        # `ha_mode` command or a save applied live: what `apply_saved_settings` finds changed.
        # And whether the last save reconnected, for the page's sentence.
        self._applied_settings = None
        self._last_save_reconnected = None
        # The build this process runs, and where the build on disk is read from:
        # `info.build`. Arguments only so that a test can say which build it is.
        self._build = build
        self._build_path = build_path if build_path is not None else buildid.ON_DISK_PATH
        self._build_reported = None
        self._build_ticker = Ticker(self.check_build_on_disk, "build")
        self._capabilities_logged = None

    # ----------------------------------------------------------------- settings --

    def value(self, name):
        return settings_module.value(name, self.settings)

    def set_value(self, name, new_value):
        element = settings_module.element(name, self.settings)
        if element is None:
            return False
        element.value = new_value
        return True

    def save_settings(self):
        return settings_module.save(self.settings)

    def remote_settings(self):
        """The non-secret settings exposed to and writable by the integration."""
        return {
            name: self.value(name) for name in settings_module.REMOTE_SETTING_NAMES
        }

    def published_settings(self):
        """What `info.settings` carries: the non-secret settings, writable or not.

        Presence is not permission. The writable ones are the `cmd/config`
        allowlist and nothing else; the rest are read-only over MQTT and are set
        on the receiver - its setup screen, the provisioning file or the
        OpenWebif page - which `docs/TOPICS.md` says member by member.
        """
        values = self.remote_settings()
        for name in settings_module.READ_ONLY_SETTING_NAMES:
            # Published the way the command guard applies it - anything falsy is
            # a refusal - so it is a boolean even on an image where the element
            # did not build, and a consumer reading it hides the control.
            values[name] = bool(self.value(name))
        return values

    def apply_remote_settings(self, values):
        """Persist one validated replacement, then apply its publisher lifecycle.

        🔴 Not while the plugin removes itself - from acceptance, not only once
        the doors close. Applying swaps publishers, republishes `info` and
        discovery and retracts stale topics at QoS 0, none of it inside the set
        the teardown retracts and has acknowledged. So the values are saved as
        `apply_settings` saves them, nothing is applied, and `cmd/config` says
        so on `last_error`: the change did not take effect, which is what a
        consumer that waits for `info.settings` needs to hear.
        """
        if self._uninstaller.underway:
            error = self.defer_settings(values)
            return error or UNINSTALL_DEFERRED
        if self._uninstaller.closed:
            return UNINSTALL_RUNNING
        if self._self_update.closed:
            return self._self_update.doors_refusal()
        if not settings_module.save_remote_settings(values, self.settings):
            return "could not persist the plugin settings"

        self._mark_applied(settings_module.REMOTE_SETTING_NAMES)
        self._replace_configurable_publishers()
        # The menu's hotkey and press combo are rebound in place rather than by replacing the
        # publisher: the menu it holds, and a screen that may be open on it, belong to this
        # session.
        menu = self.publisher("menu")
        if menu is not None:
            menu.rebind_hotkey()
            menu.rebind_combo()
        # No reconnect follows this path, so nothing else would retract what the
        # new settings stopped publishing: `publish_keys` switched off here takes
        # the `keys` capability, and with it the eight device triggers, which
        # would otherwise stay retained - and offered in Home Assistant's
        # automation editor - until the next connect. Before the republish, so
        # the node retracts before it announces, as a mode switch does.
        self.retract_stale()
        info = self.build_info()
        self.publish_info(info)
        self.publish_discovery(info)
        return None

    def apply_settings(self, values):
        """Persist settings the broker cannot write, then apply them as the setup screen does.

        The setup screen's path, taken for any change outside `cmd/config`'s
        allowlist: save, write the settings file once, `apply_saved_settings()` -
        a reconnect when the connection changed, the change applied under the
        open session otherwise. Either way `info` - and in discovery mode the
        buttons a permission gates - is published again, so a setting changed on
        the OpenWebif page reaches a consumer exactly as one changed on the
        television does, and a kill-switch rebinds its hook the same way.
        `values` must already be validated. `last_save_reconnected` says
        afterwards which of the two it was, and None when it was neither.
        """
        self._last_save_reconnected = None
        if self._uninstaller.underway:
            return self.defer_settings(values)
        if self._uninstaller.closed:
            return UNINSTALL_RUNNING
        if self._self_update.closed:
            # Neither a reload nor a live change under the update's closed doors.
            return self._self_update.doors_refusal()
        if not settings_module.save_settings(values, self.settings):
            return "could not persist the plugin settings"
        self.apply_saved_settings()
        return None

    @property
    def last_save_reconnected(self):
        """Whether the last `apply_saved_settings` opened a new session, or None before one."""
        return self._last_save_reconnected

    def apply_saved_settings(self):
        """Apply what a save on the receiver changed. True when it reconnected.

        The setup screen's Save and the OpenWebif page's settings forms end
        here, after the settings are saved. A new session is built only when it
        has to be - the open session was built from another broker, login or
        name than the settings now hold, the plugin was switched off, or there is
        no session to change (the plugin was idle, or switched on just now) -
        and `reload` does that as it always has, with its `offline` rule
        (`_says_offline_on_reload`). Every other change is applied under the open
        session (`_apply_live`), so the menu is not greyed and Home Assistant
        sees no reconnect for a change that did not touch the connection.

        The callers keep the doors an uninstall or an update closes: they never
        get here while one is under way.
        """
        if self._reconnects_for_save():
            self._last_save_reconnected = True
            self.reload()
            return True
        self._last_save_reconnected = False
        try:
            self._apply_live()
        except Exception:
            LOG.exception("the saved settings could not all be applied; reconnecting instead")
            self._last_save_reconnected = True
            self.reload()
            return True
        return False

    def _reconnects_for_save(self):
        """Whether a save needs a new session: see `apply_saved_settings`."""
        if self.client is None or self._session_settings is None:
            return True
        if not self.value("enabled"):
            return True
        return self._connection_settings() != self._session_settings

    def _settings_now(self):
        return {name: self.value(name) for name in settings_module.SETTING_NAMES}

    def _mark_applied(self, names):
        """These settings, as they stand, are what the open session runs with."""
        if self._applied_settings is None:
            return
        for name in names:
            self._applied_settings[name] = self.value(name)

    def _changed_since_applied(self):
        """The settings that differ from what the open session last applied, sorted."""
        applied = self._applied_settings or {}
        return sorted(
            name for name in settings_module.SETTING_NAMES
            if name not in applied or applied[name] != self.value(name)
        )

    def _apply_live(self):
        """Apply a saved change under the open session, as a reconnect would have.

        Each setting is applied the way the code that reads it needs: a
        `cmd/config` setting as `apply_remote_settings` applies it - the four
        publishers it configures replaced, the hotkey and the press combo rebound; a kill-switch
        or a box-only choice by replacing the publisher that reads it when it
        starts (the toast, the CEC workaround, the EPG grid, the receiver menu
        with its subscriptions and Extensions entry), or by asking the publisher
        that reads it at work to read it again (the channel list, the EPG grid's
        events per channel); the log level, Wake-on-LAN and the device name as a
        start applies them; a permission by nothing at all, since every command
        reads it when it runs. Then, as at a connect: what this node no longer
        publishes is retracted, and `info`, the announcement and the discovery
        payloads go out again - which carry every setting, capability and button.

        Without a broker connection only the receiver's side is changed: the
        connect that follows retracts and publishes everything, and a
        retraction sent now would be forgotten without having been sent.
        """
        # At every save, as when every save restarted the bridge: with `wol_arm` on, the image's
        # own switch turned off in its menu is turned on again (SETUP.md). It writes nothing
        # when the switch is already on.
        wol.arm(self.settings)
        changed = set(self._changed_since_applied())
        if not changed:
            LOG.info("settings saved; nothing the bridge runs with has changed")
            return
        # Names only: one of these may be a password.
        LOG.info("settings saved; applying %s without a reconnect", ", ".join(sorted(changed)))
        if "log_level" in changed:
            configure_logging(self.value("log_level"), self._log_path)
        if "friendly_name" in changed:
            # An emptied name is derived again, as at a start.
            self._ensure_identity()
        # A new `oscam_password` is registered for the log's filter by the OSCam publisher that
        # replaces the old one below, as at a start (`OscamPublisher.start`).
        started = []
        if changed & set(CONFIGURABLE_PUBLISHER_SETTING_NAMES):
            self._replace_configurable_publishers()
        if "osd_toast" in changed:
            from .toast import ToastPublisher

            started += self._replace_publishers((ToastPublisher,), with_session_only=True)
        if "cec_standby_workaround" in changed:
            started += self._replace_publishers((CecPublisher,), with_session_only=True)
            if self.publisher(CecPublisher.name) is None and self.connected:
                # What a connect without the workaround does (`on_connect`).
                self.retract(self.topic(CEC_TOPIC))
        if "bouquets_for_select" in changed:
            channels = self.publisher("channels")
            if channels is not None:
                # Walks the selection again: the lists, the index and the slugs, and the EPG
                # grid follows (`when_changed`). The select's options go with discovery below.
                channels.refresh()
            service = self.publisher("service")
            if service is not None and self.connected:
                # `service.bouquet` is looked up in the channel list when `service` is
                # published, and nothing else republishes it before the next zap.
                service.refresh()
        if "epg_grid_events" in changed:
            started += self._apply_grid_events()
        if "menu_allowed" in changed:
            started += self._switch_menu()
        else:
            menu = self.publisher("menu")
            if menu is not None:
                if "menu_hotkey" in changed:
                    menu.rebind_hotkey()
                if changed & set(settings_module.MENU_COMBO_SETTING_NAMES):
                    menu.rebind_combo()
                if "ha_discovery_prefix" in changed and self.connected:
                    menu.resubscribe(self.client)
        self._applied_settings = self._settings_now()
        if not self.connected:
            LOG.info("no broker connection; the next connect publishes the change")
            return
        for publisher in started:
            self._publish_own_snapshot(publisher)
        if "ha_mode" in changed and self.value("ha_mode") != "discovery":
            self.retract_discovery()
        # Before the republish, so the node retracts before it announces - as at a connect,
        # and as `apply_remote_settings` does.
        self.retract_stale()
        info = self.build_info()
        self.publish_info(info)
        self.publish_announcement(info)
        self.publish_discovery(info)
        if "ha_mode" in changed:
            # Which releases are compatible depends on whether an integration is in use.
            self._updates.publish()
        self.state.save()

    def _apply_grid_events(self):
        """`epg_grid_events` changed: build the grids to the new count, or start or stop them."""
        from .epggrid import EpgGridPublisher

        grid = self.publisher(EpgGridPublisher.name)
        if grid is not None and grid.events_per_channel > 0:
            grid.regenerate()
            return []
        started = self._replace_publishers((EpgGridPublisher,), with_session_only=True)
        if self.publisher(EpgGridPublisher.name) is None and self.connected:
            # Turned down to 0: every grid goes, as at a connect without the publisher.
            self.sync_grid_slugs()
        return started

    def _switch_menu(self):
        """`menu_allowed` changed: offer the receiver menu now, or take it away.

        The menu's subscriptions go and come with its publisher, and the
        Extensions entry follows the setting whatever the publisher managed to
        build - as at a start (`_start`).
        """
        from .menu import MenuPublisher

        old = self.publisher(MenuPublisher.name)
        if old is not None and self.connected:
            old.unsubscribe(self.client)
        started = self._replace_publishers((MenuPublisher,), with_session_only=True)
        menu = self.publisher(MenuPublisher.name)
        if menu is not None and self.connected:
            menu.subscribe(self.client)
            menu.connection_changed()
        self._sync_menu_entry()
        return started

    def _publish_own_snapshot(self, publisher):
        """What a publisher started under the open session holds, as its connect would send it."""
        try:
            for suffix, payload in publisher.snapshot().items():
                publisher.publish(suffix, payload)
        except Exception:
            LOG.exception("the %s publisher's state could not be published", publisher.name)

    def defer_settings(self, values):
        """Save settings while the plugin removes itself, and apply nothing now.

        🔴 A reload here would open a fresh session underneath the removal -
        republishing what it retracts, or, before its first turn, leaving it a
        session that is not connected yet, so it fails and the removal is lost.
        The values are kept: a reinstall starts from them, and if the removal
        stops, its failure path reloads the bridge with them. The same rule as
        the setup screen's Save. `values` must already be validated.
        """
        if not settings_module.save_settings(values, self.settings):
            return "could not persist the plugin settings"
        LOG.warning("settings saved during an uninstall; not applying them now")
        return None

    def run_command(self, name, text, origin, **consents):
        """A command from somewhere other than the broker - the dispatcher's refusal, or None.

        Nothing runs while the plugin is removing itself, and the refusal is not
        published: `last_error` would be a retained topic created after the
        retraction, which is the one thing the removal must not leave behind.
        `consents` are the television's or the page's confirmed answers
        (`CommandDispatcher.run`).
        """
        if self._uninstaller.closed:
            return UNINSTALL_RUNNING
        return self._commands.run(name, text, origin, **consents)

    @property
    def command_id(self):
        """The id of the command a handler is running for right now, or None.

        What a handler's later work takes when it is accepted, to say back
        with a refusal it publishes turns afterwards (`commands.py`).
        """
        return self._commands.command_id

    @property
    def updates(self):
        """The update check: the `update` topic, `cmd/update_check` and the relayed index."""
        return self._updates

    @property
    def uninstaller(self):
        return self._uninstaller

    @property
    def self_update(self):
        """`cmd/update`: the guards, the helper's launch, the doors and the restart question."""
        return self._self_update

    def discarded_retained_commands(self):
        """This node's command topics somebody left a retained message on, this session."""
        return set(self._commands.discarded_retained)

    def last_payloads(self):
        """`(topic, payload)` for every retained topic this process published, sorted.

        The payload is the JSON as it went out, or None for a raw topic, which
        the page names without showing.
        """
        rows = [(topic, payload) for topic, payload in self._last_json.items()]
        rows.extend((topic, None) for topic in self._raw_topics)
        return sorted(rows)

    def last_error(self):
        """The `last_error` payload as it stands on the broker, or None when it is clear."""
        if not self._last_error_published:
            return None
        return self._last_json.get(self.topic("last_error"))

    def diagnostics(self):
        """What §3.2's runtime diagnostics measure, read from memory for the page."""
        values = {}
        if self.client is not None:
            reader = getattr(self.client, "diagnostics", None)
            if reader is not None:
                values.update(reader())
        if self._loop_monitor is not None:
            reader = getattr(self._loop_monitor, "state", None)
            if reader is not None:
                values.update(reader())
        return values

    def _remember(self, topic, encoded):
        """Keep the last JSON of one retained topic, within the page's bounds."""
        self._raw_topics.discard(topic)
        if len(encoded) > REMEMBERED_BYTES:
            encoded = encoded[: REMEMBERED_BYTES - 1] + "\u2026"
        self._last_json.pop(topic, None)
        self._last_json[topic] = encoded
        while len(self._last_json) > REMEMBERED_TOPICS:
            self._last_json.popitem(last=False)

    def _forget(self, topic):
        self._last_json.pop(topic, None)
        self._raw_topics.discard(topic)

    def _replace_configurable_publishers(self):
        """Rebind only hooks controlled by cmd/config; preserve all other work."""
        from .cam import CamPublisher
        from .oscam import OscamPublisher
        from .remote import KeyPublisher
        from .screen import ScreenPublisher

        self._replace_publishers((CamPublisher, OscamPublisher, KeyPublisher, ScreenPublisher))

        if self.value("screenshot") == "off":
            # A disabled private image must not remain readable from broker retention.
            self.retract(self.topic("screen"))
        if not self.value("cam_telemetry"):
            self.retract(self.topic("cam"))
        if not self.value("oscam_telemetry"):
            self.retract(self.topic("oscam"))

    def _replace_publishers(self, classes, with_session_only=False):
        """Stop each of these publishers and start a new one under the open session.

        What a reload does for every publisher, done for these alone: the old one
        lets go of its hooks before the new one binds them, and a new one that
        does not start - switched off, or not possible here - is left out of the
        registry, as at a start. `with_session_only`: nothing at all without an
        enigma2 session, where a start registers no publisher either
        (`register_default_publishers`). The new ones that started, in order.
        """
        from .publishers import PUBLISHER_CLASSES

        if with_session_only and self.session is None:
            return []
        started = []
        for publisher_class in classes:
            name = publisher_class.name
            old = self.publisher(name)
            if old is not None:
                try:
                    old.stop()
                except Exception:
                    LOG.exception("stopping the %s publisher raised", name)
                self._publishers.remove(old)

            replacement = publisher_class(self)
            try:
                ready = replacement.start()
            except Exception:
                LOG.exception("the %s publisher could not restart", name)
                ready = False
            if ready:
                order = PUBLISHER_CLASSES.index(publisher_class)
                index = sum(
                    PUBLISHER_CLASSES.index(type(item)) < order
                    for item in self._publishers
                    if type(item) in PUBLISHER_CLASSES
                )
                self._publishers.insert(index, replacement)
                started.append(replacement)
        return started

    @property
    def state(self):
        if self._state_store is None:
            self._state_store = discovery.StateStore()
        return self._state_store

    # -------------------------------------------------------------------- topics --

    @property
    def base_topic(self):
        return (self.value("base_topic") or settings_module.DEFAULT_BASE_TOPIC).strip("/")

    @property
    def node_id(self):
        return (self.value("node_id") or "").strip()

    def topic(self, suffix):
        return self.base_topic + "/" + self.node_id + "/" + suffix

    @property
    def command_root(self):
        return self.topic("cmd")

    def command_name(self, topic):
        """`enigma2/<node>/cmd/ha_mode` -> `ha_mode`, and None for anything else."""
        prefix = self.command_root + "/"
        if not str(topic or "").startswith(prefix):
            return None
        return str(topic)[len(prefix):].strip("/") or None

    @property
    def build(self):
        """The build id of the code this process runs, or None for a copy nobody built."""
        return self._build

    @property
    def connected(self):
        return self.client is not None and self.client.connected

    # ------------------------------------------------------------------ lifecycle --

    def start(self):
        """Never raises. The graphical interface must come up regardless."""
        try:
            self._start()
        except Exception:
            self._stop_timers()
            LOG.exception("the bridge failed to start; the receiver is unaffected")
            self.idle_reason = "the bridge failed to start"
        return self

    def _start(self):
        if self._uninstaller.underway:
            # Once the removal has disconnected, `client` is None and a second
            # start would open a session under it. No caller is known to do
            # this; the failure path clears the phase before it reloads.
            LOG.warning("not starting: the plugin is removing itself")
            return
        if self.client is not None:
            # enigma2 can hand a plugin its session start more than once. The
            # session that is already open is the healthy one; opening a second
            # would strand the first one's network thread and its will.
            LOG.info("the bridge is already running; leaving the open session alone")
            return

        configure_logging(self.value("log_level"), self._log_path)
        # Before the provisioning file and before `enabled` (TRANSACTION.md, section 4): a
        # new release that is switched off still confirms to its update helper that it started.
        self._self_update.on_start()

        # Before anything connects: an installer may have written the broker in.
        settings_module.import_provisioning(self._provisioning_path, self.settings)
        configure_logging(self.value("log_level"), self._log_path)
        # The Extensions entry follows `menu_allowed` whether or not a session follows: an idle
        # plugin still has the entry the setting says, and says why when it is chosen.
        self._sync_menu_entry()

        self._ensure_identity()
        register_secret(self.value("password"))

        if not self.value("enabled"):
            self._idle("the plugin is switched off in its settings")
            return
        # A setting of the receiver's, not of the connection: honoured before
        # the broker is asked about, so a box with no broker yet still does what
        # its own setup screen says. Every start, and at a save that changes it
        # under an open session (`_apply_live`).
        wol.arm(self.settings)
        host = (self.value("host") or "").strip()
        if not host:
            self._idle("no broker address is configured")
            return
        if not self.node_id:
            self._idle("no node id could be derived")
            return

        broker = BrokerSettings(
            host=host,
            port=self.value("port"),
            tls=self.value("tls"),
            ca_file=self.value("ca_file"),
            username=self.value("username"),
            password=self.value("password"),
            client_id="mqttbridge-" + self.node_id,
        )
        self.client = MqttClient(
            broker,
            on_connect=self.on_connect,
            on_message=self.on_message,
            on_disconnect=self.on_disconnect,
            dispatcher=self._dispatcher,
            client_factory=self._client_factory,
        )
        if not self.client.usable:
            # No Twisted and no usable ePythonMessagePump. Running paho's
            # callbacks on its network thread would touch enigma2 from off the
            # main loop, so this image gets a plugin that loads and does nothing.
            self.client = None
            self._idle("this image offers no way to reach the main loop from a thread")
            return
        if self._loop_monitor is not None:
            self._loop_monitor.start()
        self._build_ticker.start(buildid.CHECK_MILLISECONDS)
        self._updates.start()
        self._will_topic = self.topic("availability")
        self._session_settings = self._connection_settings()
        self._applied_settings = self._settings_now()
        self.client.set_will(self._will_topic, OFFLINE, qos=WILL_QOS, retain=True)

        self._last_error_published = self.state.knows(self.topic("last_error"))
        self.register_default_publishers()
        self._start_publishers()
        self._uninstaller.probe()
        self._self_update.probe()

        self.idle_reason = None
        self.running = True
        LOG.info(
            "starting: ha_mode=%s plugin=%s capabilities=%d build=%s",
            self.value("ha_mode"),
            __version__,
            len(self.capabilities()),
            buildid.display_version(__version__, self._build),
        )
        self.client.start()

    def _retract_absent_pvr(self):
        """At a connect: take back the library's and timeshift's topics where they are gone.

        A library that is there retracts its own vanished folders when it publishes
        (`LibraryPublisher.retract_stale`). One that is not - no movie locations on this
        image now - leaves the earlier run's index and every folder topic to this.
        """
        from .library import FOLDER_PREFIX
        from .library import INDEX as LIBRARY_INDEX
        from .timeshift import TOPIC as TIMESHIFT_TOPIC

        library = self.publisher(LIBRARY_INDEX)
        if library is None:
            prefix = self.topic(FOLDER_PREFIX)
            index = self.topic(LIBRARY_INDEX)
            for topic in self.state.retained_topics:
                if topic == index or topic.startswith(prefix):
                    self.retract(topic)
        else:
            library.retract_stale()
        if self.publisher(TIMESHIFT_TOPIC) is None:
            topic = self.topic(TIMESHIFT_TOPIC)
            if self.state.knows(topic):
                self.retract(topic)

    def _sync_menu_entry(self):
        try:
            from .plugin import sync_menu_entry

            sync_menu_entry(bool(self.value("menu_allowed")))
        except Exception:
            LOG.exception("the menu's Extensions entry could not be updated")

    def _idle(self, reason):
        self._stop_timers()
        self.running = False
        self.idle_reason = reason
        LOG.warning("idle: %s", reason)

    def stop(self):
        """Say goodbye properly: a clean disconnect suppresses the will."""
        try:
            self.running = False
            self._uninstaller.abandon()
            self._self_update.abandon()
            self._stop_timers()
            if self.client is None:
                self._stop_publishers()
                return
            if self._self_update.silent:
                # ADR-0015, decision 5: a downgrade's retraction is done and nothing more
                # goes out. The clean disconnect keeps the will unsent; the release that
                # starts says `online`.
                LOG.info("not publishing offline: an update has retracted this node's topics")
            elif self.client.connected:
                # A list of choices answers `closed` before the `offline`.
                self.close_open_screens()
                # A change to `not_published` that was still waiting to be
                # said: the `info` left retained must not be the one before it.
                # Guarded by itself, because what follows is the `offline` and
                # the disconnect, and neither may depend on it.
                try:
                    self._say_not_published()
                except Exception:
                    LOG.exception("could not publish the info that was waiting")
                info = self.client.publish(
                    self.topic("availability"), OFFLINE, qos=STATE_QOS, retain=True
                )
                self.client.wait_for(info, SHUTDOWN_FLUSH_SECONDS)
            self._stop_publishers()
            self.client.stop()
            self.client = None
            self.state.save()
        except Exception:
            LOG.exception("shutting the bridge down raised; the receiver is unaffected")

    def _stop_publishers(self):
        """Every publisher lets go of its hooks, and the registry is emptied.

        🔴 Emptying the registry without this is how a receiver ends up with two
        of every listener. Publishers attach themselves to lists that belong to
        enigma2 - `session.nav.event`, the standby counter's notifiers, the
        action map - and those lists outlive the plugin's own objects. Dropping
        the registry on a settings save would leave the old listeners attached
        and add a second set beside them, once per save, until the box is
        restarted.
        """
        for publisher in list(self._publishers):
            try:
                publisher.stop()
            except Exception:
                LOG.exception("stopping the %s publisher raised", publisher.name)
        self._publishers = []

    def _stop_timers(self):
        """The session's own timers: the loop monitor, the build-on-disk check, the daily check."""
        if self._loop_monitor is not None:
            self._loop_monitor.stop()
        self._build_ticker.stop()
        self._updates.stop()
        self._not_published_ticker.stop()
        self._not_published_since = None

    def reload(self):
        """End the session and start a new one with the settings as they are now.

        A save on the receiver comes here only when it needs a new session - the
        connection changed, the plugin was switched off or on, or none was open
        (`apply_saved_settings`); an update's failure path and a removal that
        stopped come here too.

        🔴 The old session ends with a clean disconnect, and a clean disconnect
        is exactly what tells the broker to throw the will away. When the save
        changed the connection itself - see `_says_offline_on_reload` - the
        session therefore says `offline` first, as `stop` does. Without it the
        retained `availability` stays `online` from the old session, and if the
        new one never connects - a mistyped broker, a password that is now
        wrong, or the plugin switched off on the same screen - a consumer sees a
        receiver that is online with nothing connected, for as long as nobody
        looks. The new session's own `online` replaces it the moment it connects.

        Every other reload stays silent - a rename, or a reload asked for with
        nothing of the connection changed; an `offline` there would make the
        receiver unavailable for the seconds a reconnect takes, and re-fire every
        automation that watches it, for a change that did not touch the
        connection at all.

        Unlike `stop`, this does not wait for the publish to leave: the process
        goes on running, paho's network thread writes its queue in order and
        does not end before the queue is empty, so the `offline` reaches the
        socket ahead of the DISCONNECT - and a reload runs on enigma2's main
        thread, where waiting on a broker is what the user would feel.
        """
        try:
            self._stop_timers()
            if self.connected:
                # A list of choices answers `closed` on the session that is ending.
                self.close_open_screens()
                if self._will_topic == self.topic("availability"):
                    # What `stop` does, and for its reason: the new session may
                    # never connect. Not on a rename - the settings already
                    # carry the new name, and `info` under the old one is about
                    # to be retracted. Guarded by itself, as in `stop`: the old
                    # client's stop and the new session may not depend on it.
                    try:
                        self._say_not_published()
                    except Exception:
                        LOG.exception("could not publish the info that was waiting")
                self.retract_stale()
                if self._says_offline_on_reload():
                    self.client.publish(self._will_topic, OFFLINE, qos=STATE_QOS, retain=True)
            if self.client is not None:
                self.client.stop()
                self.client = None
            self._will_topic = None
            self._session_settings = None
            self._applied_settings = None
            self._stop_publishers()
            # The save may have renamed the node or narrowed what is published,
            # and the new session measures everything again.
            self._not_published = {}
            self._select_left_out = False
        except Exception:
            LOG.exception("could not shut the old session down cleanly")
        return self.start()

    def _connection_settings(self):
        """What the open session was built from, as the settings hold it now."""
        return {name: self.value(name) for name in CONNECTION_SETTING_NAMES}

    def _says_offline_on_reload(self):
        """Whether the session being replaced should publish `offline` first.

        Yes when the save switched the plugin off, or changed how the box
        reaches the broker - the new session may never connect, and nothing
        else would take the old `online` back. No when nothing of the
        connection changed, and no on a rename either: the node id and the base
        topic name the will's topic, the settings already carry the new name,
        and the old topic has just been retracted by `retract_stale`. An
        `offline` for the new name from the old session could reach the broker
        after the new session's `online` - they are two client ids, so the
        broker does not order them - and would then stay retained under a name
        that is live.
        """
        before = self._session_settings
        if before is None or self._will_topic is None:
            return False
        now = self._connection_settings()
        if any(before[name] != now[name] for name in IDENTITY_CONNECTION_SETTING_NAMES):
            return False
        if not self.value("enabled"):
            return True
        return before != now

    def _stale_topics(self):
        """Remembered topics outside this node's tree that this session will not publish.

        Outside the tree there are two kinds of topic the node owns under its
        current name: the announcement, and - in `discovery` mode - the Home
        Assistant discovery payloads for the current prefix, node id and
        capabilities. 🔴 Those have to be left alone here. This runs before the
        first publish of every connect and every reload, and an empty retained
        device payload deletes the device and all its entities in Home
        Assistant; the republish a moment later brings them back without the
        names, areas and dashboards they had. What is left over - an older
        prefix, an older node id, a mode that no longer publishes them, a
        trigger whose capability is gone - is stale, and is retracted.
        """
        root = self.base_topic + "/" + self.node_id + "/"
        current = {discovery.announcement_topic(self.node_id)}
        if self.value("ha_mode") == "discovery":
            current |= discovery.discovery_topics(
                self.discovery_prefix, self.node_id, self.capabilities()
            )
        return [
            topic
            for topic in self.state.retained_topics
            if not topic.startswith(root) and topic not in current
        ]

    def retract_stale(self):
        """Retract retained topics this node published under a name it no longer has.

        Renaming the node or the base topic orphans everything published under
        the old one: retained payloads nothing will ever update, and in Home
        Assistant a device that looks alive. The state file is what makes them
        findable at all, and it survives a restart - which is why this runs on
        every connect and not only from `reload`. The rename is just as likely
        to happen while the box is disconnected, or while the plugin is not even
        running, as it is to happen with a session open. What the session is
        about to publish again is not stale - see `_stale_topics`.
        """
        stale = self._stale_topics()
        if not stale or self.client is None or self._self_update.silent:
            return 0
        LOG.info("retracting %d retained topic(s) this node no longer owns", len(stale))
        for topic in stale:
            self.client.publish(topic, "", qos=STATE_QOS, retain=True)
            self.state.forget(topic)
            self._forget(topic)
            if topic == self._screenshot_topic:
                self._screenshot = None
        self.state.save()
        return len(stale)

    # ------------------------------------------------------------------ identity --

    def _ensure_identity(self):
        """Derive the node id and the device name once, then keep them forever."""
        changed = []
        if not self.node_id:
            derived = boxinfo.derive_node_id()
            self.set_value("node_id", derived)
            changed.append("node_id")
            LOG.info("derived node id %s", derived)
        if not (self.value("friendly_name") or "").strip():
            self.set_value("friendly_name", boxinfo.box_type())
            changed.append("friendly_name")
        if changed:
            self.save_settings()

    # ---------------------------------------------------------------- publishers --

    def register_publisher(self, publisher):
        if getattr(publisher, "bridge", None) is None:
            publisher.bridge = self
        self._publishers.append(publisher)
        return publisher

    def publisher(self, name):
        """One registered publisher by name, or None when it did not bind.

        Commands ask for the publisher of the state they are about to change,
        because a command is verified by reading the state back - and a state
        nothing publishes cannot be read back.
        """
        for publisher in self._publishers:
            if publisher.name == name:
                return publisher
        return None

    def register_default_publishers(self):
        """The feature areas of the contract, in the order `capabilities` lists them.

        Only when nothing has been registered by hand, and only with a session:
        every one of these hangs off `session.nav` or a screen, so a bridge
        built without one would register publishers that could only fail to
        start. A test that registers its own is left alone.
        """
        if self._publishers or self.session is None:
            return []
        from .publishers import default_publishers

        for publisher in default_publishers(self):
            self.register_publisher(publisher)
        return self._publishers

    def _start_publishers(self):
        for publisher in list(self._publishers):
            try:
                if not publisher.start():
                    if publisher.switched_off:
                        # The publisher has already said so in its own words,
                        # and it says it on the settings-change path too, where
                        # this loop does not run.
                        LOG.debug("%s did not start: switched off", publisher.name)
                    else:
                        LOG.warning("this image does not provide the %s hooks", publisher.name)
                    self._publishers.remove(publisher)
            except Exception:
                LOG.exception("the %s publisher could not start", publisher.name)
                self._publishers.remove(publisher)

    def capabilities(self):
        """What this box can actually do - never what the contract says it might.

        A name gets in here by a hook binding on *this* image. Consumers hide
        what is missing, so a capability claimed and not delivered is a dead
        entity in somebody's dashboard. Registered is not the same as bound:
        a publisher that is still waiting for a hook stays in the registry and
        out of this list until it has one - see `Publisher.claimed`.
        """
        names = list(CORE_CAPABILITIES)
        for publisher in self._publishers:
            if publisher.name and publisher.name not in names and publisher.claimed():
                names.append(publisher.name)
                for extra in publisher.extra_capabilities():
                    if extra not in names:
                        names.append(extra)
        if self.session is not None and MESSAGE_CAPABILITY not in names:
            from .osd import popups_available

            if popups_available():
                names.append(MESSAGE_CAPABILITY)
        if self._uninstaller.claimed:
            names.append(UNINSTALL_CAPABILITY)
        if self._self_update.claimed:
            names.append(SELF_UPDATE_CAPABILITY)
        names.append(COMMAND_ID_CAPABILITY)
        return names

    def announce_capabilities(self):
        """Say again what this box can do, after a late bind changed the answer.

        `info` and the announcement are published on connect, so a capability
        that appears a few seconds later - a hook that could only bind once
        enigma2 had built the screen behind it - would otherwise stay invisible
        until the next reconnect. The log gets the new count for the same
        reason: the start line counted what was bound by then. It gets it
        whether or not a session is up - the connect that follows carries the
        list - and only when the count is not the one last logged here since
        the start. A start is told by its client, which each start makes anew,
        so the first change after any start is logged.
        """
        count = len(self.capabilities())
        logged = self._capabilities_logged
        if logged is None or logged[0] is not self.client or logged[1] != count:
            self._capabilities_logged = (self.client, count)
            LOG.info("capabilities=%d now; the start line counted those bound by then", count)
        if not self.connected:
            return False
        info = self.build_info()
        self.publish_info(info)
        self.publish_announcement(info)
        self.publish_discovery(info)
        return True

    # -------------------------------------------------------------------- events --

    def on_connect(self):
        # This connection has not published `info` yet; until it has, nothing
        # below republishes it over a change to `not_published`.
        self._not_published_reported = None
        self._not_published_ticker.stop()
        self._not_published_since = None
        # First, before a single new payload: whatever this node published under
        # an older name is still on the broker and this is the first chance to
        # take it back.
        self.retract_stale()
        # Privacy switches also apply to retained data left by an earlier
        # process, including when they were changed on the receiver setup screen.
        if self.value("screenshot") == "off":
            self.retract(self.topic("screen"))
        if not self.value("cam_telemetry"):
            self.retract(self.topic("cam"))
        if not self.value("oscam_telemetry"):
            self.retract(self.topic("oscam"))
        # The standby workaround's count outlives the workaround on the broker.
        # A process that starts without it - or a save that switched it off
        # while there was no connection - comes here, and a retained `cec` left
        # behind would tell a consumer it is still at work.
        # Keyed on the publisher rather than the setting, because the capability
        # also goes when HDMI-CEC does.
        if self.publisher(CecPublisher.name) is None:
            self.retract(self.topic(CEC_TOPIC))
        # The stream area's topics outlive it the same way, and its list of
        # clients is one a consumer acts on: a client an earlier run listed
        # must not stay offered for stopping by a run that lists none. Keyed
        # on what bound - an image can have the server and not the listing.
        stream = self.publisher(StreamPublisher.name)
        if stream is None:
            self.retract(self.topic(STREAM_TOPIC))
        if stream is None or not stream.lists_clients():
            self.retract(self.topic(STREAM_CLIENTS_TOPIC))
        # The recording library and timeshift the same way: an earlier run's index, folders
        # and timeshift state are not this run's, where this run has none of its own.
        self._retract_absent_pvr()
        # And the refusal an earlier run left retained, here with the other
        # leftovers of an earlier process: before `online`, so that a consumer
        # which takes `online` for the start of this run never reads that
        # refusal as this run's, and before the state file is written at the
        # end of this connect, so that it is written without the topic. The
        # error this run brings to the connect is said at the other end of it,
        # after the snapshot it is about.
        self._clear_earlier_runs_error()
        # Every payload goes out on every connect, so what was published before
        # this connection is not what is on the broker now.
        self.forget_published()
        info = self.build_info()
        self.publish_raw(self.topic("availability"), ONLINE)
        self.publish_snapshot(info)
        # After the snapshot, which retracts what it measured itself: a topic
        # that outgrew the packet bound with no session open, and that no
        # snapshot carries.
        self._take_back_withheld()
        # The channel list walks its bouquets while it starts, before there is
        # a session, so this connect is the first chance to take back the list
        # of a bouquet that went while nothing was connected - or the plugin
        # was not running.
        self.sync_channel_slugs()
        if self.publisher("epg_grid") is None:
            # With a grid publisher this is its business, and it does it at the
            # end of every pass. Doing it here as well would retract each grid
            # on every connect and republish it a moment later, which a consumer
            # sees as the feature disappearing and coming back.
            self.sync_grid_slugs()
        self.publish_announcement(info)
        self.publish_discovery(info)
        self.client.subscribe(self.command_root + "/#", qos=COMMAND_QOS)
        # The signed release index, relayed by the companion integration to every
        # receiver on the broker, with internet or without. Retained, so a fresh
        # session is handed it at once; judged like any fetched index, and never
        # obeyed as a command.
        self.client.subscribe(RELEASE_INDEX_TOPIC, qos=COMMAND_QOS)
        # The companion integration's version, contract and plugin floor, retained: what
        # the rule of `update.available` and of `cmd/update` judges against once it is known.
        integration = self._self_update.integration_topic()
        if integration:
            self.client.subscribe(integration, qos=COMMAND_QOS)
        # The receiver menu and Home Assistant's status - only while `menu_allowed` is on, which
        # is when the menu publisher runs.
        menu = self.publisher("menu")
        if menu is not None:
            menu.subscribe(self.client)
            menu.connection_changed()
        self._lists_connection_changed()
        self.state.save()
        if self._pending_error is not None:
            # Said once, so only a publish the client took counts as said: a
            # connect whose socket was gone again leaves it for the next one.
            # Nothing else would say it - the marker it was read from is gone.
            # With the id of the command it is about, when that carried one.
            command, message, *asked_by = self._pending_error
            command_id = asked_by[0] if asked_by else None
            if accepted(self.publish_last_error(command, message, command_id=command_id)):
                self._pending_error = None

    def on_message(self, topic, payload, retain):
        if self._uninstaller.closed:
            # Asked first: from here on nothing may re-create a topic.
            LOG.info("discarding a message on %s: the plugin is removing itself", topic)
            return
        if topic == self._self_update.integration_topic():
            self._self_update.on_integration(payload)
            return
        menu = self.publisher("menu")
        if menu is not None and menu.handles(topic):
            menu.on_message(topic, payload, retain)
            return
        if topic == RELEASE_INDEX_TOPIC:
            if self._self_update.closed:
                LOG.info("not judging a relayed index now: an update is being applied")
                return
            self._updates.on_release_index(payload, retain)
            return
        self._commands.handle(topic, payload, retain)

    def on_disconnect(self, reason_code):
        # The menu greys itself without a broker, and an open one says so at once.
        menu = self.publisher("menu")
        if menu is not None:
            menu.connection_changed()
        # A list's answer the broker had not taken is never sent after the reconnect.
        self._lists_connection_changed()

    def _lists_connection_changed(self):
        lists = self.publisher("list")
        if lists is not None:
            lists.connection_changed()

    def close_open_screens(self):
        """Before the session goes: a screen that owes Home Assistant an answer gives it now.

        A list of choices on the television answers `closed` when the plugin stops
        (`choicelist.py`), and only an open session can carry that. `stop`, `reload` and the
        uninstall ask for it while theirs is still up; every publisher stops later anyway.
        """
        for publisher in list(self._publishers):
            closing = getattr(publisher, "before_stop", None)
            if closing is None:
                continue
            try:
                closing()
            except Exception:
                LOG.exception("the %s publisher could not close its screens", publisher.name)

    # ----------------------------------------------------------------- publishing --

    def publish_raw(self, topic, payload, retain=True, change_key=None):
        if self.client is None or self._uninstaller.closed or self._self_update.silent:
            # Closed: a publisher's timer or event that fires after the
            # retraction would re-create a retained topic for good.
            return None
        size = _oversize(topic, payload)
        if size:
            return self._withhold(topic, size, retain)
        info = self.client.publish(topic, payload, qos=STATE_QOS, retain=retain)
        if retain:
            self.state.remember(topic)
            # What is remembered is what the next comparison will be made
            # against - never the bytes that went out, when the two differ. A
            # snapshot publish and a state publish reach the same topic, and if
            # they recorded it two different ways the first publish after every
            # connect would look like a change.
            self._published[topic] = payload if change_key is None else change_key
            self._last_json.pop(topic, None)
            if len(self._raw_topics) < REMEMBERED_TOPICS:
                self._raw_topics.add(topic)
            if topic == self.topic("screen") and payload:
                self._record_screenshot(payload)
        if self._not_published.pop(topic, None) is not None:
            # It fits again, so it is on the broker and off the list.
            self._report_not_published()
        return info

    def publish_event(self, suffix, payload, qos=COMMAND_QOS):
        """An event the receiver raises: JSON, never retained, at `qos`. The client's answer.

        None when nothing was handed to the client.

        Only on an open session, and never while the plugin removes itself or an update has
        taken the node's topics back - as for every other publish. Held to the packet bound like
        any payload, although the one event published this way, `menu_action`, is a few hundred
        bytes by construction.
        """
        if self.client is None or not self.connected:
            return None
        if self._uninstaller.closed or self._self_update.silent:
            return None
        topic = self.topic(suffix)
        encoded = _encoded(payload)
        size = _oversize(topic, encoded)
        if size:
            return self._withhold(topic, size, retain=False)
        # Transient: one the broker has not acknowledged when the connection goes is dropped at
        # the next connect, before the client would send it again.
        return self.client.publish(topic, encoded, qos=qos, retain=False, transient=True)

    def withdraw_event(self, info):
        """Take an event that was not acknowledged back out of the client's queue.

        For an event that is true only when it was raised: without this, the client would send
        it again after the next connect (`mqttclient.withdraw_publish`). Whether it was taken.
        """
        client = self.client
        withdraw = getattr(client, "withdraw", None) if client is not None else None
        return bool(withdraw(info)) if withdraw is not None else False

    def _topic_label(self, topic):
        """A topic as `info.not_published` and the log name it: relative to the node's tree."""
        root = self.base_topic + "/" + self.node_id + "/"
        return topic[len(root):] if topic.startswith(root) else topic

    def not_published(self):
        """`info.not_published`: what was too big to send, sorted by topic."""
        return sorted(
            (
                {"topic": self._topic_label(topic), "bytes": size, "limit": MAX_PACKET_BYTES}
                for topic, size in self._not_published.items()
            ),
            key=lambda entry: entry["topic"],
        )

    def _withhold(self, topic, size, retain=True):
        """Keep a payload whose packet is over `MAX_PACKET_BYTES` off the wire.

        Handing it to the client is what must not happen: the broker answers
        an oversize packet by closing the connection, and every connect would
        send it again. What a consumer gets instead is the topic named in
        `info.not_published`, and one line in the log - when the topic becomes
        withheld, not per attempt and not per size: the snapshot attempts it on
        every connect, and a grid that stays too big has another size every
        time it is built. The size kept is the first one measured.

        A copy this node published earlier under its own tree, when the payload
        was smaller, is retracted: left retained it would go on saying it is the
        current state. A topic that was never published gets nothing at all.

        Outside the tree nothing is retracted. Those are the announcement and
        the Home Assistant discovery payloads, and an empty retained device
        payload deletes the device and all its entities there; a select that
        keeps the options it had is the lesser harm.

        An event - a publish that is not retained - is dropped and logged, and
        that is all: it has no retained copy, and is not a topic a consumer
        could find missing.
        """
        if not retain or topic not in self._not_published:
            LOG.warning(
                "not publishing %s: %d bytes is over the %d byte packet limit",
                self._topic_label(topic), size, MAX_PACKET_BYTES,
            )
        if not retain:
            return None
        self._not_published.setdefault(topic, size)
        if self._topic_label(topic) != topic:
            # Under the node's own tree.
            self._take_back(topic)
            self._published.pop(topic, None)
            self._forget(topic)
        if topic != self.topic("info"):
            # `info` cannot say that `info` is missing: the publish it would
            # wait for is the one that was just withheld, every time.
            self._report_not_published()
        return None

    def withhold_state(self, suffix, size):
        """Withhold a state topic its publisher already knows is over the bound.

        For a payload measured when it was built and not changed since: the
        snapshot leaves it out, and this does what `publish_raw` would have
        done had it been handed the payload and measured it again - under the
        same conditions, and with the size that measurement would have found.
        It spares a connect the encoding of megabytes that cannot be sent.
        """
        if self.client is None or self._uninstaller.closed or self._self_update.silent:
            return None
        return self._withhold(self.topic(suffix), size)

    def _take_back(self, topic):
        """Retract the retained copy of a withheld topic - once the broker can be told.

        Forgetting the topic is only true when the retraction was sent. A
        publisher that publishes while it starts does so before the session
        exists, and a timer does not stop for an outage: retracting then would
        send nothing and still forget the topic, and the copy an earlier process
        left would stay on the broker with nothing left that knows of it. So
        without a session the state file keeps the topic, and the connect that
        follows retracts it (`on_connect`).

        A session that looks open may not be: the socket goes before the
        disconnect reaches the main thread, and until it does the client answers
        a publish with "no connection". That retraction was not sent either, so
        the topic is forgotten only when the client took the publish.

        Nothing is sent while the plugin removes itself or an update has taken
        this node's topics back, as for any other publish (`publish_raw`).
        """
        if self._uninstaller.closed or self._self_update.silent:
            return False
        if not self.connected or not self.state.knows(topic):
            return False
        if not accepted(self.client.publish(topic, "", qos=STATE_QOS, retain=True)):
            return False
        self.state.forget(topic)
        return True

    def _take_back_withheld(self):
        """On a connect: retract what was withheld while there was no session to say so."""
        for topic in sorted(self._not_published):
            if self._topic_label(topic) != topic:
                self._take_back(topic)

    def _report_not_published(self):
        """See that `info` is published again when `not_published` is not what it last said.

        Only on an open session that has published `info` already: before that,
        the `info` about to go out carries the list anyway.

        Not at once. The list changes in bursts, so the publish waits
        `NOT_PUBLISHED_SETTLE_MILLISECONDS` on a timer and every further change
        starts that wait again - but never past `NOT_PUBLISHED_LATEST_SECONDS`
        after the first one, so a list that kept changing could not keep `info`
        back for good. What goes out is the list as it stands when the timer
        fires (`_say_not_published`).
        """
        if self._not_published_reported is None or not self.connected:
            return False
        if self.not_published() == self._not_published_reported:
            # Back to what `info` says. A wait already running finds that out
            # for itself.
            return False
        now = time.monotonic()
        if self._not_published_since is None:
            self._not_published_since = now
        left = NOT_PUBLISHED_LATEST_SECONDS - (now - self._not_published_since)
        wait = max(0, min(NOT_PUBLISHED_SETTLE_MILLISECONDS, int(left * 1000)))
        if not self._not_published_ticker.start(wait, True):
            # No timer on this image: said now, as it was before there was a wait.
            return self._say_not_published()
        return True

    def _say_not_published(self):
        """Publish `info` when `not_published` is still not what it last said.

        The timer's callback, and what `stop` and `reload` call so that a change
        still waiting is not lost with the session. It cannot loop: an `info`
        that went out is recorded as said (`publish_info`), and one that did
        not go out starts no wait of its own (`_withhold`).
        """
        self._not_published_since = None
        if self._not_published_reported is None or not self.connected:
            # The connect that follows publishes `info` with the list in it.
            return False
        if self.not_published() == self._not_published_reported:
            return False
        self.publish_info()
        return True

    def _record_screenshot(self, payload):
        """Remember the picture just sent on `screen`, with the time it was taken.

        The time is the publisher's - when `grab` finished - so a snapshot that
        republishes an older picture keeps that picture's time.
        """
        publisher = self.publisher("screenshot")
        taken = getattr(publisher, "completed_at", None) if publisher is not None else None
        self._screenshot = (payload, taken if taken is not None else time.time())
        self._screenshot_topic = self.topic("screen")

    def last_screenshot(self):
        """`(jpeg bytes, completed_at)` of the last picture put on `screen`, or None.

        Only while `screen` is still the topic it went out on: after a rename of
        the node or the base topic the old picture is somebody else's retained
        topic, and is retracted as such.
        """
        if self._screenshot is None or self._screenshot_topic != self.topic("screen"):
            return None
        return self._screenshot

    def measure(self, suffix, payload):
        """`(encoded, size)` for a state topic's payload, without publishing anything.

        `size` is `_oversize`'s answer - the bytes of the packet when that is
        over the bound, else 0 - for a publisher that has something smaller to
        send instead: the channel list without its lists, a grid with fewer
        events. `encoded` is the JSON that was measured, handed back so that
        the publish that follows does not build it a second time.
        """
        encoded = _encoded(payload)
        return encoded, _oversize(self.topic(suffix), encoded)

    def encode(self, value):
        """The canonical JSON for a value, for a publisher that builds a payload in parts."""
        return _encoded(value)

    def exceeds(self, suffix, least):
        """Whether a payload of at least `least` bytes is certainly over the bound here.

        For a publisher that can put a floor under a payload's size without
        encoding it, and so need not encode what cannot fit. It only ever says
        "too big": that something fits is `measure`'s to say.
        """
        topic = self.topic(suffix)
        return PACKET_OVERHEAD_BYTES + len(topic.encode("utf-8")) + least > MAX_PACKET_BYTES

    def publish_json(self, topic, payload, retain=True, volatile=(), encoded=None,
                     change_key=None):
        if encoded is None:
            encoded = _encoded(payload)
        if change_key is None:
            change_key = _change_key(encoded, payload, volatile)
        info = self.publish_raw(topic, encoded, retain=retain, change_key=change_key)
        if retain and self.client is not None and topic not in self._not_published:
            self._remember(topic, encoded)
        return info

    def forget_published(self):
        """Forget what was published, so the next publish goes out regardless.

        Used wherever the broker's copy stops being what this process last sent
        it - a new connection, and a reset.
        """
        self._published = {}

    def publish_state(self, suffix, payload, raw=False, retain=True, volatile=(), encoded=None,
                      change_key=None):
        """A feature area's state topic - published only when it has changed.

        `sort_keys` in `_encoded` is what makes the comparison meaningful: two
        dictionaries built in a different order encode to the same bytes, so
        „changed" means the box changed, not that the code walked it differently.
        `volatile` is that argument carried one step further, and it is the
        publisher owning the topic that names the fields - so a reader sees at
        the call site which topic tolerates what, rather than finding a list of
        exceptions here.
        A topic that is not retained (`key`) is never compared - every press is
        an event, including the same press twice.
        `encoded` is the payload's JSON when the caller measured it first
        (`measure`); it is then not built again here. `change_key` is what the
        comparison is made on when the publisher has one of its own
        (`Publisher.prepared`), which saves encoding the payload a second time
        without its stamps.
        """
        topic = self.topic(suffix)
        if raw:
            encoded = payload
        elif encoded is None:
            encoded = _encoded(payload)
        if change_key is None:
            change_key = _change_key(encoded, payload, volatile)
        if retain and self._published.get(topic) == change_key:
            return None
        info = self.publish_raw(topic, encoded, retain=retain, change_key=change_key)
        if not raw and retain and self.client is not None and topic not in self._not_published:
            self._remember(topic, encoded)
        return info

    def retract(self, topic):
        if topic == self.topic("screen"):
            # Whether or not the broker can be told: switching screenshots off
            # means the page must not keep showing the last one either.
            self._screenshot = None
        if self.client is None or self._uninstaller.closed or self._self_update.silent:
            return None
        info = self.client.publish(topic, "", qos=STATE_QOS, retain=True)
        self.state.forget(topic)
        self._published.pop(topic, None)
        self._forget(topic)
        if self._not_published.pop(topic, None) is not None:
            # Taken back on purpose is not "too big to send" any more.
            self._report_not_published()
        return info

    def build_report(self):
        """`info.build`, with the file on disk read now."""
        return buildid.report(self._build, buildid.read(self._build_path))

    def check_build_on_disk(self):
        """Publish `info` again when the build on disk is not the one it last reported.

        Runs every ten minutes, and is what an install on the receiver calls when
        it has replaced the files: until the interface restarts, the receiver
        runs one build and has another on disk, and a consumer deciding whether
        to offer an update needs to know both. Says so only when it changed,
        and only on an open session - a connect publishes `info` anyway.
        """
        if not self.connected:
            return False
        if self.build_report() == self._build_reported:
            return False
        info = self.build_info()
        if info["build"] != self._build_logged:
            # Once for each build: while the publish is refused - an update
            # that has gone silent - this is reached at every check.
            self._build_logged = info["build"]
            LOG.info("the build on disk changed: on_disk=%s", info["build"]["on_disk"] or "-")
        self.publish_info(info)
        return True

    def publish_info(self, info=None):
        """Publish `info`, and record what it said - here, and nowhere else.

        `check_build_on_disk` and `_report_not_published` know whether there is
        news by comparing with what `info` last said: the build on disk and
        the list of withheld topics. That is recorded where `info` goes out,
        from the payload that went out, and only when the client took it. A
        caller that builds an `info` for something else - the announcement,
        a measurement - therefore cannot make a change look as if it had been
        said, and neither can a publish that was refused.
        """
        if info is None:
            info = self.build_info()
        sent = self.publish_json(self.topic("info"), info)
        if accepted(sent):
            self._build_reported = info.get("build")
            self._not_published_reported = info.get("not_published")
        return sent

    def build_info(self):
        """`info` as it stands now. It reads and records nothing (`publish_info`)."""
        build = self.build_report()
        not_published = self.not_published()
        info = {
            "image": boxinfo.image_version(),
            "enigma": boxinfo.enigma_version(),
            "plugin": __version__,
            "build": build,
            "contract": CONTRACT,
            "boxtype": boxinfo.box_type(),
            "mac": boxinfo.mac_address(),
            "ip": boxinfo.local_ip(self.value("host")),
            "uptime": boxinfo.uptime_seconds(),
            # Read from the image at every publish, never from what `wol_arm`
            # asked for - the image's switch can be changed in its own menu.
            "wol": wol.report(),
            "ha_mode": self.value("ha_mode"),
            "settings": self.published_settings(),
            "capabilities": self.capabilities(),
            # Which screen the receiver menu uses and which key opens it; null without the menu.
            "menu": self._menu_info(),
            # Whether the image's trash is on - what a delete of a recording moves into -
            # or null where the image has none. Read at every publish: it is the image's
            # own setting, changed in its own menu.
            "recording_trash": self._recording_trash(),
            # Empty on nearly every receiver: the retained topics a payload was
            # too big for, which are therefore not on the broker (`_withhold`).
            "not_published": not_published,
        }
        lists = self._list_info()
        if lists is not None:
            # Which screen a list of choices is shown with; absent, not null, without `list`.
            info["list"] = lists
        return info

    def _list_info(self):
        lists = self.publisher("list")
        if lists is None or not lists.claimed():
            return None
        try:
            return lists.info()
        except Exception:
            LOG.exception("info.list could not be read")
            return None

    def _recording_trash(self):
        if self.session is None:
            return None
        try:
            from .library import trash_state

            return trash_state()
        except Exception:
            LOG.exception("info.recording_trash could not be read")
            return None

    def _menu_info(self):
        menu = self.publisher("menu")
        if menu is None or not menu.claimed():
            return None
        try:
            return menu.info()
        except Exception:
            LOG.exception("info.menu could not be read")
            return None

    def publish_snapshot(self, info=None):
        """Everything this node knows, as a consumer would want it on subscribe."""
        snapshot_started = time.monotonic()
        topic_count = 1
        self.publish_info(info)
        for publisher in self._publishers:
            publisher_started = time.monotonic()
            published = 0
            try:
                raw = getattr(publisher, "raw", ())
                volatile = getattr(publisher, "volatile", ())
                prepared = getattr(publisher, "prepared", None)
                for suffix, payload in publisher.snapshot().items():
                    if suffix in raw:
                        self.publish_raw(self.topic(suffix), payload)
                    else:
                        # The JSON and the key a publisher holds already are
                        # the ones a state publish would use, so what this
                        # records as sent is what the next one is judged by.
                        encoded, key = prepared(suffix, payload) if prepared else (None, None)
                        self.publish_json(self.topic(suffix), payload, volatile=volatile,
                                          encoded=encoded, change_key=key)
                    published += 1
                    topic_count += 1
                # What the publisher measured over the bound when it built it,
                # and left out above: withheld as if it had been measured here.
                too_big = getattr(publisher, "too_big", None)
                for suffix, size in (too_big() if too_big else {}).items():
                    self.withhold_state(suffix, size)
            except Exception:
                LOG.exception("the %s publisher could not produce a snapshot", publisher.name)
            finally:
                elapsed = time.monotonic() - publisher_started
                if elapsed >= SLOW_SNAPSHOT_PUBLISHER_SECONDS:
                    LOG.warning("slow snapshot publisher=%s elapsed_ms=%d topics=%d",
                                publisher.name, int(elapsed * 1000), published)
        # Not a publisher: `update` is no feature area of the image and claims no
        # capability. What it says comes from the release index, on every box.
        try:
            self.publish_json(self.topic(UPDATE_SUFFIX), self._updates.payload(),
                              volatile=UPDATE_VOLATILE)
            topic_count += 1
        except Exception:
            LOG.exception("the update check could not produce a snapshot")
        elapsed = time.monotonic() - snapshot_started
        LOG.info("snapshot complete elapsed_ms=%d topics=%d", int(elapsed * 1000), topic_count)
        if elapsed >= SLOW_SNAPSHOT_TOTAL_SECONDS:
            LOG.warning("slow snapshot total elapsed_ms=%d topics=%d",
                        int(elapsed * 1000), topic_count)

    def publish_announcement(self, info=None):
        topic = discovery.announcement_topic(self.node_id)
        if self.value("ha_mode") == "off":
            LOG.debug("ha_mode is off; retracting the announcement")
            self.retract(topic)
            return
        payload = discovery.build_announcement(
            info if info is not None else self.build_info(),
            self.node_id,
            self.value("friendly_name"),
            self.base_topic,
        )
        self.publish_json(topic, payload)

    @property
    def discovery_prefix(self):
        return (
            self.value("ha_discovery_prefix") or settings_module.DEFAULT_DISCOVERY_PREFIX
        ).strip("/")

    def channel_options(self):
        """The channel names a `select` entity offers, in bouquet order.

        Deduplicated by name, because the options of a select are names and
        `cmd/zap` by name refuses a name that is not unique: offering the same
        „Sport" twice would be offering an option that can only fail.
        """
        channels = self.publisher("channels")
        if channels is None:
            return []
        names = []
        seen = set()
        for bouquet in channels.bouquets:
            for channel in bouquet.get("channels") or []:
                name = (channel.get("name") or "").strip()
                if name and name not in seen:
                    seen.add(name)
                    names.append(name)
        return names

    def _discovery_components(self, info):
        """`(components, encoded)` for the Home Assistant discovery payloads, as they stand now.

        `components` is {topic: payload}; `encoded` holds the JSON of the device
        payload, which was built to be measured and need not be built again.

        The channel select is the one component that grows with the receiver:
        its options are every channel name. When the device payload with it
        would be over the packet bound, the payload is built without it - which
        costs one entity, where a payload that is not sent costs a first install
        the whole device. A select announced earlier is then in `previous` and
        absent here, so the builder writes its removal, as for any component
        that is no longer announced, and it comes back the same way once the
        names fit.
        """
        topic = discovery.device_topic(self.discovery_prefix, self.node_id)
        options = self.channel_options()
        components = self._build_discovery(info, options)
        encoded = {}
        left_out = False
        if topic in components:
            encoded[topic] = _encoded(components[topic])
            if options and _oversize(topic, encoded[topic]):
                components = self._build_discovery(info, ())
                encoded[topic] = _encoded(components[topic])
                # Too big even so: the smaller payload is the one withheld,
                # and the select has not been left out of anything sent.
                left_out = not _oversize(topic, encoded[topic])
        if left_out and not self._select_left_out:
            LOG.warning(
                "the channel select is left out of the discovery payload: with %d channel"
                " name(s) it would be over the %d byte packet limit",
                len(options), MAX_PACKET_BYTES,
            )
        self._select_left_out = left_out
        return components, encoded

    def _build_discovery(self, info, channel_options):
        return discovery.build_discovery_components(
            self.node_id,
            self.value("friendly_name"),
            self.base_topic,
            info,
            prefix=self.discovery_prefix,
            channel_options=channel_options,
            # From the same payload the announcement carries, so what is
            # announced and what is published cannot disagree about it.
            deep_standby_allowed=bool(info.get("settings", {}).get("deep_standby_allowed")),
            softcam_restart_allowed=bool(
                info.get("settings", {}).get("softcam_restart_allowed")
            ),
            epg_import_allowed=bool(info.get("settings", {}).get("epg_import_allowed")),
            previous=self.state.component_keys,
        )

    def _discovery_too_big(self):
        """The discovery topics whose payload, built now, would not be sent for its size."""
        if self.value("ha_mode") != "discovery":
            return set()
        components, encoded = self._discovery_components(self.build_info())
        return {
            topic for topic, payload in components.items()
            if _oversize(topic, encoded.get(topic) or _encoded(payload))
        }

    def publish_discovery(self, info=None):
        if self.value("ha_mode") != "discovery":
            return
        if info is None:
            info = self.build_info()
        components, encoded = self._discovery_components(info)
        if not components:
            LOG.debug("this build publishes no Home Assistant discovery payloads")
            return
        for topic, payload in sorted(components.items()):
            self.publish_json(topic, payload, encoded=encoded.get(topic))
        self.state.set_components(sorted(components))
        device_topic = discovery.device_topic(self.discovery_prefix, self.node_id)
        if device_topic in self._not_published:
            # Not sent, so what Home Assistant holds is still the payload before
            # it. Recording this one's components would forget those it dropped,
            # and a component nobody remembers is never removed by name.
            return
        self.state.set_component_keys(discovery.component_platforms(components.get(device_topic)))

    def sync_grid_slugs(self):
        """Retract the EPG grid of every bouquet that is no longer configured.

        A bouquet that was renamed is two things at once: a new slug nobody has
        published yet and an old slug nothing will ever update again. The second
        one is the retained ghost, and the state file is what makes it findable
        - including from a process that was restarted between the rename and
        now. Called with no grid publisher at all, this retracts the lot, which
        is what turning `epg_grid_events` down to `0` has to mean.
        """
        grid = self.publisher("epg_grid")
        published = list(getattr(grid, "published_slugs", [])) if grid is not None else []
        stale = [slug for slug in self.state.grid_slugs if slug not in published]
        for slug in stale:
            LOG.info("retracting the EPG grid of a bouquet that is no longer configured: %s", slug)
            self.retract(self.topic("epg_grid/" + slug))
        self.state.set_grid_slugs(published)
        self.state.save()
        return len(stale)

    def sync_channel_slugs(self):
        """Retract the channel list of every bouquet that is no longer configured.

        `channels/<bouquet_slug>` sets the trap `epg_grid/<bouquet_slug>` sets,
        and the answer is the same: the state file knows the slugs, so a bouquet
        renamed, removed or left out of `bouquets_for_select` is found from a
        process restarted since. With no channel list at all, this retracts the
        lot.

        Only on an open session, and that is where it differs from the grid.
        The channel list walks its bouquets while it starts, before the client
        has connected; a retraction then reaches nobody, and forgetting the slug
        there would leave the topic on the broker with nothing that knows of
        it. The connect that follows calls this again.
        """
        if not self.connected:
            return 0
        channels = self.publisher("channels")
        published = list(getattr(channels, "published_slugs", [])) if channels is not None else []
        stale = [slug for slug in self.state.channel_slugs if slug not in published]
        for slug in stale:
            LOG.info(
                "retracting the channel list of a bouquet that is no longer configured: %s", slug
            )
            self.retract(self.topic("channels/" + slug))
        index = self.topic("bouquets")
        if channels is None and self.state.knows(index):
            # The index of topics that have all just gone.
            self.retract(index)
        self.state.set_channel_slugs(published)
        self.state.save()
        return len(stale)

    def retract_discovery(self):
        topics = self.state.components
        if not topics:
            return 0
        LOG.info("retracting %d Home Assistant discovery payload(s)", len(topics))
        for topic in topics:
            self.retract(topic)
        self.state.set_components([])
        # Nothing is announced any more, so nothing is left to remove by name.
        self.state.set_component_keys({})
        return len(topics)

    # ------------------------------------------------------------------ commands --

    def publish_last_error(self, command, message, reason=None, command_id=None):
        """`last_error`; `reason` is the optional stable code of a handler that defines one.

        Absent, not null, when there is none: the payload of every other
        refusal stays exactly what it was before the field existed.

        `command_id` is the id the refused command carried, said back as `id`
        and absent in the same way. It is never taken from the command being
        handled now: the caller passes the id of the command the refusal
        belongs to, which for a refusal published later is another one. Held
        to the id's rule here once more, because this is where it reaches the
        broker - and an id carried across a restart was read from a file.

        The sentence is made sendable first (`_sendable`): a refusal that
        cannot be encoded would be an exception here and no refusal at all.
        """
        payload = self._last_error_payload(command, message, reason, command_id)
        info = self.publish_json(self.topic("last_error"), payload)
        self._last_error_published = True
        return info

    def _last_error_payload(self, command, message, reason=None, command_id=None):
        """`last_error`'s payload, and its line in the log."""
        if reason is None:
            reason = getattr(message, "reason", None)
        if isinstance(message, str):
            message = _sendable(message)
        payload = {
            "cmd": _capped(command, LAST_ERROR_CMD_LIMIT),
            "error": message,
            "ts": int(time.time()),
        }
        if reason:
            payload["reason"] = str(reason)
        command_id = clean_id(command_id)
        if command_id is not None:
            payload["id"] = command_id
            LOG.warning("cmd/%s (id %s) refused: %s", payload["cmd"], command_id, message)
        else:
            LOG.warning("cmd/%s refused: %s", payload["cmd"], message)
        return payload

    def say_refusal_unretained(self, command, message, command_id=None):
        """A refusal on `last_error` while an update has made the plugin silent.

        From a downgrade's retraction on nothing is published (`selfupdate.py`), and a retained
        `last_error` now would outlive the retraction that took the topic back. A command whose
        sender waits for its answer - a list of choices - is refused all the same: once, **not
        retained**, at QoS 1, on the open session only, and never remembered as published.
        """
        payload = self._last_error_payload(command, message, command_id=command_id)
        if self.client is None or not self.connected or self._uninstaller.closed:
            return None
        return self.client.publish(self.topic("last_error"), _encoded(payload), qos=COMMAND_QOS,
                                   retain=False, transient=True)

    def clear_last_error(self):
        if not self._last_error_published:
            return False
        return self._retract_last_error()

    def _retract_last_error(self):
        """The empty retained payload to `last_error`; whether the client took it.

        Forgetting the error is only true when the retraction was sent
        (`_take_back` has the same rule, for the same reason): a session that
        looks open may have lost its socket already, and the client then
        answers "no connection". Forgetting there would leave the refusal on
        the broker with nothing here that knows of it - not the state file, so
        not the next start either, and not the next command that succeeds. So
        without an accepted publish everything stays as it was, and whoever
        clears next sends it again.

        Nothing is sent while the plugin removes itself or an update has taken
        this node's topics back, as for any other publish (`publish_raw`).
        """
        topic = self.topic("last_error")
        if self.client is None or self._uninstaller.closed or self._self_update.silent:
            return False
        if not accepted(self.client.publish(topic, "", qos=STATE_QOS, retain=True)):
            return False
        self.state.forget(topic)
        self._published.pop(topic, None)
        self._forget(topic)
        self._last_error_published = False
        return True

    def _clear_earlier_runs_error(self):
        """Take back the `last_error` an earlier run left retained. Whether it did.

        A retained refusal outlives the process that published it: after an
        interface restart, a reinstall or an update the broker still holds it,
        and it then describes a command of a run that is over - until some
        command succeeds, which on a receiver nobody commands is never. So the
        first connect of a process clears it. The state file is how this
        process knows there is one (`_start`).

        Only the first connect. A reconnect is the same run, whose refusal has
        to survive a broker outage, and so is the session a settings save or a
        failed removal opens (`reload`). And not when this run has an error of
        its own to say at that connect - how an update ended, read at the start
        (`selfupdate.py`): that one is published a few lines on and replaces the
        earlier run's, so emptying the topic first would only be a second
        message about nothing.

        A refusal this process made before it had a session - a command from
        the page, with the broker away - was not sent, and goes the same way:
        `last_error()` is what stands on the broker.

        Nor while the last update's record says the receiver still needs
        somebody: after a restore that did not complete the earlier run's
        sentence is "install the plugin again", and restarting the interface
        has not done that (`SelfUpdater.needs_reinstall`). It stays until a
        command succeeds or `cmd/clear_error` takes it back, as it did before
        this clearing existed.

        The connect counts as the first one until the question is settled:
        answered with "nothing to clear", or with a retraction the client took.
        A connect whose socket was gone again before the retraction could be
        handed over settles nothing, and the next one asks again.
        """
        if not self._first_connect:
            return False
        if self._pending_error is not None or not self._last_error_published:
            self._first_connect = False
            return False
        if self._self_update.needs_reinstall():
            self._first_connect = False
            LOG.info("keeping the last_error an earlier run left: the last update's record "
                     "says the plugin has to be installed again")
            return False
        if not self._retract_last_error():
            return False
        self._first_connect = False
        LOG.info("clearing the last_error an earlier run left retained")
        return True

    def retract_last_error(self):
        """`cmd/clear_error`: the retraction, whether or not this process knows of an error.

        `clear_last_error` sends nothing when no error is known here. That is
        right after every other command and wrong for this one: the state file
        is not written at every refusal, so an interface that was killed before
        the next write leaves a retained refusal nothing here knows of, and this
        command is how somebody takes it back. Whether the client took the
        retraction; when it did not, nothing is forgotten (`_retract_last_error`).
        """
        return self._retract_last_error()

    def set_ha_mode(self, mode):
        """The republished `info` is the acknowledgement; there is no ack topic."""
        previous = self.value("ha_mode")
        if mode != previous:
            self.set_value("ha_mode", mode)
            self.save_settings()
            LOG.info("ha_mode %s -> %s", previous, mode)
        self._mark_applied(("ha_mode",))
        if mode != "discovery":
            self.retract_discovery()
        info = self.build_info()
        self.publish_info(info)
        self.publish_announcement(info)
        self.publish_discovery(info)
        # Which releases are compatible depends on whether an integration is in use.
        self._updates.publish()
        self.state.save()

    def reset_retained(self):
        """Retract everything this node owns, then put it straight back.

        A reset is a cleanup, not a factory reset: settings are untouched and the
        snapshot returns immediately, so it is safe to run at any time and it is
        the documented step before uninstalling.

        Returns how many topics it retracted, which is the number its log line
        gives: a discovery payload left in place is not one of them, and
        without a session it is none.
        """
        topics = self.state.retained_topics
        # The one thing a reset does not take back: a discovery payload it could
        # not put back, because what would replace it is over the packet bound.
        # Emptied, it deletes the device and its entities in Home Assistant, and
        # nothing would follow. It stays, and stays remembered - with the
        # components it announced, which is what is still on the broker.
        too_big = self._discovery_too_big()
        kept = [topic for topic in topics if topic in too_big]
        announced = self.state.component_keys
        # Without a session nothing is sent, and the count says so.
        retracted = len(topics) - len(kept) if self.client is not None else 0
        LOG.info("reset: retracting %d retained topic(s)", retracted)
        for topic in topics:
            if self.client is not None and topic not in kept:
                self.client.publish(topic, "", qos=STATE_QOS, retain=True)
        self.state.forget_all()
        for topic in kept:
            self.state.remember(topic)
        if kept:
            self.state.set_component_keys(announced)
        self.state.save(force=True)
        self._last_error_published = False
        # Everything on the broker was just emptied, so nothing this process
        # believes it published is true any more - including the screenshot and
        # every grid.
        self.forget_published()
        self._last_json.clear()
        self._raw_topics.clear()
        self._screenshot = None

        info = self.build_info()
        self.publish_raw(self.topic("availability"), ONLINE)
        self.publish_snapshot(info)
        self.sync_grid_slugs()
        self.sync_channel_slugs()
        self.publish_announcement(info)
        self.publish_discovery(info)
        self.state.save()
        return retracted

    # ----------------------------------------------------------------- uninstall --
    # The bridge's half of `uninstall.py`: what only the bridge can reach.

    def forget_everything_published(self):
        """Step 5 of the removal: nothing this process published is on the broker any more."""
        self.state.forget_all()
        self.forget_published()
        self._not_published = {}
        # `info` went with the rest, so this session has said nothing that a
        # waiting change could correct - until a connect publishes it again.
        self._not_published_reported = None
        self._last_json.clear()
        self._raw_topics.clear()
        self._screenshot = None
        self._last_error_published = False

    def disconnect_for_uninstall(self):
        """Step 6: a clean disconnect, so the will stays unsent and `offline` stays retained.

        The shutdown hook runs later, when the interface restarts; it finds no
        session and publishes nothing.
        """
        self.running = False
        self.idle_reason = "the plugin is being removed"
        self._stop_timers()
        if self.client is not None:
            self.client.stop()
            self.client = None

    def say_at_connect(self, command, message, command_id=None):
        """A refusal for the next connect to publish, once (`on_connect`).

        `command_id` is the id of the command it belongs to, kept with it:
        by the time a session is up, other commands have come and gone.
        """
        self._pending_error = (command, message, command_id)

    def restart_after_failed_uninstall(self, command, message, command_id=None):
        """A removal that stopped ends where a reset ends: everything back, and why.

        `reload()` opens a fresh session, whose connect republishes availability,
        the snapshot, the announcement and discovery. The reason goes on
        `last_error` after that, on the new session - before it there is nobody
        to publish it to. `command_id` is the id the removal's command carried.
        """
        self.say_at_connect(command, message, command_id)
        self.reload()
