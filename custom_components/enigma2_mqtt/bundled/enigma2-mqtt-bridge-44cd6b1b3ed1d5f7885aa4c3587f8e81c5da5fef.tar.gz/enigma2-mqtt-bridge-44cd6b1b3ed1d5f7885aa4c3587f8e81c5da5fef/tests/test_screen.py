"""The screenshot: what runs it, what stops it running too often, and what it publishes."""

import os

from conftest import ConsoleAppContainer

from MQTTBridge import bridge as bridge_module
from MQTTBridge import screen as screen_module

NODE = "vuuno4kse_005301"
SCREEN = "enigma2/" + NODE + "/screen"
LAST_ERROR = "enigma2/" + NODE + "/last_error"

JPEG = b"\xff\xd8\xff\xe0" + b"picture" * 100


def write_a_picture(path, data=JPEG):
    with open(path, "wb") as handle:
        handle.write(data)


def publisher(bridge, tmp_path):
    found = bridge.publisher("screenshot")
    found.path = str(tmp_path / "mqttbridge.jpg")
    return found


def test_a_capture_left_by_an_older_version_is_removed_at_start(
    make_bridge, settings, receiver, tmp_path, monkeypatch
):
    """Nothing else ever deleted it - not even switching screenshots off."""
    legacy = tmp_path / "mqttbridge.jpg"
    write_a_picture(str(legacy))
    monkeypatch.setattr(screen_module, "LEGACY_OUTPUT_PATH", str(legacy))
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    settings.screenshot.value = "off"

    bridge = make_bridge(session=receiver.session)
    bridge.start()

    assert not legacy.exists()
    assert "screenshot" not in bridge.capabilities()


def test_screenshots_off_is_read_before_the_image_is_blamed(
    make_bridge, settings, receiver, monkeypatch, plugin_log
):
    """🔴 A box with screenshots off and no `grab` is not a box with no hooks."""
    monkeypatch.setattr(screen_module, "grab_binary", lambda: None)
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    settings.screenshot.value = "off"

    bridge = make_bridge(session=receiver.session)
    bridge.start()

    written = plugin_log()
    assert "screenshots are switched off" in written
    assert "no grab utility" not in written
    assert "does not provide the screenshot hooks" not in written
    assert "screenshot" not in bridge.capabilities()


def test_removing_a_capture_that_is_not_there_is_not_an_error(tmp_path):
    assert screen_module.forget_legacy_output(str(tmp_path / "absent.jpg")) is False


def test_a_capture_runs_grab_through_the_console_container(live_bridge, tmp_path):
    """Never a subprocess: waiting for one blocks the thread that draws the picture."""
    assert publisher(live_bridge, tmp_path).capture(commanded=True) is None
    assert ConsoleAppContainer.instances[-1].commands[-1].startswith("grab ")


def test_the_grab_command_asks_for_both_layers(live_bridge, tmp_path):
    """🔴 `-o` means „the menus only" in this utility, not „output file"."""
    publisher(live_bridge, tmp_path).capture(commanded=True)
    command = ConsoleAppContainer.instances[-1].commands[-1]
    assert " -o " not in command
    assert " -v " not in command
    assert command.endswith(str(tmp_path / "mqttbridge.jpg"))
    assert "-j 80" in command and "-r 720" in command


def test_the_picture_is_published_when_grab_finishes(live_bridge, factory, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path)
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(0)
    entry = factory.client.last(SCREEN)
    assert entry.payload == JPEG
    assert entry.retain is True


def test_a_capture_finishing_after_stop_is_cleaned_without_publishing(
        live_bridge, factory, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path)
    found.stop()
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(0)
    assert factory.client.all_for(SCREEN) == []
    assert not found._busy
    assert not os.path.exists(found.path)


def test_an_identical_commanded_picture_is_still_a_fresh_state_event(
    live_bridge, factory, tmp_path, monkeypatch
):
    """The screen topic acknowledges each command, even when the pixels did not move."""
    found = publisher(live_bridge, tmp_path)
    now = [1000.0]
    monkeypatch.setattr(screen_module.time, "time", lambda: now[0])

    found.capture(commanded=True)
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)

    now[0] += 6
    factory.client.clear()
    found.capture(commanded=True)
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)

    assert factory.client.last(SCREEN).payload == JPEG


def test_the_file_is_removed_after_it_is_published(live_bridge, tmp_path):
    import os

    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)
    assert not os.path.exists(found.path)


def test_a_grab_that_wrote_nothing_publishes_nothing(live_bridge, factory, tmp_path, plugin_log):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(0)
    assert factory.client.all_for(SCREEN) == []
    assert "grab wrote nothing" in plugin_log()
    assert factory.client.last(LAST_ERROR).json()["cmd"] == "screenshot"
    assert "no image" in factory.client.last(LAST_ERROR).json()["error"]


def test_an_automatic_grab_failure_does_not_fail_an_unrelated_command(
    live_bridge, factory, tmp_path
):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=False)
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(1)
    assert factory.client.last(LAST_ERROR) is None


def test_a_commanded_grab_failure_is_reported_asynchronously(
    live_bridge, factory, tmp_path
):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(1)
    assert factory.client.last(LAST_ERROR).json()["cmd"] == "screenshot"
    assert "exited with code 1" in factory.client.last(LAST_ERROR).json()["error"]


def test_an_empty_file_publishes_nothing(live_bridge, factory, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path, b"")
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(0)
    assert factory.client.all_for(SCREEN) == []


def test_an_oversized_capture_is_refused_rather_than_retained(live_bridge, factory, tmp_path):
    """🔴 `screen` is retained: an enormous one is served to every new subscriber."""
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path, b"x" * (screen_module.MAX_BYTES + 1))
    factory.client.clear()
    ConsoleAppContainer.instances[-1].finish(0)
    assert factory.client.all_for(SCREEN) == []
    assert "over the" in factory.client.last(LAST_ERROR).json()["error"]


# ---------------------------------------------------------- what the log says of it --


def finish_a_capture(bridge, tmp_path, data=JPEG):
    found = publisher(bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path, data)
    ConsoleAppContainer.instances[-1].finish(0)


def test_the_log_says_a_picture_was_published(live_bridge, tmp_path, plugin_log):
    finish_a_capture(live_bridge, tmp_path)

    assert f"published a {len(JPEG)} byte screenshot" in plugin_log()
    assert "was not published" not in plugin_log()


def test_the_log_does_not_say_published_for_a_picture_that_was_withheld(
    live_bridge, factory, tmp_path, plugin_log, monkeypatch
):
    """Over the packet bound the bridge keeps it off the wire; "published" would be untrue."""
    # A bound everything else this bridge publishes is under, and the picture's packet is not.
    picture = JPEG + b"x" * 20000
    monkeypatch.setattr(bridge_module, "MAX_PACKET_BYTES", len(picture))
    factory.client.clear()

    finish_a_capture(live_bridge, tmp_path, picture)

    assert factory.client.all_for(SCREEN) == []
    written = plugin_log()
    assert written.count("not publishing") == 1 and "not publishing screen:" in written
    assert f"took a {len(picture)} byte screenshot; it was not published" in written
    assert "published a " not in written


def test_the_log_does_not_say_published_without_a_connection(live_bridge, factory, tmp_path,
                                                             plugin_log):
    """paho's answer to a publish while the socket is gone: taken by nobody."""
    factory.client.publish_rc = 4

    finish_a_capture(live_bridge, tmp_path)

    assert f"took a {len(JPEG)} byte screenshot; it was not published" in plugin_log()
    assert "published a " not in plugin_log()


def test_the_log_does_not_say_published_while_the_plugin_removes_itself(live_bridge, factory,
                                                                        tmp_path, plugin_log):
    live_bridge.uninstaller.closed = True
    factory.client.clear()

    finish_a_capture(live_bridge, tmp_path)

    assert factory.client.published == []
    assert f"took a {len(JPEG)} byte screenshot; it was not published" in plugin_log()
    assert "published a " not in plugin_log()


def test_a_second_capture_within_five_seconds_is_refused(live_bridge, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    ConsoleAppContainer.instances[-1].finish(0)
    assert "at most one every 5 s" in found.capture(commanded=True)


def test_a_capture_is_allowed_again_after_five_seconds(live_bridge, tmp_path, monkeypatch):
    found = publisher(live_bridge, tmp_path)
    now = [1000.0]
    monkeypatch.setattr(screen_module.time, "time", lambda: now[0])
    found.capture(commanded=True)
    ConsoleAppContainer.instances[-1].finish(0)
    now[0] += 6
    assert found.capture(commanded=True) is None


def test_a_capture_while_one_is_running_is_refused(live_bridge, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    assert "already being taken" in found.capture(commanded=True)


def test_a_zap_takes_a_screenshot_after_the_box_has_settled(live_bridge, factory, receiver,
                                                            tmp_path):
    found = publisher(live_bridge, tmp_path)
    receiver.nav.fire(1)  # evStart
    assert found._debounce.timer.started == (4000, True)
    found._debounce.timer.fire()
    assert ConsoleAppContainer.instances[-1].commands


def test_running_through_ten_channels_takes_one_screenshot(live_bridge, receiver, tmp_path):
    """The debounce is the difference between one picture and ten."""
    found = publisher(live_bridge, tmp_path)
    before = len(ConsoleAppContainer.instances)
    for _ in range(10):
        receiver.nav.fire(1)
    found._debounce.timer.fire()
    assert len(ConsoleAppContainer.instances) == before + 1


def test_the_configured_zap_delay_is_used(live_bridge, receiver, settings, tmp_path):
    settings.screenshot_delay.value = 8
    found = publisher(live_bridge, tmp_path)
    receiver.nav.fire(1)
    assert found._debounce.timer.started == (8000, True)


def test_a_new_zap_discards_an_inflight_automatic_capture(
    live_bridge, factory, receiver, tmp_path, monkeypatch
):
    """The re-arm below is `max(delay, the rest of the rate limit)`, off the real clock.

    `_arm_zap_capture` computes `max(4000, ceil((5 - (time.time() - last)) * 1000))`,
    so the 5000 this asserts only holds while less than a millisecond has passed
    since the first capture. On a loaded machine it is 4999 - three failures in
    320 runs under CPU contention, and every time with a forced 2 ms gap. The
    clock is frozen here the way its siblings freeze it; the assertion is the
    thing being tested and is left exact.
    """
    now = [1000.0]
    monkeypatch.setattr(screen_module.time, "time", lambda: now[0])
    found = publisher(live_bridge, tmp_path)
    receiver.nav.fire(1)
    found._debounce.timer.fire()
    old = ConsoleAppContainer.instances[-1]
    write_a_picture(found.path)

    receiver.nav.fire(1)
    factory.client.clear()
    old.finish(0)

    assert factory.client.all_for(SCREEN) == []
    assert not os.path.exists(found.path)
    assert found._debounce.timer.started == (5000, True)


def test_a_commanded_capture_is_not_invalidated_by_a_zap(
    live_bridge, factory, receiver, tmp_path
):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path)
    receiver.nav.fire(1)
    ConsoleAppContainer.instances[-1].finish(0)
    assert factory.client.last(SCREEN).payload == JPEG


def test_stop_prevents_a_stale_capture_from_rearming(
    live_bridge, receiver, tmp_path
):
    found = publisher(live_bridge, tmp_path)
    receiver.nav.fire(1)
    found._debounce.timer.fire()
    running = ConsoleAppContainer.instances[-1]
    write_a_picture(found.path)
    receiver.nav.fire(1)
    debounce = found._debounce.timer
    found.stop()
    running.finish(0)
    assert debounce.stopped is True
    # And the publisher is no longer on that timer's callback list at all.
    assert found._debounce.timer is None


def test_no_screenshot_on_a_zap_when_the_setting_is_an_interval(live_bridge, receiver, settings,
                                                                tmp_path):
    settings.screenshot.value = "interval"
    found = publisher(live_bridge, tmp_path)
    found._debounce.stopped = False
    receiver.nav.fire(1)
    assert found._debounce.timer is None


def test_the_interval_timer_is_armed_when_the_setting_says_so(make_bridge, factory, settings,
                                                              receiver):
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    settings.screenshot.value = "interval"
    settings.screenshot_interval.value = 90
    bridge = make_bridge(session=receiver.session)
    bridge.start()
    assert bridge.publisher("screenshot")._interval.timer.started == (90000, False)


def test_an_interval_capture_completion_is_published(
    make_bridge, factory, settings, receiver, tmp_path
):
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    settings.screenshot.value = "interval"
    bridge = make_bridge(session=receiver.session)
    bridge.start()
    found = publisher(bridge, tmp_path)
    found._interval.timer.fire()
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)
    assert factory.client.last(SCREEN).payload == JPEG


def test_a_queued_debounce_after_stop_does_nothing(live_bridge, receiver, tmp_path):
    found = publisher(live_bridge, tmp_path)
    receiver.nav.fire(1)
    timer = found._debounce.timer
    found.stop()
    before = len(ConsoleAppContainer.instances)
    timer.fire()
    assert len(ConsoleAppContainer.instances) == before


def test_a_finished_container_gets_its_callback_back(live_bridge, tmp_path):
    """One finished console container is held, and only until the next one."""
    found = publisher(live_bridge, tmp_path)
    assert found.capture(commanded=True) is None
    first = ConsoleAppContainer.instances[-1]
    write_a_picture(found.path)
    first.finish(0)
    # Still attached: the walk of its own callback list has only just ended.
    assert found._finished_container is first

    found._last_capture = 0.0
    assert found.capture(commanded=True) is None
    second = ConsoleAppContainer.instances[-1]

    assert second is not first
    assert first.appClosed == []
    assert found._finished_container is None
    write_a_picture(found.path)
    second.finish(0)
    found.stop()
    assert second.appClosed == []


def test_rebind_does_not_let_old_completion_remove_new_capture(
    live_bridge, factory, tmp_path
):
    old = live_bridge.publisher("screenshot")
    assert old.capture(commanded=True) is None
    old_container = ConsoleAppContainer.instances[-1]
    old_path = old.path
    old.stop()

    new = screen_module.ScreenPublisher(live_bridge)
    assert new.path != old_path
    new.path = str(tmp_path / "new.jpg")
    assert new.start() is True
    assert new.capture(commanded=True) is None
    new_container = ConsoleAppContainer.instances[-1]
    write_a_picture(new.path)

    old_container.finish(0)
    assert os.path.exists(new.path)
    new_container.finish(0)
    assert factory.client.last(SCREEN).payload == JPEG


def test_the_interval_never_goes_below_five_seconds(make_bridge, settings, receiver):
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    settings.screenshot.value = "interval"
    settings.screenshot_interval.value = 1
    bridge = make_bridge(session=receiver.session)
    bridge.start()
    assert bridge.publisher("screenshot")._interval.timer.started == (5000, False)


def test_screenshots_off_means_no_capability(make_bridge, factory, settings, receiver):
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    settings.screenshot.value = "off"
    bridge = make_bridge(session=receiver.session)
    bridge.start()
    factory.client.fire_connect()
    assert "screenshot" not in bridge.capabilities()


def test_no_screenshot_in_standby_unless_asked_for(live_bridge, receiver, tmp_path):
    receiver.enter_standby()
    found = publisher(live_bridge, tmp_path)
    before = len(ConsoleAppContainer.instances)
    assert found.capture() is None
    assert len(ConsoleAppContainer.instances) == before


def test_a_commanded_screenshot_works_in_standby(live_bridge, receiver, tmp_path):
    receiver.enter_standby()
    found = publisher(live_bridge, tmp_path)
    assert found.capture(commanded=True) is None
    assert ConsoleAppContainer.instances[-1].commands


def test_a_grab_that_will_not_start_is_reported(live_bridge, tmp_path, monkeypatch):
    found = publisher(live_bridge, tmp_path)

    class Rejecting(ConsoleAppContainer):
        def __init__(self):
            ConsoleAppContainer.__init__(self)
            self.rejects = True

    monkeypatch.setattr("enigma.eConsoleAppContainer", Rejecting)
    assert "could not be started" in found.capture(commanded=True)


def test_the_last_picture_comes_back_on_a_reconnect(live_bridge, factory, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)
    factory.client.clear()
    factory.client.fire_connect()
    assert factory.client.last(SCREEN).payload == JPEG


def test_a_reconnect_does_not_run_grab_again(live_bridge, tmp_path):
    """A reconnect loop that ran `grab` each time would be a receiver on its knees."""
    publisher(live_bridge, tmp_path)
    before = len(ConsoleAppContainer.instances)
    factory_clients = len(ConsoleAppContainer.instances)
    live_bridge.publish_snapshot()
    assert len(ConsoleAppContainer.instances) == before == factory_clients


def test_a_box_without_grab_has_no_screenshots(make_bridge, factory, settings, receiver,
                                               monkeypatch):
    monkeypatch.setattr(screen_module, "grab_binary", lambda: None)
    settings.host.value = "10.0.0.5"
    settings.node_id.value = NODE
    bridge = make_bridge(session=receiver.session)
    bridge.start()
    factory.client.fire_connect()
    assert "screenshot" not in bridge.capabilities()


# ---------------------------------------------- what the OpenWebif page reads (ADR-0010) --


def test_completed_at_is_when_grab_finished_not_when_it_started(live_bridge, tmp_path,
                                                                 monkeypatch):
    found = publisher(live_bridge, tmp_path)
    assert found.completed_at is None
    monkeypatch.setattr(screen_module.time, "time", lambda: 1000.0)
    found._last_capture = 0.0
    found.capture(commanded=True)
    monkeypatch.setattr(screen_module.time, "time", lambda: 1003.5)
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)
    assert found.completed_at == 1003.5
    assert live_bridge.last_screenshot() == (JPEG, 1003.5)


def test_a_failed_grab_leaves_completed_at_alone(live_bridge, tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    ConsoleAppContainer.instances[-1].finish(1)
    assert found.completed_at is None
    assert live_bridge.last_screenshot() is None


def test_capture_state_says_whether_a_grab_is_in_flight_and_since_when(live_bridge, tmp_path):
    found = publisher(live_bridge, tmp_path)
    assert found.capture_state() == (False, None)
    found.capture(commanded=True)
    busy, started = found.capture_state()
    assert busy is True and started == found._last_capture
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)
    assert found.capture_state() == (False, None)


def test_the_recorded_picture_is_the_published_object_not_a_copy(live_bridge, factory,
                                                                  tmp_path):
    found = publisher(live_bridge, tmp_path)
    found.capture(commanded=True)
    write_a_picture(found.path)
    ConsoleAppContainer.instances[-1].finish(0)
    assert live_bridge.last_screenshot()[0] is factory.client.last(SCREEN).payload
