# Configuring the plugin

Everything lives under `config.plugins.mqttbridge.*` in enigma2's own settings file
(`/etc/enigma2/settings`) and is edited on the box through *Menu -> Plugins -> MQTT Bridge* or on
the [OpenWebif page](#the-openwebif-page). There is no separate configuration file to maintain,
and settings survive a plugin upgrade.

## Settings

| Setting | Default | What it does |
|---|---|---|
| `enabled` | `on` | Master switch. Off means the plugin loads and does nothing - reachable from the setup screen even when the broker is unreachable, which is the point |
| `host` | - | Broker address. Empty means the plugin stays idle and says so once in the log |
| `port` | `1883` | `8883` for TLS |
| `tls` | `off` | TLS to the broker. Client certificates are not in v1 |
| `ca_file` | - | Path to a CA bundle on the box, for a broker with a private CA |
| `username` | - | Broker login. Give the box **its own**, not Home Assistant's |
| `password` | - | Entered as a password field and never written to the log |
| `node_id` | `<boxtype>_<mac6>` | For example `vuuno4kse_005301`. Lowercase ASCII, stable across reinstalls, and the unique identity everything keys on. Changing it orphans the old retained topics - run `cmd/reset` first |
| `friendly_name` | the box type | The device name a user sees in Home Assistant |
| `base_topic` | `enigma2` | State publishes under `<base_topic>/<node_id>/` |
| `ha_discovery_prefix` | `homeassistant` | Match your Home Assistant MQTT integration if you changed it there |
| `ha_mode` | `discovery` | `discovery` / `integration` / `off` - see [TOPICS.md](TOPICS.md#cmdha_mode-semantics) |
| `publish_keys` | `on` | Remote-key events on the `key` topic. Off if you do not automate on them - it is a log of what is pressed |
| `screenshot` | `on zap` | `off`, `on zap`, or `interval N s`. At most one capture per five seconds whatever this says. Each capture costs the receiver about 22 kB of memory it does not give back - see below |
| `screenshot_delay` | `4` | Seconds to wait after a zap before capturing. Another zap restarts the wait |
| `osd_toast` | `on` | Lets a sender ask `cmd/message` for a **discreet toast** instead of the popup: a small box in the top-right corner, headed „MQTT Bridge", that hides itself after a few seconds, never takes a key press and is not shown in standby. Off means the toast is never created, the `toast` capability is absent and a toast is refused; popups are unaffected. See below |
| `cam_telemetry` | `off` | Publish bounded current-service conditional-access status from `/tmp/ecm.info` |
| `oscam_telemetry` | `off` | Publish privacy-reduced OSCam software and reader/server health |
| `oscam_port` | `8888` | Receiver-local OSCam WebIf port; the host is fixed to `127.0.0.1` |
| `oscam_username` | - | OSCam WebIf login, used only on the receiver |
| `oscam_password` | - | OSCam WebIf password, masked in Setup and excluded from MQTT and logs |
| `epg_grid_events` | `4` | Events per channel in the EPG grid. `0` turns the grid off and drops it from `capabilities` |
| `bouquets_for_select` | all TV bouquets | Which bouquets feed the channel list, the `zap`-by-name lookup and the EPG grid. The channel list and the grid each publish **one retained topic per bouquet**, `channels/<bouquet_slug>` and `epg_grid/<bouquet_slug>`. Narrow it if you have hundreds of services. Dropping or renaming a bouquet retracts the topics it owned |
| `deep_standby_allowed` | `off` | Gate for `cmd/deep_standby` and `cmd/reboot`. Off by default because a receiver in deep standby may not wake again over the network: `info.wol.supported` says whether its image can, and when it is `false` only the remote, the front button or a timer brings it back |
| `wol_arm` | `off` | Switch on the image's own Wake-on-LAN setting („Wake On LAN" in its expert settings) at every start. Only where the image has one: on a receiver without it the label says „Wake-on-LAN is not available on this receiver" and the setting does nothing. Switching it off never switches the image's setting off - and while it is on, switching the image's own „Wake On LAN" off is undone at the next start or settings save, so switch this off first. Never writable over MQTT and not in `info.settings` - `info.wol` says what the receiver's switch actually is. No `ethtool` is run; see [ADR-0012](adr/0012-wake-on-lan-is-the-image-s-switch.md) |
| `cec_standby_workaround` | `off` | When the television switches itself off while the channel list is open, close the list so the receiver follows it into standby at once - and drop a television standby that is still waiting thirty seconds later behind any other screen, so it cannot fire when you next close that screen. Off by default; see below |
| `softcam_restart_allowed` | `off` | Gate for `cmd/softcam_restart` and for the automatic restart below. Off by default because it stops a running program on your receiver |
| `softcam_autoheal` | `off` | Restart the softcam by itself when the channel you are watching is encrypted and stops decoding. Does nothing unless the permission above is on |
| `softcam_autoheal_seconds` | `90` | How long a stuck decode has to hold before that happens, 30 to 600. A healthy encrypted channel refreshes its ECM file about every ten seconds, so anything much shorter is reading noise |
| `epg_import_allowed` | `off` | Gate for `cmd/epg_import`, which starts the image's EPG importer now. Off by default because the end of every import freezes the menus for two or three seconds; see below |
| `uninstall_allowed` | `off` | Gate for `cmd/uninstall`, which removes the plugin from the receiver. Off by default because it is a one-way door: afterwards only the receiver's own plugin menu or SSH can put the plugin back. See below |
| `update_check` | `off` | Let the receiver ask the plugin's release origin on the internet which releases exist - once a day, and when `cmd/update_check` asks - and publish what it found on the `update` topic. Off by default because the receiver then makes no connection but the broker's. A receiver without internet learns of releases from Home Assistant instead, which needs no setting. It only checks; nothing is installed. See below |
| `update_allowed` | `off` | Gate for `cmd/update`, which installs a signed release of the plugin over MQTT and restarts the interface to run it. Off by default because it replaces the code that takes the commands. The receiver's own screens and the OpenWebif page do not need it |
| `recording_delete_allowed` | `off` | Gate for `cmd/delete_recording`, which moves one recording into the receiver's trash - never further, and not at all while the receiver's trash is switched off. Off by default because it takes a recording out of the movie list; see below |
| `menu_allowed` | `on` | Offer the Home Assistant menu: the Extensions entry "Home Assistant", the hotkey, and the subscription to the menu the companion integration publishes. On by default because the menu can do only what you put into it in Home Assistant; see below |
| `menu_hotkey` | `HELP, held` | The key that opens the Home Assistant menu in live TV and while a recording or a media file plays: HELP held, RED held, F3, F4, or off. A key the receiver itself uses keeps doing what it did; see below |
| `menu_transparency` | `20 %` | How see-through the Home Assistant menu's background is: 0 % (opaque) to 80 %, in steps of 10. The text, the icons and the bar on the selected row stay solid. It applies the next time the menu is opened |
| `menu_combo_key` | `off` | The press combo: a key that opens the Home Assistant menu when you press it several times in quick succession in live TV - PREVIOUS also while a recording or a media file plays - for a television's own remote over HDMI-CEC, which has no HELP and cannot hold a key. PREVIOUS, EXIT, PLAY/PAUSE, STOP, or off. **While a key is set here, it does nothing else there**; see below |
| `menu_combo_presses` | `3` | How many presses of that key open the menu, 2 to 5 |
| `menu_combo_gap_ms` | `1.2 s` | The longest pause between two presses, 0.3 s to 3.0 s in steps of 0.1 s; a slower press starts counting again. Stored in milliseconds |
| `log_level` | `info` | `error` / `warning` / `info` / `debug` |

The setup screen shows `recording_delete_allowed` under the heading **Recordings**, and the three menu settings last, under the heading **Home Assistant menu**; the OpenWebif page
has the menu's on its own [Menu page](#the-menu-page-and-the-menu-creator).

**Saving reconnects only for the connection.** A save on the setup screen or the OpenWebif page
that changes `enabled`, `host`, `port`, `tls`, `ca_file`, `username`, `password`, `node_id` or
`base_topic` ends the MQTT session and opens a new one, which takes a few seconds; the Home
Assistant menu is greyed meanwhile. Every other setting is applied at once under the open
session - as `cmd/config` applies its own - and `info`, the announcement and the discovery payloads
are published again with it: the menu stays usable, and Home Assistant sees no reconnect. A save
that changes nothing publishes nothing. With the broker unreachable at that moment, the change is
applied on the receiver and published by the next connect.

🔴 **`deep_standby_allowed`, `softcam_restart_allowed`, `epg_import_allowed`,
`uninstall_allowed`, `update_check`, `update_allowed`, `menu_allowed` and
`recording_delete_allowed` are never writable over MQTT.** They are
set on the receiver - here, in the provisioning file, or on the [OpenWebif page](#the-openwebif-page)
- and published in `info.settings` so that a consumer can hide a control the box would always
refuse, but `cmd/config` rejects them like any other key outside its allowlist - the whole command,
with "the config object contains unknown settings: " and the name of each key it refused, in
single quotes, on `last_error`. The rule is the
same for all of them: a setting that **enables** a command is granted on the receiver, and a setting
that only **tunes** a command already permitted - `softcam_autoheal` and its delay - may be
changed from the broker. `update_check` enables no command on the receiver, but it is what lets
the receiver reach the internet at all, which is the receiver's to decide.

🔴 **`cec_standby_workaround` is never writable over MQTT, and it is not echoed at all.** It is
not a permission for a command - it switches on code that closes a screen you may be looking at,
which makes it the kill-switch for that code, and a kill-switch belongs on the receiver. A consumer
learns whether it is at work from the `cec_workaround` capability, not from `info.settings`.

🔴 **`osd_toast` is never writable over MQTT, and it is not echoed either.** It is the kill-switch
for a screen that lives inside the receiver's user interface, and a kill-switch reachable over the
broker is not one. A consumer learns whether toasts are available from the `toast` capability.

„On the receiver" includes the OpenWebif page, and that is not a loophole but a statement of fact:
whoever OpenWebif admits can already set every one of these through OpenWebif's own settings
endpoint. What stays true is the half that matters - **the broker can never grant itself one.**

The log is `/home/root/mqttbridge.log`, capped at 1 MB with two rotations kept, so a debug
session cannot fill the flash.

### What the CEC standby workaround does

It works around an enigma2 defect, not a defect of this plugin. When the television switches itself
off it tells the receiver over HDMI-CEC, and the image queues a standby that only the info bar
carries out. With the channel list open, the receiver therefore stays on - and when you later close
the list it goes to standby after all, and tells the television to switch off as well, because by
then the image has forgotten that the standby was the television's idea.

With the setting on:

- **The channel list, and only the channel list, is closed** when the television's standby arrives
  behind it - through the list's own exit, so you are back on the channel you were watching. A
  menu, the EPG, an input box, a message, a recording dialog, the service picker inside another
  dialog, or anything opened on top of the channel list is left exactly as it is.
- **A standby the television asked for that is still waiting after thirty seconds is dropped**, so
  that closing the menu you were in half an hour later does not put the receiver - and the
  television - to sleep.
- **A standby you asked for is never touched.** `cmd/power standby` from Home Assistant queues
  exactly the same thing as the television does; the plugin tells the two apart at the moment they
  are queued and only ever acts on the television's. The remote's power button does not go through
  the queue at all - it opens the standby screen directly - so the workaround never sees it.

It needs HDMI-CEC switched on in the image's own settings, with the image set to follow the
television into standby (on OpenViX 6.6 that second one is on by default). With either of them
off the image never queues the television's standby, so the plugin does not start the workaround
and does not claim the `cec_workaround` capability. Both are read when the plugin starts, so after
changing them restart the receiver's interface. Each intervention is logged at `info` and counted
on the `cec` topic - see [TOPICS.md](TOPICS.md).

### What the discreet toast does

A message from Home Assistant normally arrives as the receiver's own popup: it opens in the middle
of the screen, takes the remote until somebody dismisses it or it times out, and - because it goes
through the same queue as the image's other notifications - waits while the channel list is open
and then appears when you close it. A sender that asks for `"style": "toast"` gets something else:

- **A small box in the top-right corner**, above the channel list and the info bar, headed
  „MQTT Bridge" so that it cannot be mistaken for a message from the receiver itself. It has one
  appearance whatever the message says.
- **It hides itself** after 5 seconds, or the 1 to 30 the sender asks for. The remote cannot dismiss
  it, because nothing on it can take a key press - which is also why the channel list keeps moving
  normally while it is on screen.
- **A newer toast replaces the one on screen.** There is no queue.
- **It is not shown in standby.** It is hidden when the receiver goes to standby, and one sent
  while it is in standby is refused on `last_error` rather than kept for later.

A skin may define a screen called `MQTTBridgeToast` to restyle it, as it can any other screen.

### What the Home Assistant menu does

With the companion integration, you choose in Home Assistant what the receiver's menu offers -
lights, switches, covers, scenes, scripts, a selector, a number, a text - in up to eight groups.
The receiver shows it on the television:

- **Open it** from the Extensions menu (the entry "Home Assistant") or by
  holding HELP in live TV or while a recording or a media file plays (`menu_hotkey`). A key the
  receiver already uses - for example a function you assigned in its own button setup, or a key
  the player uses - keeps doing that, and the menu does not open from it;
  `info.menu.hotkey` then says so. The Extensions entry always works, and you can put it on any key
  in the receiver's button setup.
- **From the television's remote** (HDMI-CEC), which has no HELP and no long press, use the
  **press combo**: choose a key in `menu_combo_key` and press it `menu_combo_presses` times
  (3 by default), each press within `menu_combo_gap_ms` (1.2 s) of the one before. A
  television's Back key usually arrives as `previous` or `exit`; to find out which, watch the
  `key` topic (`enigma2/<node>/key`, with `publish_keys` on) while you press it in live TV - it
  says `KEY_PREVIOUS` or `KEY_EXIT`. **While a combo key is set, that key does nothing else in
  live TV** - one or two presses do nothing at all - so on OpenViX Back no longer zaps back to
  the previous channel there. `previous` counts while a recording or a media file plays too;
  EXIT, STOP and PLAY/PAUSE do not, so in a player they still leave, stop and pause it - but in
  live TV, with `exit` EXIT no longer hides the info bar, with `stop` STOP no longer stops
  timeshift and with `playpause` PLAY/PAUSE no longer pauses it. In menus, lists and the EPG
  every key works as before. A press sent from Home Assistant's remote (`cmd/key`) counts and
  is taken like the remote's own. On the Home Assistant menu and the list of choices PREVIOUS
  always works as EXIT, whatever the combo is set to, so a television's Back leaves them. A function you assigned to that key in the receiver's button setup
  does not run there either. `info.menu.combo.replaces` lists what the key no longer does
  ([ADR-0025](adr/0025-a-press-combo-takes-its-key-from-the-image-in-live-tv-and-the-players.md)). `off` gives the key back.
- **Use it** with the arrows and OK; EXIT goes back. OK switches a light or a switch, runs a scene
  or a script, opens a list of choices, or opens the keyboard for text. On a number - a dimmer, a
  blind's position - LEFT and RIGHT change the value on the receiver and OK sends it; EXIT, or
  moving to another row, forgets it. OK on the choice, number or text the row already has sends
  nothing and just closes the list or keyboard. The keys 1-9 jump to the row of that number; OK
  then acts. A row whose state is green is all good, red needs attention. A row of a kind this
  receiver does not know yet - from a newer Home Assistant integration - shows its state and does
  nothing on OK.
- **What it shows** comes from Home Assistant and changes on the screen as it changes there.
  After OK a row shows a small mark until Home Assistant has done it; when nothing has changed after
  five seconds the line at the bottom says so.
- **Without the broker, or while Home Assistant is down**, the menu stays on the screen greyed,
  with a line saying why, and nothing in it can be used. It never sends a choice later. When the
  receiver gets its broker connection back, the menu is usable again at once unless Home
  Assistant says it is down.

The receiver only says which row was chosen and the value; Home Assistant decides what that does,
and does nothing for a row it does not have. Anybody who can publish on your broker can send the
receiver's choices too, so put into the menu only what you would hand to whoever holds the remote.
`menu_allowed` off removes the menu, the entry and the hotkey. Where the receiver cannot draw the
plugin's own screen, it uses its own plain list with the same rows; the number keys do nothing
there, because that list would act on a digit.

The menu's background lets the picture show through, 20 % by default (`menu_transparency`); 0 %
makes it opaque. The receiver's own plain list is drawn as the receiver draws it. The menu can be
built from the receiver's web interface as well as in Home Assistant: see the
[Menu page](#the-menu-page-and-the-menu-creator).

### What a list of choices does

Home Assistant can ask the person in front of the television a question - "Doorbell: open the gate
/ ignore", "TV off in 1 minute: +15 minutes / cancel" - with the companion integration's action, or
any client that publishes `cmd/list` ([TOPICS.md](TOPICS.md)). There is nothing to set up on the
receiver:

- **It appears over whatever is on the screen** - live TV, a recording, the Home Assistant menu,
  the keyboard - which is still there when the list has gone. A line at the top says the question
  comes from Home Assistant through this plugin.
- **Answer it** with the arrows and OK, or with the colour or number key a row shows on its
  right - a coloured button, or a digit in a box - which picks that row at once. EXIT says no
  answer. The time left counts down at the bottom, naming the row Home Assistant set as the
  default, if it set one; when it runs out the list closes with that row.
- **The receiver only says which row was picked.** Home Assistant decides what that does. A newer
  question replaces the one on the screen, and standby closes it; a question that arrives in
  standby is refused, not kept for later. An answer is never sent late: a pick made while the
  receiver has no connection to the broker is lost.

Anybody who can publish on your broker can put a question on the television, or answer one in the
viewer's place, so do not let an answer open a door you would not open for whoever is on your
broker ([SECURITY.md](../SECURITY.md)). Where the receiver cannot draw the plugin's own screen, it
uses its own plain list with the same rows and keys, and shows the time left in its title where it
can. A skin may define a screen called `MQTTBridgeChoices` to restyle the plugin's own.

### What the softcam restart does

It is not „run the init script" and not „restart the process". On the images that need it the
script is a stub and there may be several copies of the cam running, because the image's own
liveness check looks the cam up by process name - and the kernel keeps only the first fifteen
characters of that name, so a longer binary name can never be found and the check starts another
copy instead of leaving the running one alone.

So the command **collapses the copies to exactly one**: it signals every running instance of the
binary the image selected, waits up to five seconds, kills whatever is left, and starts one with
the image's own command line. The binary is resolved on the receiver from
`config.softcammanager.softcams_autostart`; nothing about it comes from the broker. The `softcam`
topic then reports how many instances are running, and whether your receiver is one of the ones
affected by that check - see [TOPICS.md](TOPICS.md).

Two things it deliberately does not touch: the cam's own runtime directory, because the line the
image's manual start screen uses would delete the live cam log with it, and the image's
„skip this cam" marker file, because on these images the manager is the only thing that starts the
cam at all and a marker left behind would disable it until the next interface restart.

### What the EPG import does

It asks the image's own EPG-Importer for an import now, exactly as the importer's „Manual" button
does, without the button's dialogs - the same selected sources, the same settings. The plugin adds
nothing of its own to the import and never loads the importer itself: it uses the one enigma2
already loaded, and where there is none - or where the image's guide cannot take imported events
and the importer would end by restarting the user interface - the command is simply not offered.

What you should know first, because it is the importer's behaviour and applies to every import,
scheduled ones included:

- **At the end of every import the menus freeze for two or three seconds** while the importer saves
  the guide on the thread that draws the picture. That is why the permission is off by default, and
  why the import is refused while recording, with a timer due within ten minutes, and within ten
  minutes of the importer's own scheduled run.
- **With the importer's „clear old EPG" setting on**, the guide is empty until the import finishes.
- **The importer's own deep-standby settings apply**, to an import started from Home Assistant as
  to a scheduled one: after **every** import, whoever started it, the importer checks whether to put the receiver into
  deep standby. It does so only when **all four** of its own conditions hold - its „shutdown"
  setting is on, its deep-standby setting is „wake up", its „deep standby after import" setting is
  on, and a timer woke the receiver - and then only if the receiver is in standby, nothing is
  recording and it is not already shutting down. The settings are all off by default. That is the
  importer, not this plugin.
- **A network recording mount can hold the press up.** Before its first download the importer reads
  `/proc/mounts` and asks the recording mount for its free space, on the main loop, to choose
  where to put the file. If that mount is a network share that has stopped answering, pressing the
  button can freeze the picture until the mount gives up - as the importer's scheduled run would.

A normal run takes a minute or two. The `epg_import` topic says `running` from the moment it starts -
whoever started it, including the importer's own schedule - and `done` with the number of events,
or `failed` with a sentence. The importer does not say which source failed, so neither can the
plugin. While an import runs the plugin also refuses its own deep standby, reboot and
user-interface restart, because a restart mid-import loses the run - except once its own start of
the import has failed, or the import has run past its 30-minute watchdog. The importer can go on
saying „running" after a start that failed part-way, until its next scheduled run, and a receiver
that cannot be restarted for a day because of it is the worse outcome.

### What the recording library does

The plugin publishes the receiver's recordings for Home Assistant - every recording in every movie
location, with its subfolders, the trash left out - and lets Home Assistant play one on the
receiver and, with `recording_delete_allowed` on, move one into the receiver's trash. The topics
and commands are in [TOPICS.md](TOPICS.md#basenoderecordings---since-050).

- **Which locations.** The receiver's own: its default movie location first - also when it is
  a folder of another location - then the movie list's locations ("Movie locations" in its
  recording settings) in the receiver's order, then its timer and instant-recording locations
  where no location before them holds them. A location on a network share is read like any
  other.
- **Which files.** Recordings - `.ts`, and `.stream` for an IPTV recording. Other media files the
  movie list shows are not listed. Names starting with a dot, the trash `.Trash` among them, are
  left out.
- **When it is read.** Once when the plugin starts, then when a recording starts or ends, after a
  delete, when a movie location is mounted - and when Home Assistant's *Refresh recordings* button
  sends `cmd/recordings_refresh`. **Never on a timer**: reading the library reads the recording
  disk's folders and the files beside each recording, and a disk read once an hour is a disk that
  never sleeps. Free space and whether each location is mounted are read once a minute, without
  touching a disk. A deletion, move or rename made on the receiver itself - in its movie list,
  through OpenWebif, over FTP - raises no event, so Home Assistant sees it after the next of those
  events or after the button.
- **Playing.** A recording starts in the receiver's own movie player, exactly as if it had been
  chosen in its movie list - with timeshift running, the receiver first asks on the television
  whether to leave it, and a "no" there plays nothing. The receiver's own setting for resuming
  applies - "Behaviour when a movie is started" in its movie-list settings: resume, ask, or start
  from the beginning. When it
  is set to ask, the question is on the television. A receiver in standby is woken first.
- **Deleting.** Only with `recording_delete_allowed` on (off by default, never writable over MQTT),
  and only ever **into the receiver's trash** - the receiver's own move, with the files beside the
  recording - where the receiver's own trash settings decide when it is emptied. With the
  receiver's trash switched off ("Use trash can in movie list") a delete is refused: nothing Home
  Assistant asks for is deleted for good. A recording that is being recorded or played is not
  deleted.
- **Hidden bouquets are Home Assistant's.** The receiver lists every recording, with the channel's
  service reference and bouquet, and the companion integration leaves out the ones of a bouquet
  its options hide - as it does in its channel lists. The receiver publishes the whole library,
  titles and descriptions included, to anybody on the broker.

The timeshift state is published beside it: whether a buffer runs, whether the picture is paused,
whether it is playing behind live, and since when.

### What removing the plugin remotely does

With `uninstall_allowed` on, `cmd/uninstall` - with this receiver's node id as its payload, so that
a message meant for another receiver removes nothing - takes the plugin off the receiver. The
companion integration offers it from 0.3.0 in the entry's options, behind a confirmation, and only
while the receiver says both that it may and that it can; the OpenWebif page offers it too, behind
its own confirmation. Deleting the integration's entry never removes anything. It is refused while a recording runs or is
due within ten minutes, while an EPG import runs, and on a plugin that the package manager did not install (the `uninstall`
capability says which).

It first stops everything that publishes, then empties every retained topic the plugin put on the
broker and ends with `offline`, waits until the broker has confirmed all of it, disconnects, removes
the package with `opkg remove`, and restarts the user interface. In Home Assistant the receiver then
looks switched off: its entities stay, unavailable.

**It can fail, and then nothing is lost.** If the broker does not confirm within 15 seconds, the
connection drops, or `opkg` refuses - it holds a lock that the image's own update check and plugin
browser take as well - the plugin reconnects, publishes everything again as after any restart, and
`last_error` says which step stopped it. Try again a minute later.

**Saving the setup screen or the OpenWebif page's settings during a removal** keeps what you typed but does not reconnect or apply it: the screen and the page say so. The settings take effect if the removal stops - its failure path reconnects with them - or when the plugin is installed again.

🔴 **opkg removes files one at a time.** If it is interrupted part way - it reports success even when
it was killed - the plugin checks that the package really is gone before restarting. When it is not,
some of its files may already be missing: `last_error` then says so and gives the command that puts
it back whole, `opkg install --force-reinstall enigma2-plugin-extensions-mqttbridge`, to run over
SSH.

🟡 **The restart can wait for you.** If something is streaming from the receiver, a background job
is running or timeshift is active, the receiver asks on the television whether to restart now, and
waits for an answer. The plugin is already disconnected and removed by then; answering either way
is fine, and the next restart finishes the job.

What stays on the receiver, on purpose:

| Left behind | Why |
|---|---|
| `config.plugins.mqttbridge.*` in `/etc/enigma2/settings` - **including the broker password** | So that a reinstall finds its configuration. Remove the lines by hand if you want them gone |
| `/etc/enigma2/mqttbridge-state.json`, emptied | It says nothing is published, so a reinstall has nothing to retract |
| `/home/root/mqttbridge.log*` | The only record of what the removal did |
| `/home/root/mqttbridge-backups/` | Snapshots made by the guided installer or by you. 🔴 They hold copies of the settings, so of the broker password too |
| `/etc/opkg/enigma2-mqtt-bridge.conf` | The feed. It is what lets the receiver's own plugin menu install the plugin again |
| `/etc/enigma2/mqttbridge-index.json`, `/etc/enigma2/mqttbridge-check.json`, `/etc/enigma2/mqttbridge-index.lock` | What the receiver has learned from the signed release index, and when it last checked (below). Removing it would let an index the receiver already refused for good be accepted again after a reinstall |

Reinstalling from the receiver's own menu (*Plugins -> Download plugins -> Extensions*) with the feed
still configured brings the plugin back on its kept broker, node id and Home Assistant mode, and an
integration entry that was kept picks it up again with every entity as it was.

### What checking for updates does

The plugin's releases are listed in a **signed release index**
([RELEASE-INDEX.md](RELEASE-INDEX.md)), and the receiver believes nothing else about which releases
exist: an index counts only once its signature verifies with a key built into the plugin, and never
if it is older than one the receiver already accepted. What the receiver holds is on the `update`
topic ([TOPICS.md](TOPICS.md)) - the index's serial and age, the newest compatible release and up to
twenty releases with the reason any of them is not compatible.

It learns of an index in two ways:

- **From the internet**, only with `update_check` on: once a day, once its clock has been set, and
  when `cmd/update_check` asks - or, whatever the setting says, when you press *Check for plugin
  updates now* on the [OpenWebif page](#the-openwebif-page) or *Check now* (yellow) on the
  receiver's *Plugin updates* screen. Asking again within ten minutes
  answers with the last result and fetches nothing. The receiver asks one fixed address over HTTPS,
  checks its certificate, and follows no redirect.
- **From Home Assistant**, with no setting at all: the companion integration publishes the index it
  verified on the retained topic `enigma2mqtt/release_index`, and the receiver verifies it again
  itself. This is how a receiver with no internet learns of releases, and it makes no connection.

With `update_check` off and nobody pressing the page's or the screen's button, the receiver makes
no connection other than the broker's. Checking installs nothing; installing is below. What the
receiver has learned is kept in `/etc/enigma2/mqttbridge-index.json`, when it last
checked in `/etc/enigma2/mqttbridge-check.json`, both
(0600), which a removal leaves in place on purpose.

### Installing a release from the receiver

The setup screen's **blue** key opens *Plugin updates*: the running version and build, which
signed list of versions the receiver holds and how old it is, the versions that list offers - the
running one marked, older and newer ones named, the ones that cannot be installed marked so (**OK**
on such a row says why; the page lists the reason with it) - and an update in progress, with who
started it and how far it is. The same number as the
running one is marked *installed* only when the running build is that release; a development build
of it is never shown as the release. **Yellow** checks for updates, and a failed check says why in
words; **OK** or **green** installs the chosen version. The
[OpenWebif page](#the-openwebif-page) has the same: a *Plugin updates* section and the action
*Install a plugin version*.

Neither needs `update_check` or `update_allowed`: whoever holds the remote control, or is admitted
by OpenWebif, could switch both on, so the act of pressing is the consent. Every guard that
protects the household still applies - a recording, a running EPG import, standby, an update
already running, the ten-minute limits - and says so, on the television in the household's
language. Every install is asked first, because it ends in a restart of the user interface: the
picture stops while it restarts, and the restart is the image's clean one, which is meant to bring
the receiver back on the channel it was showing. In the acceptance before 0.4.0 was released - one
receiver, on OpenViX 6.6 - an install and a downgrade chosen on the television both came back on
the channel being watched ([TRANSACTION.md](TRANSACTION.md) §8); how long the picture stops was not
measured. **Only here can a version older than the running one be installed**, and its question
says what that costs: the plugin's newer features
disappear until it is updated again. The release still has to be on the signed list, at or above
its floor, and not withdrawn. The answer on the television acts only on the question it answers,
and a confirmation on the page expires after ten minutes.

From the moment the package manager starts until the restart, the screen - which may stay open
under the image's restart question - and the page show only "An update of the plugin is being
applied on this receiver. Please wait." A form sent from a page opened earlier gets the same
sentence and nothing else: no question, and nothing saved or kept for later - all but the interface
restart, when the sentence names it as the repair. If the update fails and the plugin's previous
files cannot be put back, they say to install the plugin again instead.

**A receiver without internet** installs through Home Assistant (TOPICS.md, `relay_request`). An
install asked for here may therefore wait before it starts, and the screen and the page say for
what: first "Checking whether the receiver can reach the internet to download version ...", then,
when it cannot, that it has asked Home Assistant, with the seconds left of the two minutes. When
Home Assistant does not answer, they say "The receiver has no access to the internet, and Home
Assistant did not answer. The installation is not possible.", in the receiver's language; when
the only answer carried a download address the receiver's clock calls expired, they say so and
ask to set the clock if it is wrong. Nothing on the receiver has changed in either case. The
screen that asked keeps saying how the wait ended until it is closed; the page says it for an
hour after the wait ended, so an old answer is not read as news, and the Status section's last
error keeps the refusal until a command next succeeds.

### What a screenshot costs

**Every capture leaves about 22 kB in enigma2 that it does not give back, whoever takes it.**
That is the image's own `grab`, not this plugin: measured on OpenViX 6.6 by running 60 captures
from the receiver's own shell with the plugin idle - enigma2's resident memory rose by 1 320 kB
and stayed there. The same 60 captures taken *through* the plugin cost the same or less, so the
read-and-publish path here adds nothing measurable. The price is paid by anything that runs
`grab`, which presumably includes the image's own web interface.

`on zap` stays the default: it is what makes the picture in Home Assistant follow the television,
and on a receiver that is restarted every few weeks the arithmetic is small - 60 zaps a day is
about 1.3 MB a day. On a box that runs for months without a restart, or one that is short of
memory to begin with, set `interval` with a long period and take a capture on demand with
`cmd/screenshot` when you actually want one.

**`off` means off, including on demand.** It does not leave a manual shutter behind: the
screenshot publisher does not start at all, `screenshot` leaves `capabilities`, the retained
`screen` topic is retracted, and `cmd/screenshot` is refused with *screenshots are not available
on this box*. Choose it when you want no captures; choose a long `interval` when you want them
only when you ask.

OSCam telemetry does not enable or change WebIf. Enable OSCam's JSON API yourself, restrict WebIf
to loopback or an explicit local allowlist, and set OSCam `httpreadonly = 1`; the bridge itself
requests only the `status` and `readerlist` views, but cannot enforce OSCam's global policy. The
login is stored by enigma in `/etc/enigma2/settings`: `ConfigPassword` masks it in the UI, not on
disk. It is never sent to Home Assistant, MQTT, provisioning acknowledgements or the log.

## The OpenWebif page

If the receiver runs OpenWebif, the plugin adds a page to it: `http://<receiver-address>/mqttbridge`.
OpenWebif's extras menu entry *MQTT Bridge* opens it **inside OpenWebif**, in a frame with a fixed
height that scrolls, with a link under it to open it in a new tab; the address typed or bookmarked
opens the page on its own. It is the recovery tool - it is served by the receiver's web interface,
not by the broker session, so it keeps working when the broker settings are wrong.

**What it shows.** The plugin version; whether the bridge is running, and if it is idle, why;
whether it is connected; the broker's address and port and whether TLS is on; the node id, base
topic, discovery prefix and Home Assistant mode; the capabilities; the current `last_error`; the
settings as `info.settings` publishes them; the connection diagnostics; the last payload published
on every retained topic, exactly as a subscriber received it (a raw topic such as the screenshot is
named, not shown); and a sanitised tail of the plugin's log.

That includes `zap_history` - the receiver's list of recently watched channels - **unfiltered**:
every channel of every bouquet in it, to whoever OpenWebif admits. A bouquet hidden in a Home
Assistant list is hidden there and nowhere else.

Beside *Take a screenshot* it shows the **last screenshot the plugin sent to the broker**, with the
time the capture finished and a link to the full size (`<mount>/screen.jpg`). While a capture is
running the page says so and reloads itself every two seconds, for at most twenty, until the new
picture is there - no script involved. A capture that fails leaves the previous picture and its
time, and the reason is on `last_error`. The picture is kept in memory, so after the plugin
restarts the page has none until the next capture, while the broker still holds the retained one.

**What it changes.** Every setting on this page's table above, in the setup screen's order - but
the three of the Home Assistant menu, which the page shows as one line with a link to the
[Menu page](#the-menu-page-and-the-menu-creator), where they are changed. The
passwords are **write-only**: their fields are always empty, an empty field keeps the stored
password, and clearing one is done on the setup screen. Every text value refuses control characters
and line breaks - enigma2's settings file has no escaping, so a line break would plant a second
setting. A change to the node id, the base topic or the discovery prefix asks for a confirmation
first, because every retained topic moves and Home Assistant sees a new device. A change inside
`cmd/config`'s subset applies at once, and so does every other change that leaves the connection
as it was; a change to the connection - see [Saving reconnects only for the
connection](#settings) - saves and reconnects, which can take a few seconds, and `info` follows
when it has. Only the fields you actually changed are saved: the form
remembers what it showed, so a page left open while a setting was changed elsewhere - over
`cmd/config`, or a permission switched off at the television - does not write its old value back.
Only the changed fields are checked, too, so a value stored before these rules (a longer host, say)
does not block saving something else; it is checked when you edit it. If another tab or window
saved first, the page says it is out of date - reload it and make the change again.

**What it does.** Every command the plugin accepts over MQTT, run through the same code with the
same household-safety guards - a recording, a timer due, the softcam's one-a-minute limit. Deep
standby, reboot, restarting the interface, deleting a timer, stopping a recording, restarting the
softcam, clearing the list of recently watched channels (which also switches to channel 1, as the
receiver's 0 key does), changing the Home Assistant mode, resetting the retained topics and
removing the plugin each ask for a confirmation that says what the household loses; for the removal
the page fills in the node id itself. Going back to a recently watched channel offers the channels
of the last `zap_history` the plugin published, by reference, as a consumer would send them.
Installing a plugin version always asks first, and asks in its own words before an older version
([above](#installing-a-release-from-the-receiver)); only that confirmation can start a downgrade -
it is kept on the receiver with the confirmation step, never sent by the browser.
*Clear last error* empties the `last_error` the page shows. The one
difference from MQTT: a command from this page **does not need** `deep_standby_allowed`,
`softcam_restart_allowed`, `epg_import_allowed`, `uninstall_allowed`, `update_check`,
`update_allowed` or `recording_delete_allowed`. While the bridge is idle
the commands are shown disabled, with the reason.

**Who can open it.** Exactly whoever OpenWebif lets in - the page has no login of its own and reads
no OpenWebif setting ([ADR-0009](adr/0009-the-openwebif-page-trusts-openwebif.md)):

| OpenWebif setting | Who reaches the page |
|---|---|
| Authentication **off** (OpenWebif's default for HTTP) | A client in one of the receiver's own networks; any private address when OpenWebif's VPN access is on; a process on the receiver. Everybody else gets OpenWebif's own refusal |
| Authentication **on** (OpenWebif's default for HTTPS) | A client that logged in with a system user's password, or a process on the receiver |

🔴 **With authentication off, OpenWebif judges a client by the `X-Forwarded-For` header the client
sends itself**, so its „local network" rule is advisory against anyone who can open the receiver's
port 80. Keep that port off anything you do not trust.

🔴 **The page's own checks protect the page, not the receiver.** It answers only when the address
in the browser is the receiver's IP address, `localhost`, or the receiver's hostname (bare or with
`.local`), which is what stops a hostile web site from reaching it through a name it controls; and
every change must come from the page itself (its `Origin`), carrying the token the page put into
the form. That token is kept in the browser's OpenWebif session, is accepted only from the POST
body - never from the address; the page reads every field from the body alone - and is replaced after every change that took effect, except a save of the menu creator, which the Menu page repeats without a reload; a refused
request leaves it as it was, so the page you are looking at still works. A confirmation step
carries a separate token that is good for exactly one attempt at exactly that action. But while
OpenWebif authentication is off, any web page a household member opens can already switch the
receiver off, or grant `deep_standby_allowed`, through OpenWebif's own endpoints - this page cannot
make the receiver safer than its web interface. If that matters, switch OpenWebif authentication on.

🔴 **The same holds for the broker password.** Whoever OpenWebif admits can point `host` at a
server of their own (or switch TLS off) on this page, and the receiver will then send its stored
broker password there on the next connect. That is no worse than OpenWebif's own `/web/settings`,
which prints the password to anybody it admits - but it is the reason the page is not a safe place
to leave open to people you would not give the broker login to.

The screenshot on the page shows nobody anything new: whoever OpenWebif admits can already take a
fresh picture of the television at any time through OpenWebif's own `/grab`.

**Known limitation.** Because of the address check, the page refuses to answer under a DNS name of
your own or behind a reverse proxy, with a message naming the addresses that work. Opened from
OpenWebif's menu under such a name, the frame still appears and shows that message inside it. This is deliberate and there is no setting for it. A second click on the
menu entry does nothing until another OpenWebif panel has been opened, and reloading OpenWebif does
not reopen the page; both are OpenWebif's behaviour for every entry.

🟡 On an image where the **original** WebInterface is installed instead of OpenWebif, the page is
mounted under that interface's authentication, not OpenWebif's; this has not been measured.

🟡 If the setup screen is open on the television while the page saves, both edit the same settings:
the television's *Cancel* restores what the page saved, and its *Save* writes whatever it shows.

### The Menu page and the menu creator

`http://<receiver-address>/mqttbridge/menu`, linked from the main page. It has the Home Assistant
menu's settings - `menu_allowed`, `menu_hotkey`, `menu_transparency` and the press combo's
`menu_combo_key`, `menu_combo_presses` and `menu_combo_gap_ms` - with the main page's rules, and a status line: whether the menu is on, the broker connection, whether Home
Assistant was heard from, and when the catalogue (below) arrived and how many entities Home
Assistant left out of it.

Below them is the **menu creator**: the same menu you build in the companion integration's options
in Home Assistant, built here. Groups - add, rename, choose an icon, move, remove - and rows: pick an
entity by typing part of its name, its entity id or its area (hidden, configuration and diagnostic
entities are marked), choose its control from those the entity allows, and optionally a label and
an icon, shown as the picture the television draws with its name beside it; move a row up, down or into another group, or remove it. *Save the menu* sends the whole
menu. It needs the companion integration in a version with the menu creator, the menu switched on,
and JavaScript in the browser - the settings above work without it.

- **Home Assistant decides.** The page edits a copy; Home Assistant checks every save with the
  rules of its own menu options and stores the menu, or says what it refused and where. No Home
  Assistant login is on the receiver: the page goes through the broker.
- **A save waits up to ten seconds for Home Assistant's answer.** Without one the page says so and
  offers to reload - the save may still have landed, and the reload shows it.
- **When the menu was changed elsewhere** since the page loaded it - in Home Assistant, or in
  another tab - the save is refused, and the page asks you to reload; your changes stay on the page
  until you do. A save in Home Assistant's own options afterwards, from an older copy, replaces what
  was saved here: Home Assistant is the owner of the menu.
- **Switched on in Home Assistant.** Editing from the receiver is off by default; the companion
  integration's receiver menu options switch it on ("Allow editing from the receiver"). While it is
  off the page says so and shows no editor.
- **Who can use it** once it is on: whoever OpenWebif lets in, like the rest of the page - and
  anyone on the broker can do the same without the page. See [SECURITY.md](../SECURITY.md) before
  you switch it on.

The page is the one page of the plugin that runs a script, `creator.js`, a file in the package,
under a policy that admits no other script and no other site
([ADR-0022](adr/0022-the-menu-creator-page-runs-a-script-every-other-page-stays-script-free.md)).
Everything Home Assistant sends to it is shown as text.

## Provisioning file

For headless installs - and for the companion integration's guided installer - write
`/etc/enigma2/mqttbridge.json` before the plugin starts:

```json
{
  "host": "192.0.2.10",
  "port": 1883,
  "username": "enigma2box",
  "password": "the-broker-password",
  "node_id": "vuuno4kse_005301",
  "friendly_name": "Living room receiver",
  "base_topic": "enigma2",
  "ha_mode": "discovery",
  "publish_keys": true,
  "screenshot": "on zap",
  "deep_standby_allowed": false,
  "softcam_restart_allowed": false,
  "epg_import_allowed": false,
  "uninstall_allowed": false,
  "update_check": false,
  "update_allowed": false,
  "recording_delete_allowed": false
}
```

Only the keys you include are written; the rest keep their defaults. At start-up the plugin
imports them into its configuration and then **deletes the file**, because it holds a password in
clear. The setup screen shows the same values afterwards and is the way to change them later.

A file it could not use at all - every key misspelt, say - is **kept**, with one line in the log
saying so: a typo should cost you a correction, not the only copy of what you wrote.

Write it with `0600` permissions, and be aware it is on flash between the write and the next
start of enigma2:

```sh
scp -O mqttbridge.json root@<box-ip>:/etc/enigma2/mqttbridge.json
ssh root@<box-ip> 'chmod 600 /etc/enigma2/mqttbridge.json && init 4 && sleep 3 && init 3'
```

## Broker access

Give the receiver a dedicated login, never the one Home Assistant itself uses.

If your broker enforces ACLs, limit that login to the box's own topics. For Mosquitto, in the ACL
file, with `<node_id>` replaced by the plugin's node id:

```
user enigma2box
topic readwrite enigma2/<node_id>/#
topic write enigma2mqtt/discovery/<node_id>/#
topic write homeassistant/device/<node_id>/#
topic write homeassistant/device_automation/<node_id>/#
topic read enigma2mqtt/release_index
topic read enigma2mqtt/integration/<node_id>
topic read enigma2mqtt/menu/<node_id>
topic read enigma2mqtt/menu_catalogue/<node_id>
topic read enigma2mqtt/menu_edit_result/<node_id>
# the default discovery prefix, homeassistant; with another, use yours
topic read homeassistant/status
```

The first two `read` lines (since 0.4.0) let the receiver hear the release index and the version of
the companion integration that Home Assistant publishes; without them it learns of releases only
from the internet, and cannot ask Home Assistant for a package. The other four (since 0.5.0) are
the Home Assistant menu's: the menu itself, the menu creator's catalogue and Home Assistant's answers to a
save, and Home Assistant's own status under your discovery prefix (`homeassistant` by default).

Then **verify it by effect**. Subscribe as a privileged user to a topic the box has no business
touching and publish there as the box's user: the message must not arrive. Mosquitto drops an
ACL-denied publish silently and the publishing client sees success either way, so an ACL that is
too tight and one that works look identical from the box.

**The Mosquitto add-on in Home Assistant does not enforce an ACL.** It accepts an `acl_file` in
its customize folder, logs nothing, and never consults it. This was reported against 7.1.0
([home-assistant/addons#4721](https://github.com/home-assistant/addons/issues/4721), closed as
stale without a fix) and is still the case in 7.1.1. On the
add-on, use the dedicated login, run the by-effect check above rather than trusting the file, and
do not count on a topic boundary. If you need the topic boundary, use a broker that enforces ACLs.

Where the ACL is enforced, it is the privacy boundary. Anything able to publish on
`<base>/<node>/cmd/config` can switch on screenshots, key reporting and the CAM and OSCam
telemetry, and then ask for a picture of the television whenever it likes. The companion
integration's options flow is built on exactly that path, so the plugin does not ask the box for
a second confirmation. Without an enforced ACL, any client with a login on the broker can do the
same.

TLS to the broker is optional (`tls`, `ca_file`); client certificates are not supported in v1.

## Home Assistant modes

The `ha_mode` setting decides how Home Assistant learns about the box:

- **`discovery`** (default) - the plugin publishes standard Home Assistant MQTT discovery
  payloads and Home Assistant's own MQTT integration creates the entities. Nothing else to
  install.
- **`integration`** - the plugin publishes only its announcement and leaves entity creation to
  the companion integration [hass-enigma2-mqtt](https://github.com/deltasystems-pl/hass-enigma2-mqtt),
  which adds what discovery cannot express: a native `media_player` with channel browsing, a
  `remote`, a `notify` target for on-screen messages, device triggers for the colour keys and an
  `update` entity. The integration switches the box into this mode itself when you add it.
- **`off`** - no discovery and no announcement. State topics still publish, for openHAB, Node-RED
  or anything else that speaks MQTT.

A mode switch retracts the old discovery payloads before anything new is published, so entities
are never duplicated. The details are in [TOPICS.md](TOPICS.md#cmdha_mode-semantics).

---

# A media player without the custom integration

In `discovery` mode the plugin gives you a switch, a mute switch, a volume number, a channel
select, sensors and buttons - but Home Assistant's MQTT discovery has no way to express a
`media_player`. Home Assistant's own `universal` platform can assemble one out of those entities.

This is the **fallback**. If you can install
[hass-enigma2-mqtt](https://github.com/deltasystems-pl/hass-enigma2-mqtt), use it instead: it
gives a native player with channel browsing, picons, a remote and device triggers, and none of
the plumbing below. The recipe is here for people using another automation system's HA bridge, or
who would rather not add a custom integration.

Save as `config/packages/enigma2_mqtt_player.yaml` and make sure `packages: !include_dir_named
packages` is under `homeassistant:` in your `configuration.yaml`.

Substitute two things throughout: the entity ids, which Home Assistant derives from the
`friendly_name` you set on the box (a box called *Living room receiver* gives
`switch.living_room_receiver_power` and friends - check *Developer tools -> States*), and
`enigma2/vuuno4kse_005301` in the MQTT topics, which is `<base_topic>/<node_id>`.

```yaml
# The universal player does no arithmetic, so volume 0-100 becomes 0.0-1.0 here.
template:
  - sensor:
      - name: "Receiver volume level"
        unique_id: enigma2_mqtt_receiver_volume_level
        state: >-
          {{ (states('number.living_room_receiver_volume') | float(0)) / 100 }}

media_player:
  - platform: universal
    name: "Receiver"
    unique_id: enigma2_mqtt_receiver_universal
    device_class: receiver

    state_template: >-
      {% set power = states('switch.living_room_receiver_power') %}
      {%- if power in ['unknown', 'unavailable'] %}off
      {%- elif power == 'off' %}standby
      {%- else %}playing
      {%- endif %}

    attributes:
      source: sensor.living_room_receiver_channel
      source_list: select.living_room_receiver_channel|options
      volume_level: sensor.receiver_volume_level
      is_volume_muted: switch.living_room_receiver_mute
      media_title: sensor.living_room_receiver_programme
      media_channel: sensor.living_room_receiver_channel
      media_content_id: sensor.living_room_receiver_channel|sref

    commands:
      turn_on:
        action: switch.turn_on
        target: {entity_id: switch.living_room_receiver_power}
      turn_off:
        action: switch.turn_off
        target: {entity_id: switch.living_room_receiver_power}

      volume_set:
        action: number.set_value
        target: {entity_id: number.living_room_receiver_volume}
        data:
          value: "{{ (volume_level * 100) | int }}"
      volume_mute:
        action: "switch.turn_{{ 'on' if is_volume_muted else 'off' }}"
        target: {entity_id: switch.living_room_receiver_mute}

      select_source:
        action: select.select_option
        target: {entity_id: select.living_room_receiver_channel}
        data:
          option: "{{ source }}"

      media_next_track:
        action: mqtt.publish
        data:
          topic: enigma2/vuuno4kse_005301/cmd/key
          payload: KEY_CHANNELUP
          qos: 1
      media_previous_track:
        action: mqtt.publish
        data:
          topic: enigma2/vuuno4kse_005301/cmd/key
          payload: KEY_CHANNELDOWN
          qos: 1

      play_media:
        action: mqtt.publish
        data:
          topic: enigma2/vuuno4kse_005301/cmd/zap
          payload: "{{ media_id }}"
          qos: 1
```

`play_media` takes a service reference as its `media_content_id`; pass the `sref` the channel
sensor carries as an attribute - the attributes both sensors carry are listed in
[TOPICS.md](TOPICS.md#the-attributes-the-sensors-carry), which is why `|sref` above is safe to
rely on. `media_content_type` is ignored.

What this recipe cannot give you, and the integration can: browsing bouquets and channels with
picons, the screenshot as the player's artwork, remote keys as device triggers, on-screen
messages as a `notify` target, and an `update` entity that tells you the box is running an old
plugin.

## Privacy

Before you leave this file: the programme sensor, the key events and the screenshot image all go
into Home Assistant's recorder database by default. Exclude what you would not want to read back
in six months.

**With the companion integration installed**, the remote keys are an `event` entity and the
screenshot is an `image`, so both can be named:

```yaml
recorder:
  exclude:
    entities:
      - event.living_room_receiver_key
      - image.living_room_receiver_screen
```

**In plain `discovery` mode there is no `event.<box>_key` to exclude.** The key topic becomes MQTT
*device triggers*, which are not entities and which the recorder never stores, so the first line
above would name something that does not exist. Turn **`publish_keys` off** on the box instead -
which is the stronger control in either case, because the information then never reaches the
broker at all. The screenshot *is* an entity in discovery mode, so the second line applies; on the
box, `screenshot: off` is its equivalent.

What else to know, and the settings that control it:

- **The `key` and `epg` topics** say what is being pressed and watched. Decide deliberately about
  the programme-title sensor as well as the key events.
- **`zap_history`** (since 0.3.0) names the channels watched recently (up to twenty on the images
  read so far), from every bouquet, retained on the broker - just as `channels` names every
  channel there is. A consumer that hides a bouquet hides it from its own list, not from the
  broker.
- **`stream_clients`** (since 0.5.0) names every device that is being sent a stream by the
  receiver - its address on your network and the channel it is watching, from every bouquet -
  retained on the broker while it watches. There is no setting for it: it is published wherever
  the image has a stream server. Any broker client that can publish this receiver's commands can
  also end one of those streams (`cmd/stream_stop`), as it can change the channel on the
  television.
- **`screenshot`** is a picture of your screen on the broker, retained. Set it to `off` if you do
  not use it. `screenshot_delay` (four seconds by default) is how long the image settles after a
  channel change; rapid zaps reset the delay and stale in-flight captures are discarded.
- **`cam_telemetry`** stays off unless you need conditional-access diagnostics. When on, it
  publishes only the generic CA system, the current service's encryption flag and bounded fresh
  ECM timing - never reader, server, user, card or raw ECM data.
- **`oscam_telemetry`** stays off unless you need OSCam's software and reader/server health. It queries only
  receiver-local, read-only WebIf views and publishes opaque source ids and bounded aggregate
  counts; reader names, addresses, users, card identifiers and WebIf credentials stay on the
  receiver.
- **Retained topics outlive the plugin.** `cmd/reset` retracts everything and is the documented
  step before removing the plugin by hand; `cmd/uninstall` (since 0.3.0) does it for you, in the
  right order. See [INSTALL.md](INSTALL.md#uninstalling).
