# Contributing

Thanks for looking. This project is developed in the open from its first commit: every change -
including the maintainer's - lands through a pull request with CI green, because the pull request
is the public record of *why*.

## The development loop

There is no PC-side Enigma2 sandbox worth the name for Python 3 images, so the loop has two
halves.

**On your machine** - the fast half. The plugin's logic is tested against a stub `enigma`
module, so the parts that build payloads, parse timers, map keys and assemble discovery run under
plain CPython:

```sh
python3 -m pip install -r requirements-dev.txt
ruff check .
pyflakes src tools tests        # skip src/MQTTBridge/_vendor - it is vendored
pytest -q
tools/build-ipk.sh --allow-unreleased
```

A package built this way is a `development` build: it carries its commit, and the receiver shows
it as `0.3.0+g<first seven digits>` rather than as the release with the same number. Only the
release workflow makes `release` builds, and `tools/build-ipk.sh --help` lists the variables a
build without its git checkout is given its commit by. A package built from a source archive - the
companion integration's bundle - is byte-identical to the released one only when it is given all
three: `MQTTBRIDGE_BUILD_COMMIT` (the tag's commit), `MQTTBRIDGE_BUILD_FLAVOUR=release` and
`SOURCE_DATE_EPOCH` (that commit's time). The integration's bundle builder and its CI rebuild must
pass them together.

**On a box** - the half that decides. Nothing counts as working until it has been seen working on
real hardware:

```sh
BOX_PASSWORD=... tools/deploy-to-box.sh <box-ip> --restart
ssh root@<box-ip> 'tail -f /home/root/mqttbridge.log'
mosquitto_sub -h <broker> -v -t 'enigma2/#'
```

The password comes from `BOX_PASSWORD` or from `--password-file <path>`; it is never echoed and
never put on a command line. `--no-build` reuses the IPK already in `dist/`, and
`--provision <file>` installs a JSON configuration as `/etc/enigma2/mqttbridge.json` so a fresh
box comes up already talking to your broker.

`deploy-to-box.sh` refuses to restart the GUI while a recording runs or a timer is due, for the
same reason the plugin refuses `cmd/restart_gui` - and it refuses just as firmly when it cannot
read the receiver's timer list at all, because not knowing is not the same as knowing it is
safe. Two terminals - the log and the subscription - are the whole debugging apparatus; a change
that cannot be demonstrated as a topic that moves is not demonstrated.

### Translations

`src/MQTTBridge/locale/MQTTBridge.pot` is the template and `pl` and `de` are the catalogues;
`tools/build-ipk.sh` compiles the `.mo` files into the package, so only the `.po` files are
committed. A new household-visible string goes through `_()`, into the template, and into both
catalogues - there is a test that fails if it does not.

Verify by effect, never by a return code. `opkg install` reporting success says the files landed,
not that the plugin loaded; a publish that an ACL denies looks identical to one that succeeded.

## The test matrix

CI runs the unit tests on **Python 3.9, 3.12 and 3.14**:

- **3.9** is the floor. OpenPLi 9 sits there, so no syntax above 3.9 - no `match`, no `X | Y`
  annotations at runtime, no `dict | dict`. Ruff is configured with `target-version = "py39"` and
  will tell you.
- **3.12** is what OpenViX 6.6 and OpenATV 7.x run. This is the one the operator's box exercises.
- **3.14** is OpenBH 6.0, and the reason the vendored MQTT client's threading is retested there.

Lint is ruff plus pyflakes. The redundancy is deliberate: a `NameError` in an unexercised branch
of a sibling project broke every polling cycle for three releases, and pyflakes would have caught
it.

**Discovery templates are rendered, never matched.** `tests/test_discovery_templates.py` renders
every `*_tpl` the discovery payloads carry against the bytes the plugin's own publishers produce,
and fails when a template has no rendering test - so a new templated entity needs one. It renders
with `tests/hatemplate.py`: an environment that starts empty and holds only the filters, tests
and globals listed there, with Home Assistant's own `int`, `round` and `timestamp_utc` copied from
the release the companion integration pins. A template that reaches for anything else fails
before it is rendered. That is on purpose: Home Assistant replaces some of Jinja's filters, and a
test that quietly used Jinja's would be coverage of the wrong engine. Adding a filter means
copying Home Assistant's, saying where it came from, and moving it when that pin moves.

## Becoming an image tester

The maintainer has exactly one box - a Vu+ Uno 4K SE on OpenViX. Every other row of the
compatibility matrix is a guess until somebody runs it.

If you have a box on OpenATV, OpenPLi or OpenBH:

1. Find (or open) the call-for-testers issue for your image.
2. Install the current pre-release, configure it against your broker, and work through the
   by-effect checklist in the issue: zap, standby in and out, a one-minute recording, volume from
   the remote and from Home Assistant, the colour keys short and long, every `cmd/*` read back,
   and a last-will drill with the network cable out for a minute.
3. Paste `enigma2/<node>/info` - its `capabilities` list is what tells us which hooks your image
   actually provides - plus anything the log complained about.

That report is what moves a row from *best effort* to *supported*, and it is credited in the
changelog.

Translations work the same way: the source strings are English, Polish is reviewed, and German is
drafted and marked `# needs-review` until a native speaker confirms it.

## Pull requests

- Branch off `main`, one concern per pull request.
- CI must be green: ruff, pyflakes, the tests on all three Python versions, and the IPK build.
- Add a `CHANGELOG.md` entry under `## [Unreleased]` for anything a user would notice.
- Update the docs in the same pull request. `docs/TOPICS.md` is the contract the companion
  integration is written against - a change to a payload is a change to that file, to
  `docs/contract.json`, and to the compatibility table in both READMEs. `contract.json` is the
  contract's names and types as data: `tools/check-contract.py` fails CI when it and TOPICS.md
  disagree, or when a change removes or retypes a topic, a command, an `info` member, a setting or a
  capability name that the last release had, without a new contract major. It does **not** see the
  fields inside a payload - the commonest way to break a consumer - so a change to one is for review
  against TOPICS.md, whose "Contract version" section says what a release may change inside a major
  and how a change of meaning becomes a named exception.
- Describe what you verified and how. „Tested on OpenViX 6.6, zap -> `service` within 1 s" is
  worth more than a paragraph of intent.

## Commit style

Plain, conventional, imperative subject lines under 72 characters; a body when the change needs
one. `fix:`, `feat:`, `docs:`, `refactor:`, `ci:` prefixes are welcome but not enforced.

**No trailers.** No `Co-Authored-By` for tooling, no generated-by footers, no attribution lines
of any kind - in commit messages, pull request bodies, issues, release notes or code comments.

## Decision records

Anything that will be asked about later - a protocol choice, a dependency, a compatibility floor
- goes into `docs/adr/` as an ADR. They are numbered, they have a status, and a decision that is
replaced is marked *superseded* rather than deleted. `docs/adr/README.md` has the template.

## Code of conduct

Participation is covered by the [Contributor Covenant](CODE_OF_CONDUCT.md).
