# The install transaction

Two programs change the plugin on a receiver: the companion Home Assistant integration's installer,
which works over SSH, and - decided in [ADR-0015](adr/0015-signed-self-update.md), merged and not
yet released - the plugin's own update helper. They must never run at the same time, they must
be able to undo each other's unfinished work, and whichever restarts the receiver's interface
must leave the household on the channel it was watching. This file is the contract between the
two: the names on the receiver's disk, the lock and how it goes stale, the snapshot, the marker,
and the restart rule. A change to any name or rule here is a change to both repositories.

What is built and what is not. For the integration there are two states: **released 0.3.1**, which
is what every installer in the field does, and **integration main (unreleased, 0.4.0)**, which is
merged on the integration's `main` branch, has **not yet been run on a receiver**, is accepted on
hardware before the release that carries it, and is taken out again if that fails.

| Part | Integration's SSH installer | Plugin's self-update |
|---|---|---|
| The lock, its owner record and the stale rule (§2) | **released 0.3.1**; the owner record's `id` (§2.2): integration main (unreleased, 0.4.0) | helper written (`updatehelper.py`) |
| The heartbeat (§2.4) | not used | helper written |
| The snapshot, schema 2 (§3) | **released 0.3.1** | helper written, same layout |
| Recovering an abandoned transaction by its id (§3.3) | integration main (unreleased, 0.4.0) | planned |
| Restoring while the interface runs (§3.4) | integration main (unreleased, 0.4.0) | helper written |
| The marker (§4) | not used | helper writes it; the plugin reads it at start |
| The restart rule (§5) | integration main (unreleased, 0.4.0); **released 0.3.1 stops and starts the interface with `init 4` / `init 3` on every path** | helper written for R2 and R3; R1's clean quit is the plugin's |
| R2 as one unit (§5.2) | integration main (unreleased, 0.4.0): one detached script | helper written: inside the helper, which is itself detached |
| Proof that the new plugin started (§6) | **released 0.3.1** (live `online`, `info` with the new version, a new enigma2 pid); unchanged on integration main | helper written |
| Tests against the other program's released code (§2.5) | - | written |
| The transaction directory (§7) | - | helper written, and the plugin's side |

"Helper written" means: the helper and the plugin's side that starts it - `cmd/update`, the
television and the OpenWebif page (`selfupdate.py`), and its half of §4 and §7 - are merged on the
plugin's `main` branch, **not released**, and tested against a fake receiver; the only runs on a
receiver are the hardware spike's (§8), before the merge. The acceptance together with the
integration comes before a release, and §8 lists what the spike left for it.

Paths are the ones on the receiver. `<id>` is twelve lowercase hexadecimal digits
(`secrets.token_hex(6)`), one per transaction; it names the snapshot, the self-update's transaction
directory, the marker's `id`, the lock owner's `id` and `update.transaction.id` in
[TOPICS.md](TOPICS.md#basenodeupdate---added-after-030-unreleased).

---

## 1. Names on the receiver

| Path | Written by | What |
|---|---|---|
| `/home/root/mqttbridge-backups/` | both | The directory everything below lives in. Anything else a person puts here is theirs: neither program deletes a name it did not make |
| `/home/root/mqttbridge-backups/.ha-installer.lock/` | both | **The** lock, a directory (0700). The name is historical - the installer came first - and it is kept, because every released installer looks for exactly this name |
| `/home/root/mqttbridge-backups/ha-installer-<id>/` | the installer | Its snapshot, schema 2 (0700) |
| `/home/root/mqttbridge-backups/self-update-<id>/` | the self-update's helper | Its snapshot, schema 2 (0700) |
| `/home/root/mqttbridge-backups/update-<id>/` | the self-update: the plugin's `cmd/update` makes it, the helper runs from it | The transaction directory (0700), §7: `request.json` (0600), the copy of the helper that runs and the four modules it imports, `status.json`, the downloaded package, and the plugin's words `restart.json`, `withdraw` and `started.json`. Removed when the transaction commits; after any other end it is kept, and the helper keeps its own and the newest other `update-<id>` |
| `/etc/enigma2/mqttbridge-update.json` | the self-update (written by the helper, read and removed by the plugin) | The marker (0600), §4 |
| `/home/root/mqttbridge-backups/drill-r2` | a person, for the hardware acceptance drill | An empty regular file (`touch`). Honoured only by a self-update started by an **acceptance** build, which removes it and goes from installed straight into R2 (§7); every other build ignores it and leaves it where it is, and so does an acceptance build for anything else of that name - a file with something in it, a directory, a link |
| `/etc/enigma2/mqttbridge-update-last.json` | the self-update's helper | The last transaction's end (0600): `id`, `started_by`, `target`, `from`, `started`, `finished`, `result`, `reason`, `error`, and `boot_id` and `uptime` (seconds since boot) at the end. Written at every end by the helper that held the lock, so that the ten-minute limit between transactions and `update.transaction` outlive the transaction directory. Nothing in it decides anything else. `started` and `finished` are the wall clock, which on a receiver without a battery-backed clock starts in 1970 and jumps when NTP answers, so **the ten-minute limit is measured on the boot, and on the wall clock only where it can be believed**: with the same `boot_id` as now, the time since the end is the uptime now minus `uptime`, whatever the wall clock says; with another `boot_id`, the transaction ended before this boot, so at least the uptime now has passed - and while that is under ten minutes, the wall clock may show that more has: the limit does not apply when `finished` is not before 2026-01-01 UTC, the clock now is not before the running build's commit time nor the held release index's `issued`, and the clock now is at least ten minutes past `finished`. Anything else - a clock still in 1970 now or at the end, an end later than now - keeps the refusal, which lasts at most the first ten minutes of a boot; with no `boot_id` (a receiver that does not report one), the limit falls back to `finished` |
| `/etc/enigma2/mqttbridge-index.json` | the plugin (the update check, `updatecheck.py`); the self-update's helper (`updatehelper.py`), when it fetches the index itself - both through `trustfile.keep` | What the receiver has accepted from the signed release index (0600), written whole and renamed into place: the trust memory in the shape [RELEASE-INDEX.md](RELEASE-INDEX.md) gives it, and under `held` the last accepted index and its signature file - see ADR-0015. Written only when what the receiver trusts changes (an index accepted or taken back), never by a check that learned nothing. 🔴 **Every writer** - the plugin today, the self-update's helper once it exists - follows one rule: take `mqttbridge-index.lock` (below), read this file again, judge the candidate index against that fresh read, write the result whole (temporary file, fsync, rename), let go. A judgement made on an earlier read is never written. **Not the lock of §2**: that one is shared with the integration's installer and held for a whole transaction, so a relayed index could not be kept during any install, and a plugin that died holding it would block every installer for thirty minutes. **Kept on purpose** by `cmd/uninstall` and by a downgrade to 0.2.0 or 0.3.x, which never read it; a reflash or a factory reset starts it again |
| `/etc/enigma2/mqttbridge-index.lock` | the plugin; the self-update's helper | The trust file's own lock (0600, empty - a lock file found with another mode is made 0600 by whoever opens it next): an exclusive `flock`, taken without blocking and retried for at most two seconds, held only around read - judge - write of the trust file and never across a fetch. `flock` dies with its holder, so a writer killed while holding it blocks nobody. A writer that cannot get it in time writes nothing and says so (`update` `check_error` `trust_busy`). Left in place; its content means nothing |
| `/etc/enigma2/mqttbridge-check.json` | the plugin (the update check) | The check's bookkeeping (0600): per lineage, when it last asked, what went wrong and whether the origin answered. Written after every check; nothing in it decides what is trusted, and a damaged one is started again. Kept by `cmd/uninstall` like the file above |
| `/etc/enigma2/mqttbridge-state.json` | the plugin | The state file ([TOPICS.md §4](TOPICS.md#the-state-file)). 🔴 Its key `retained_topics` is read by name by every loader since 0.1.0 and is **never renamed**: a downgrade relies on the older plugin finding it |
| `/home/root/mqttbridge.log`, else `/tmp/mqttbridge.log` | the plugin | The plugin's log. The proof of §6 reads which of them the new enigma2 process holds open |
| opkg's lock file | opkg | The `option lock_file` of opkg's configuration; without one, both `/run/opkg.lock` and `/var/lock/opkg.lock` (§2.6) |
| `/tmp/enigma2-mqtt-r2-<id>/` | the installer: integration main (unreleased, 0.4.0) | The directory (0700) the stop-and-restore script of R2 runs from (§5.2): `helper.py`, the script's own copy of the installer's helper; `r2.sh` (0700), the script; `status` (0600), its status lines; `log` (0600), its output from the first line. Removed only after the installer has read `started` from `status` |
| `/usr/lib/enigma2/python/.mqttbridge-staging-<id>/` | the installer: integration main (unreleased, 0.4.0) | Where a restore builds the plugin tree it puts back, before swapping it in (§3.4). Beside `Plugins/`, never inside it. `<id>` is the id of the snapshot being restored |
| `/usr/lib/enigma2/python/.mqttbridge-aside-<id>/` | the installer: integration main (unreleased, 0.4.0) | Where the live plugin tree waits during that swap; removed once a tree is at the live path again |

A name is recognised by an exact match - `ha-installer-[0-9a-f]{12}`, `self-update-[0-9a-f]{12}`,
`update-[0-9a-f]{12}` - never by a prefix alone. The same holds for the names integration main adds:
a restore removes only the staging and set-aside directories of the snapshot it restores, by their
two exact names, and the installer removes only its own transaction's `/tmp/enigma2-mqtt-r2-<id>/`.
Nothing sweeps the directory beside `Plugins/` by a pattern: it holds enigma2's own `Components`,
`Screens` and `Tools`. A restore of a snapshot that is not named `ha-installer-<id>` stages under a
fresh random twelve-digit id, which matches nothing already there.

---

## 2. The lock

### 2.1 Claim and release (released)

- **Claim**: `mkdir` of `.ha-installer.lock` with mode 0700 and no parents. If it exists, it is
  judged by the stale rule (§2.3). A stale lock is reclaimed by **renaming** it to
  `..ha-installer.lock-stale-<pid>-<8 hex>` - two dots: a dot is prefixed to the lock's own name,
  which already starts with one - judging the renamed directory again, and only then
  deleting it and making a fresh one; a lock that turns out to be alive after all is renamed back
  and the claim fails busy. A rename has one winner, so two claimers can never both believe they
  hold the lock.
- **Owner record**: the claimer writes `owner.json` into the lock directory, atomically - a
  temporary file in the same directory, flushed, renamed over.
- **Release**: remove `owner.json`, then `rmdir` the directory. The `rmdir` fails on anything else
  left inside, so the holder removes its own temporary files first. Only a well-formed lock (one
  with `owner.json`) is released.
- **Integration main (unreleased, 0.4.0)**: the claim writes the transaction's `<id>` into the owner
  record, and when it reclaimed a stale lock whose record carries an `id` and no `origin`, it
  reports that id - which is how §3.3 finds the abandoned transaction's snapshot.

### 2.2 The owner record

| Key | Type | Released | Meaning |
|---|---|---|---|
| `pid` | int | yes | The process that wrote the record. 🔴 **Never a liveness test**: the installer's record names the short-lived process that made the claim, which has exited by the time anybody reads it |
| `started` | int | yes | Epoch seconds when the record was written |
| `boot_id` | string | yes | `/proc/sys/kernel/random/boot_id` at that moment, or empty |
| `uptime` | number or `null` | yes | Seconds since boot at that moment, from `/proc/uptime` |
| `origin` | string | no; the self-update's helper writes it (plugin main, unreleased) | Who started the self-update: `mqtt`, `home_assistant`, `screen`, `page` |
| `id` | string | integration main (unreleased, 0.4.0) for the SSH installer; the self-update's helper (plugin main, unreleased) | The transaction's `<id>` |
| `target` | string | no; the self-update's helper writes it (plugin main, unreleased) | The version being installed |

A reader ignores keys it does not know. The helper of released 0.3.1 reads only `boot_id`,
`uptime` and `started`, so `origin`, `id` and `target` change nothing for it. The helper on
integration main reads `id` as well, and only from a record without `origin`.
🔴 **The record is ASCII**: the released helper decodes it as ASCII, and a record it cannot decode falls to rule 1 of §2.3 -
judged by the directory's age, so a live lock with a non-ASCII record looks stale after 30 minutes
however fresh its heartbeat. A record **without** `origin` is the SSH installer's. The plugin does
not report an SSH install on `update.transaction` - it writes no phases to report - and while its
lock is held `cmd/update` and `cmd/uninstall` are refused `busy`.

### 2.3 When a lock is stale (released, and unchanged)

`STALE_LOCK_SECONDS` is **30 minutes**. In this order:

1. `owner.json` cannot be read, or is not JSON: stale once the lock **directory's** modification
   time is more than 30 minutes old - an owner record is written atomically, so a missing one is
   either a claim milliseconds old or a claim that died.
2. The record is not a JSON object: stale.
3. Its `boot_id` differs from this boot's: stale at once - the process that held it no longer
   exists.
4. Same boot, and both uptimes are known: stale when `uptime now - uptime recorded` is more than 30
   minutes. Uptime cannot jump, and many receivers have no battery-backed clock: they boot in 1970
   and jump to the real time when NTP answers, so a wall-clock age could read as decades.
5. Otherwise: stale when `started` is missing or malformed, or more than 30 minutes old by the
   clock.

Every implementation uses this rule, and a later one may only lengthen the threshold: a released
installer in the field keeps judging every lock with 30 minutes.

### 2.4 The heartbeat (helper written)

The self-update can hold the lock longer than an SSH install does: a download, the package
manager, a question on the television, the restart, the proof, and perhaps a rollback. So its
helper keeps the lock visibly alive:

- **Every 60 seconds, from a thread of its own** - a blocking `opkg` must not starve it - the
  helper rewrites `owner.json` with the same `pid`, `boot_id`, `origin`, `id` and `target` and a
  fresh `started` and `uptime`. Rule 4 of §2.3 then measures from the last beat, so every released
  installer sees the lock as held and refuses busy.
- **It writes only a lock it still holds.** Before each rewrite the helper reads `owner.json`; if
  the `id` there is not its own, the lock was taken from it, it writes nothing, and the transaction
  stops touching the receiver and ends with `result: interrupted`.
- **It is the second line, not the first.** The helper bounds itself, so that the lock is held
  at most **1353 s (22.6 minutes)** - under the released 30-minute rule even with no heartbeat at
  all:
  - **The forward path ends at its 15-minute deadline**, measured from the helper's start. The
    wait for the restart ends there, and so does the proof window: a restart that lands late gets
    what is left of the 15 minutes, never 120 s past them (§6). A withdraw or an undo that begins
    on the deadline adds at most **45 s** - one OpenWebif call (5 s) and the restore's wait for
    opkg's lock (40 s, §2.6) - so R2, when it follows, begins at most **945 s** after the start.
  - **R2 takes at most 409 s (6.8 minutes)**, with every wait at its worst: each `init` call
    running into its 30 s timeout, each OpenWebif call into its 5 s, the restore waiting the whole
    40 s for opkg's lock, the interface given its second chance (§5.2), and R3's zap back and
    standby never taking.
  - These are measured, not added up: `tests/test_updatehelper.py` runs the whole transaction on
    a clock that moves only when the helper waits, entering R2 every way the forward path can
    reach it at its deadline (a restart just before it; a withdraw on it; a withdraw after an
    `opkg` that ran up to it; an undo after one that ran past it), with the interface stopping
    at once, late, not at all or quitting after `init 3`, and the new interface appearing early,
    late or never - and fails when any of the three numbers is exceeded. Not included: the time
    the restores take to copy the plugin's files, which was not measured on a receiver.

  The expected worst case is shorter: forward 617 s (index and download 70, verify 1, release
  digest check 10, free space 1, snapshot 30, opkg 120, manifest 10, downgrade retraction 15, the
  television's question 60, waiting for the new interface 180, proof 120), rollback 246 s (record 5,
  stop 30, restore 60, settings write 1, start and wait 120, verify and zap 20, standby 10) - **863 s
  (14.4 min)** in all. Even entered at the latest point, 945 s after the start, that rollback
  ends by about 1191 s (19.9 minutes).

  **What a follower needs.** The companion integration's 21 minutes is enough for every expected
  end, but not for an R2 whose waits run to their bounds after a late restart, which can end at
  22.6 minutes. So a follower that judges a transaction by its `started` stamp - the integration
  following one it asked for, or deciding when a receiver-started transaction is stale - keeps
  following for at least **1353 s plus the clock skew it allows** (60 s: 1413 s, 23.6 minutes),
  and should use **25 minutes**, which leaves room for the copying the measurement leaves out.
  Until then a transaction that has not `finished` may still be running; one still not
  `finished` after that has lost its helper (a `SIGKILL`, or power), and its lock goes stale 30
  minutes after the last heartbeat (§2.3).

### 2.5 The two implementations meeting

| The lock is held by | and arriving is | Result |
|---|---|---|
| a self-update whose heartbeat is fresh | any released installer, or a later one | busy |
| a self-update whose helper died, no beat for more than 30 minutes of uptime | an installer | reclaimed by §2.3 rule 4, and logged |
| an SSH install (no heartbeat) | a self-update | busy, unless stale by the same rule |
| anybody, before a reboot | anybody | reclaimed at once (§2.3 rule 3) |

These are tested against the **released** code, not a description of it:
`tests/released_installer_0_3_1.py` is the stale rule of the integration's `installer_helper.py`
at its tag `v0.3.1`, copied verbatim with its MIT licence, and `tests/test_updatehelper.py`
asserts that a lock whose helper has beaten is not stale for it 31 minutes after the claim, and
that the same lock with no beat is - also while a fake `opkg` blocks the helper, with the
heartbeat running on its own thread.

### 2.6 opkg's own lock (released)

Both programs take **every** lock file opkg could be using, with `lockf` (the lock domain opkg
itself uses; `flock` is a different one), around a snapshot and around a restore, and wait a
bounded time for it. "Is opkg busy?" is answered by taking those locks without waiting and letting
go at once. 🔴 `opkg status` and `opkg list-installed` never take the lock (measured on opkg 0.6.3),
so they cannot tell anybody it is held - only a writer sees it.

---

## 3. The snapshot

### 3.1 Layout, schema 2 (released)

Taken while opkg's lock is held; a snapshot that does not complete is deleted, so a half one can
never be mistaken for a rollback point.

| Name in the snapshot | What |
|---|---|
| `snapshot.json` | `{"schema": 2, "plugin", "package_status", "opkg_info", "provisioning", "settings", "webif_shim", "webif_cache"}` - each a bool saying whether the part below exists. Any other key set, or another schema, is refused |
| `plugin/` | The plugin directory, `/usr/lib/enigma2/python/Plugins/Extensions/MQTTBridge` |
| `package-status` | The package's stanza from opkg's status file |
| `opkg-info/` | The package's files from opkg's info directory |
| `plugin-settings` | Every `config.plugins.mqttbridge.*` line of `/etc/enigma2/settings` - so, 🔴 the broker password too |
| `provisioning` | `/etc/enigma2/mqttbridge.json`, when there is one |
| `webif-shim` | The OpenWebif hook, `.../WebInterface/WebChilds/External/MQTTBridge.py` |
| `webif-cache/` | Its compiled bytecode, in either of the two places images put it |

A restore replaces the package's status stanza, its info files, the plugin directory, the hook and
its bytecode; the settings lines and the provisioning file only when asked to. The order differs
between the two programs, and either is safe to repeat (§3.3): the integration's installer writes
opkg's records first; the self-update's helper puts **the code back first** - the plugin
directory, the hook and its bytecode, which decide what runs at the next start - and opkg's records
and the settings lines after it, each tried whatever became of the other. A full flash or an I/O
error on opkg's status file then leaves the old code in place and only the records naming the new
version, which the helper reports as such (§7), instead of stopping before the tree went back.

### 3.2 Pruning (released)

Each program keeps **two** of its own snapshots - the one of the transaction that is committing, by
name, whatever the clock says, and the newest other one - and deletes only directories that match
its own name exactly (§1). The lock, the other program's snapshots, a transaction directory and
anything a person put there are never candidates.

### 3.3 Which snapshot a rollback uses

Released 0.3.1: each program's rollback restores the snapshot its own transaction took, and
nothing recovers another transaction's.

For the recovery of an interrupted transaction (§5.2): **restoring the same snapshot twice is
safe** - a restore replaces the package's status stanza, its info files, the plugin directory and
the hook wholesale - so the recovery restores the interrupted transaction's snapshot again whenever
that transaction had begun to restore, or cannot say:

- **the self-update** says where it was: its marker and its `status.json` carry the
  phase (§4);
- **the SSH installer** writes no phase record, so an interrupted installer transaction is treated
  as "cannot say", and its snapshot is restored again. **Which** snapshot is not decided by
  modification time - receivers without a battery-backed clock boot in 1970 and jump when NTP
  answers, so "newest" can be wrong. Integration main (unreleased, 0.4.0): the installer writes its
  transaction `<id>` into the lock's `owner.json` (the `id` key of §2.2). An install that reclaims
  such a lock as stale, and finds `ha-installer-<id>` beside it for an id that is not its own,
  restores that snapshot before it takes its own. The interface is running - the install's
  preflight needs it - so this is the restore of §3.4: the files, opkg's metadata and the
  provisioning file, never the settings block.
- If that recovery does not complete - opkg's lock stays held, or the restore fails - the install
  stops before its own snapshot and releases the lock it holds. The abandoned transaction's id is
  then in no lock any more, so no later install recovers it; its snapshot stays as an ordinary one
  and is pruned like one (§3.2).
- A lock the installer released is never a recovery point: an R2 whose end the installer saw -
  including one whose restore failed or was cut off by its bound (§5.2) - releases the lock, and
  its snapshot is then left for a person: the installer's sentence names the backups directory,
  and Home Assistant's log names the exact `ha-installer-<id>`.

Either way the recovery first needs the lock, and the two programs' locks age differently: a dead
self-update's lock is stale 30 minutes after its last heartbeat, but the SSH installer's lock has
no heartbeat and stays fresh for **30 minutes from its claim** - the residual named in §5.2.

### 3.4 Restoring while the interface runs (integration main, unreleased 0.4.0; the self-update's helper, plugin main, unreleased)

When a restart is withdrawn (§5, R1 with a question), the old enigma2 is still the running process
and the old files go back underneath it. On integration main the same restore also serves the
rollback of an install that failed before its restart, and the recovery of §3.3; and every restore
there, R2's included, swaps the plugin directory in as below. Then:

- **Files and opkg metadata only, never the settings block.** The transaction changed no setting,
  and a block written while enigma2 runs is overwritten from memory by the next clean quit - writing
  it would only race the household's own saves.
- **The plugin directory is never half-written.** The old tree is copied into a staging directory,
  then two renames: the live directory aside, the staged one in. `rename` cannot replace a non-empty
  directory, so it is two steps, and for the microseconds between them the plugin directory is
  absent. During a withdraw, a restart that lands there is caught by the pid check below: on
  integration main a new pid after the old files went back goes straight to R2, without a proof.
  The hook, its bytecode and each opkg metadata file are
  single files, each replaced by its own rename. What an earlier, interrupted restore of the same
  snapshot left - its staged or set-aside tree - is removed first, by the two exact names of §1; the
  set-aside tree is removed only once a tree is at the live path again, because until then it is
  the only copy of what was live.
- 🔴 **The staging and set-aside directories are on the same filesystem as the plugin directory**
  (a rename does not cross filesystems) **and outside every directory enigma2 scans for plugins.** A
  complete copy of the plugin where the plugin loader can see it is a second installation of the
  plugin - the same trap as a backup copy inside Home Assistant's `custom_components/`. Integration
  main puts them in `/usr/lib/enigma2/python/`, beside `Plugins/` (§1): the loader lists
  `Plugins/`, then the category directories in it, then the plugin directories in those, so the
  parent of `Plugins/` is never scanned (read from an image's plugin loader, not from every image). A
  test watches every rename of a restore and checks, at each one, that the loader's view holds
  either no plugin directory or one complete tree, and never a second copy. When the snapshot holds
  a plugin tree, the restore compares the two directories' filesystems before it takes opkg's lock
  or changes anything, and refuses when they differ. A snapshot without one - the rollback of a
  first install, which takes the live tree away - skips that check: on an image whose plugin
  directory sits on another filesystem than `/usr/lib/enigma2/python/`, the installer's restore
  replaces opkg's records and then fails at the rename that sets the live tree aside (the
  self-update's helper, which puts the tree back first, would fail there before touching opkg's
  records).
- Then the enigma2 pid is read again - on integration main for up to 60 s, and compared with the
  pid read **before the restart was requested**, never with a later reading, so a restart that
  began after the last look is still a restart. If it changed - somebody answered the question - the
  transaction never reports "withdrawn" for a receiver that restarted. When the old files had been
  put back, the new process may have read either version, and a proof could pass on a plugin whose
  files are gone, so the restart is treated as failed: R2 makes the files and the process agree.
  When they had not been put back (opkg's lock stayed held), the new files are what started, and
  the transaction goes on to the proof, and to R2 if it fails.

---

## 4. The marker (the helper writes it; the plugin reads it)

`/etc/enigma2/mqttbridge-update.json`, 0600, written by the self-update's helper **before the
package manager runs** (phase `installing`), and again at every later phase and at the end. The
first write is required - a helper that cannot write it runs no package manager and ends
`failed`, `internal_error`, with nothing changed; the later ones are best effort, because by then
the files have changed and a full flash must not decide how the transaction ends (the helper
notes a failed write in its record and carries on):

| Key | Meaning |
|---|---|
| `id` | The transaction's `<id>` |
| `from`, `to` | `{"version", "commit"}` of the plugin before and after; `to.commit` is the signed index entry's |
| `boot_id` | This boot's id |
| `deadline` | Uptime in seconds, 15 minutes after the marker was written |
| `phase` | The transaction's phase, as in the `update` topic: `installing`, `restarting`, `proving`, `rolling_back`, `finished` |
| `started_by`, `started` | Who started the transaction, and when (epoch seconds) |
| `result`, `reason`, `error`, `finished` | Only with `phase: finished`: the end, its reason code and sentence, and when |

- A plugin that knows the marker reads it **right after its logging is configured**, before the
  provisioning file is imported and before it checks whether it is switched on - so a new plugin
  that is switched off still confirms that it started.
- It is **ignored** when its boot id differs and no lock with its `id` exists, or when its deadline
  has passed.
- After a power loss, the plugin that starts reports `installed` when it is `to`, `rolled_back`
  when it is `from`, `interrupted` otherwise - and removes the marker. "It is" means the version
  **and** the build commit (a release built again under the same number is another build); a
  `from` without a commit is judged by its version. The same verdict is given in the same boot
  when the helper named by the transaction directory's `helper.pid` is no longer running: the
  plugin that saw it die kept the marker for exactly this (§7).
  A marker still at `installing` is `interrupted` whatever version runs: the package
  manager may have stopped part-way, so the files on disk can be a mix of both versions,
  which no version check can see.
- **A half-installed tree** - a `SIGKILL`, an out-of-memory kill or a power loss while `opkg`
  unpacks - is the residual the marker cannot repair. When the plugin still starts from it, the
  marker says `interrupted`. When it cannot start the plugin at all, nothing on the receiver
  reports anything, and the recovery is the companion integration's **Force plugin reinstall
  (SSH)**, which needs nothing from the plugin - SSH and the package bundled with the integration
  (integration main, unreleased; the integration's ADR-0008, section 8). It needs the shared lock
  like any install: the self-update's lock goes stale 30 minutes after its last heartbeat, or at
  once after the reboot that a power loss is. The snapshot `self-update-<id>` is kept for a person
  to restore from, and pruned like any other.
- 0.2.0 and 0.3.x never read it; the next plugin that knows it discards a stale one by these rules.
- The plugin removes it once it has reported the end - read from the marker, from `status.json`,
  or from the last-transaction record - and when it gives up on a transaction whose helper has
  stopped (§7). So a marker at `phase: finished` lives only from the helper's end until the
  plugin reads it, which on a clean update is seconds: **after the end, the result is in
  `/etc/enigma2/mqttbridge-update-last.json`** (§1), not here. A marker that is absent after an
  end is the design, not a lost write.

---

<a id="5-the-restart-rule-planned-for-040-both-programs"></a>

## 5. The restart rule (integration main, unreleased 0.4.0; the self-update, plugin main, unreleased)

**Why.** The image saves its settings - the channel being watched among them, as
`config.tv.lastservice` - only on a **clean** quit: `StartEnigma.py` runs `stopService()`,
`nav.shutdown()` and `configfile.save()` after the main loop returns. A signal stop never reaches
that code (read from the image's code). Measured on a receiver: after enigma2 was stopped by a
signal, it came back on another channel than the one playing, because the saved channel was older.
OpenWebif's restart (power state 3) opens the image's own `TryQuitMainloop`, which is the clean quit
(read from OpenWebif's code). In released 0.3.1 every restart of the installer - install, and both
steps of its rollback - is `init 4` then `init 3`, with nothing recorded and nothing restored.
Integration main (unreleased, 0.4.0) follows this section: an install or update restarts only by R1,
and `init 4` is left to the rollback that is R2. It has not yet been run on a receiver.

**Two hypotheses this rule rests on.** The integration's code that relies on them is merged on its
main branch without their measurement; both are measured on a receiver in the hardware acceptance
before a release carries the code, and the code is taken out again if that fails. The rule is built
so that a wrong answer costs a zap, not a lost channel:

- **H1 - `init 4` loses unsaved settings like any signal stop.** Expected from the above: init stops
  the respawn entry by signal, so the image's save never runs. **Not measured.** On integration main
  only R2 uses `init 4`, and it writes the recorded channel after the stop either way.
- **H2 - the image reads `config.tv.lastservice` at start**, so a service written into the settings
  while enigma2 is stopped is the one it comes back on. **Observed once**, in the hardware spike's
  drill (§8): the self-update's R2 wrote a channel other than the one the image had saved, and the
  image came up on the written one, so R3's zap back was not needed. One receiver and one image;
  the joint acceptance measures it again for the integration's R2. If it is wrong, R3's zap back
  restores the channel instead.

### 5.1 The three cases

| Case | How | Why the channel survives |
|---|---|---|
| **R1 - restart**: the interface is running and healthy, and only the plugin's files changed | The plugin: `TryQuitMainloop(session, 3, timeout=60, default_yes=False)`, opened with a callback; any call back means the interface is still running (the image's own "no" closes it with `True`), and the plugin writes `withdraw`. The SSH installer (integration main): the preflight refuses while recording, streaming, in standby, or with a timer due within 10 minutes, and is measured again immediately before the restart; then OpenWebif's power state 3, called on the receiver itself, and **at most 60 s** for a new enigma2 pid, read every 2 s | A clean quit runs `configfile.save()` |
| R1, no new pid within 60 s | The image asked a question on the television (timeshift, a background job). The installer **does not force it**: it restores the plugin's files and opkg metadata as in §3.4, reads the pid again, releases the lock and says so - that the receiver asked whether to restart, that the update was withdrawn and the previous plugin is running, and that the question may still be on the television, where either answer is safe. The outcomes are in the table below | Nothing was stopped |
| **R2 - stop**: the interface must not run - a rollback that puts the settings block back, or a forced reinstall into an interface that keeps crashing (integration main, unreleased) | Record the playing service and the standby state (below); `init 4`; wait for enigma2 to stop; do the work; write the recorded service into `config.tv.lastservice` while enigma2 is stopped; `init 3`; wait for a new pid. The SSH installer's form of it, with its bounds, is §5.2 | Hypothesis H2: the image reads `lastservice` when it starts. R3 covers it being wrong |
| **R3 - verify**, after every restart on every path | Compare the playing service and the standby state with the record. A different service: zap back to the recorded one through OpenWebif, once, and compare again. Standby recorded: enter it through OpenWebif (power state 5) | By effect, not by assumption |

- **A restart is judged by the enigma2 pid changing**, never by the exit status of the call that
  asked for it: the quit can reset the HTTP connection that asked. On integration main a new pid
  means one that was not running before the request; the old pid gone with none new at the 60 s
  bound also counts as a restart - a failed one, which the proof then finds. The plugin's helper
  (written) keeps the same rule with its own starting point: the pid in its request - the process
  that asked - must be gone, and a new enigma2 must run that was never seen beside it; every pid
  seen while the one that asked was still running (enigma2 forks children that keep its name
  until they run something else) is never the restart, and is ignored by the proof. The one that
  asked gone before the package manager ran ends the transaction `interrupted`, with nothing
  changed; gone once it had started, before the helper handed the restart to the plugin, the
  process running now may hold either version or a mix, so it goes to R2 and is never proved. A new process after `restarting` - asked for or not - found the
  whole new tree, so it goes to the proof.
- **Once the restart has been requested, nothing the installer cannot see ends in R2** (integration
  main). From the power-state request until a new enigma2 pid is seen, no rollback runs, because the
  image may be keeping the interface up on purpose. A connection that drops while the installer
  waits, or while it withdraws, is connected again and the receiver read again, and a withdraw it
  cut off is repeated - a restore of the same snapshot is safe to repeat (§3.3). New attempts start
  for up to 120 s, and each may take its own 60 s, so the withdraw can last about 180 s at worst.
  A receiver that cannot be read at all, or Home Assistant stopping in that window, leaves the transaction as it is: the new files stay, and the lock stays with the
  transaction's id, for the next install to recover by that id once the lock is stale (§3.3).
- **The record** is taken from OpenWebif's `/api/statusinfo` on the receiver - `currservice_serviceref`
  and `inStandby` - and from the plugin's retained `bouquet` topic where one exists. With nothing
  recorded (the interface was not answering), nothing is restored, and the transaction's record says
  so: there was no channel to keep. On integration main the forward record is taken as late as
  possible, the channel last; R2's record is what the receiver plays when the rollback begins, else
  the record taken before the install's restart, whose bouquet is carried over only when it was
  recorded with the same channel.
- **The zap back happens at most once, and only while the playing service is still the one the
  image started on** - the first service read after the start. A channel the household chose in the
  seconds after the start is never overridden.
- **The channel-list bouquet** (`config.tv.lastroot`) is not what `lastservice` restores, and
  `statusinfo` does not report it. When a plugin that has `cmd/bouquet` is running after the start,
  the side that holds the MQTT session - Home Assistant on the SSH paths, the new plugin itself on
  the MQTT path - restores the recorded `bouquet` with it; otherwise the record says `bouquet: not
  restored`, and channel up and down walk the image's saved list until the household changes it.
- **Standby restore** is a rollback corner: the forward paths refuse to start in standby, so a
  standby record exists only when a rollback began in one. OpenWebif's power state 5 opens the
  image's standby only when the receiver is not already in standby, and with HDMI-CEC enabled the
  image then sends a standby to the television as well.
- The transaction's record carries `restart: clean | stopped`,
  `channel: kept | restored | lost | not recorded`, `bouquet: kept | restored | not restored` and
  `standby: kept | restored | lost | not recorded`. `not recorded` means the record held no channel,
  or no standby state. `lost` for the channel covers an interface that reported no channel within
  60 s of the start, a zap back that did not show within 10 s, and a channel somebody changed after
  the start, which is left alone; `lost` for standby is a standby that did not show within 10 s.
  Integration main writes the record as one line to Home Assistant's log; when the check itself
  fails, it logs a warning instead. On the forward path R3 runs **after the commit** - the lock is
  released first - so a lost connection or Home Assistant stopping while the channel is checked
  cannot roll back an install that proved itself. After R2 it runs once the new pid is seen, before
  the lock is released.
- Other settings the household changed since the last save survive R1 and are lost in R2. R2 is
  used only where the settings block has to be put back anyway.
- Nothing uses `killall enigma2`.
- **Nothing reads the order of open screens.** Some images keep a screen open from session start
  (an invisible one below the info bar, from a broadcaster plugin); the question's outcome comes from
  `TryQuitMainloop`'s own callback, standby from the image's standby flag, and "an update is being
  applied" from the plugin's own state.

**The SSH installer's outcomes around the restart** (integration main, unreleased 0.4.0; the names
are the installer's error codes, each shown to the household as a sentence):

| Outcome | When | The receiver afterwards | The lock |
|---|---|---|---|
| `restart_withdrawn` | No new pid within 60 s, OpenWebif confirmed the request, and the old files are back | The previous plugin runs; nothing was restarted; a question may still be on the television, and either answer is safe | released |
| `restart_unconfirmed` | The same, but OpenWebif never confirmed the request (its answer said so, or was lost), so no question is claimed | as above | released |
| `withdraw_failed` | No new pid within 60 s, and the old files could not be put back - opkg's lock stayed held, or the restore failed | The new files are on disk under the plugin still running (after a failed restore, possibly a mix); a question may still be on the television, and "yes" there starts the new version with nothing checking it | released |
| `restart_unobserved` | After the request the receiver could not be read at all - during the wait, or during the withdraw | As it was left: the new files, or what the withdraw had put back | **kept**, with the transaction's id, for the recovery of §3.3 |
| `rollback_unobserved` | R2's script was started and its end - `started` in its status - was not read within the follow bound | The script carries on by itself on the receiver | **kept**, with the id, and the script's directory kept (§5.2) |

Home Assistant stopping in either of the last two windows leaves the receiver and the lock the
same way, with no sentence shown. When the lock cannot be released after a withdrawal, the outcome
is `rollback_lock_failed` instead.

### 5.2 R2 runs as one unit, and an interruption ends with the interface running (integration main, unreleased 0.4.0; the self-update's helper, plugin main, unreleased)

Between `init 4` and `init 3` the household has no picture. Nothing that can be interrupted from
outside the receiver may sit between the two. What a shell does when it is interrupted was
measured for this section - busybox 1.36.1 `sh` and `dash` on a development machine, not on a
receiver, with a stand-in script in which "`init 3`" writes a marker and "the restore" is a child
process:

| What happened to the script | `trap ... EXIT HUP INT TERM` | the same plus `PIPE` |
|---|---|---|
| The reader of its output went away (a dropped connection, no signal) | the shell died of `SIGPIPE` on its next write and **the trap did not run** | the trap ran |
| `HUP` or `TERM` to the shell while the restore child ran | the trap ran **at once, while the child was still running**; the child finished after the shell had exited | the same |
| `HUP` or `TERM` to the whole process group | the child was killed too - the restore cut off - and then the trap ran | the same |
| After a signal trap that does not end in `exit` | the script **carried on** with its next step, and the `EXIT` trap ran a second time | the same |

Measured again for the integration's fix that made the trap only record a signal - busybox 1.36.1
`sh`, `dash`, and bash 5.2.21 run as `sh` and as bash, on a development machine, not on a
receiver:

| What happened to the script | Observed | So |
|---|---|---|
| `INT` and a second trapped signal (`TERM` or `HUP`) during one foreground command, all trapped | bash, as `sh` or not: a later `wait` for a background child returned 128+n within about 2 ms while the child still ran - even with the signals ignored by then. dash and busybox: not seen | the restore reports its own exit status; `wait` is not used for it |
| A caught signal while busybox runs `sleep` | busybox runs `sleep` itself and ends it at once | the stop wait is measured in time (`/proc/uptime`), not counted in sleeps |
| A signal as the shell enters the fork of the restore (strace syscall injection) | every shell: the handler ran before the pid was kept | the trap only records; the pid is kept under the deferral |

So:

- **The SSH installer starts R2 detached**, as one script in a session of its own, with its output
  going to a file on the receiver from its first line; the installer follows it by reading a status
  file over SSH. A dropped connection or a Home Assistant restart then sends it nothing at all. It
  is **one** script started once: the stop, the restore, the `lastservice` write and the start,
  never several SSH commands. (Released 0.3.1's rollback sends `init 4` and `init 3` as two
  separate commands, which is the case this rule removes; its install restart runs under a trap.)
- **How integration main starts it.** The helper's `r2-start` creates `/tmp/enigma2-mqtt-r2-<id>/`
  (0700), copies itself into it as `helper.py`, writes the script as `r2.sh` (0700), creates
  `status` and `log` (0600 each), and starts `/bin/sh r2.sh` with Python's
  `start_new_session=True` - a new session and process group with no controlling terminal, the
  detachment `setsid` gives and this section once named `start-stop-daemon -S -b` for - with its
  input from `/dev/null` and its output appended to `log`. The script runs on its own copy of the
  helper, so nothing the installer tidies up can take a file from under it.
- **The status lines**, each appended to `status` as its step happens, in this order: `begun <pid>`
  (the script's own pid), `stopping <rc>` (`init 4`'s exit status), `stopped` or `stop_timeout`,
  `restored <rc>`, `written <rc>` or `not_written`, `started <rc>` (`init 3`'s exit status) or
  `started shutdown`, `done`. `restored` carries the exit status the restore wrote itself, or `lost`
  when the restore is gone without writing one (killed - by the watchdog, or by a signal to the
  whole process group). `not_written` means enigma2 was not seen stopped, or no channel was
  recorded. `restored` is always present once `started` is. A signal that arrived before the
  finishing step began ends the script with exit status 1 after `started`, without `done`; one
  during the finishing step is ignored and `done` is written.
- **The bounds.** After `init 4` the script waits up to **30 s** for enigma2 to stop, measured in
  elapsed time from `/proc/uptime` rather than counted in sleeps. If it is still running then, the
  script says `stop_timeout` and puts back the files and opkg's metadata only - no settings block
  and no channel, because the running interface writes its own settings over them on its next
  clean quit - and still runs `init 3`. The restore is bounded at **90 s** by a watchdog that sends
  it `TERM`, and the finishing step sends it `KILL` ten seconds after that, so the picture comes
  back even from a restore that hangs or ignores the watchdog.
- **How the installer follows it.** It reads `status` every 2 s, connecting again after a dropped
  connection, for at most 180 s (the 30 s stop wait, the 90 s restore bound and a 60 s margin).
  Reading `started` ends the following. Unless the status says `stop_timeout` or `started` is not
  0, the installer then waits up to 120 s for a new enigma2 pid and runs R3; in every case it then
  releases the lock, and only after that removes `/tmp/enigma2-mqtt-r2-<id>/` and its uploaded
  helper. `restored` other than 0 is reported as `rollback_failed` (or, for the helper's two opkg
  exit statuses, `rollback_opkg_busy` and `rollback_opkg_overlap`); `restored lost` is
  `rollback_failed`. With `stop_timeout`, "only the plugin's files were put back" is reported only
  for `restored 0`; a failed restore keeps its own verdict with a note that the settings were not
  restored either, except the opkg overlap, whose sentence says the receiver was put back as it
  was - false without the settings - so it becomes `rollback_failed` with the overlap in its
  detail. `started` other than 0, `started shutdown` included - or no new pid within the 120 s -
  is `rollback_restart_failed`. When the restore and the restart both failed, the restore's code
  is the one reported, with a note that the interface did not come back either.
- **The lock is held until the script's end is seen.** From the moment `r2-start` is sent until
  `started` is read, the installer neither releases the lock nor deletes anything of the script's.
  When the following ends without `started` - its bound passed, or Home Assistant stopped - the lock
  stays with the transaction's id and the directory stays (`rollback_unobserved`).
- **A lost answer to `r2-start`.** When the connection drops under that command, its answer says
  nothing about the receiver: Python may still be starting there, before the directory exists. A
  missing `status` then means only "not yet" for a **30 s** grace period, and after it "never
  started" only when the receiver has neither the directory nor a process whose command line names
  it (read from `/proc/*/cmdline`). When `r2-start` did answer, `status` existed before the script
  started, so a missing one means it never started. A script that never started stopped nothing:
  the lock is released and the uploaded helper removed, but a directory is never removed on the
  strength of its absence.
- **The plugin's helper** (plugin main, unreleased) runs R2 inside itself - detached from enigma2
  and from any SSH session - and does not start a child for the restore at all: the restore is a
  function call in the helper's own process, and its result is the call's own, never a wait that
  a signal can cut short. Its handlers for `HUP`, `INT`, `TERM` and `PIPE` only record the signal,
  which R2 does not read, and never run the finishing step: once `init 4` has been sent, the unit
  always runs on - wait for the stop, restore, write `lastservice`, `init 3`, R3 - so a signal can
  neither cut the restore short nor start the interface over a tree that is half put back, or not
  put back at all. (The integration's script takes its restore's result from a file the restore
  writes itself, for the same reason; the helper has no child to wait for, so it has no window
  between starting one and knowing it.) A failed
  restore or `lastservice` write is recorded and the unit carries on, and anything else that
  escapes after `init 4` still meets a `finally` - the helper's form of the script's finishing
  step below: it first runs the steps the unit had not reached, the restore and the `lastservice`
  write, each guarded so that none can keep the next from running, records `rollback: cut short`,
  and then runs `init 3` - so the interface is never started over a tree that could still have
  been put back. Cut short before it had seen enigma2 stop - in `init 4` or in the wait for the
  stop - the `finally` does not take "not seen stopped yet" for "running": it looks at `/proc`
  once more, by process name as the wait does, and with no enigma2 running it puts the settings
  block back and writes the channel as the unit would have; only an interface still running, or
  a look that fails, goes without them. A `/proc` that cannot be listed at all (`EMFILE`,
  `ENOMEM`), or a process whose name cannot be read for any reason but its exit, is such a look:
  R2 reads it as unknown, never as "no enigma2", so it is never taken for the stop, and a
  process is counted as the interface starting again only when a look that did answer during the
  stop says it was not among those still running then, and none of those still runs beside it.
  `init 3` is safe to repeat - starting a runlevel that is already running changes nothing - so
  the helper repeats it wherever the start is in doubt. The helper's own way of running a
  program turns any error in starting it (a `MemoryError` or a failed fork while the child is
  set up) into exit status 127, as it did for a program it could not find, and a program that
  does not answer within 30 s into no status at all; either, or any status but 0, from
  `init 3` sends it once more after a 2 s pause (`record.init_3` lists the statuses). Something
  that is not an `Exception` escaping the call itself meets the `finally`, which counts `init 3`
  as sent only once the call has returned and sends it again otherwise. And when enigma2 was
  seen stopped and nothing started within 120 s of `init 3` - a start that answered 0 and took
  no effect, or one that never got through - `init 3` is sent once more (`record.start`
  `again`) and the interface given another 60 s. R3, after the start, is
  best effort: the rollback it checks is done, so an error in it leaves `channel` and `standby`
  at `unconfirmed` (the error noted as `internal_error`) and never changes the result - which is
  `rolled_back` only when an interface was seen starting on the old files (§7: `not_stopped`,
  `interface_not_started`). Before `init 4` nothing is
  stopped yet, so the record step is best effort - an error there leaves the record taken before
  the restart, noted as `internal_error` - and anything that escapes before the stop is sent
  reaches the helper's last net, which runs R2 again rather than end over the new, unproven code.
  A `SIGKILL` or power between `init 4` and `init 3` is the residual stated below.
- **The trap only records.** Set before `init 4`, the trap on `HUP`, `INT`, `TERM` and `PIPE` does
  nothing but note that a signal arrived. The script goes on exactly as without it: the stop is
  waited for, the restore runs to its end or its limit, the channel is written and the interface
  started. The finishing step runs once, on the main path, with those four signals ignored. The
  `EXIT` trap is there only for an exit nobody planned. Other signals keep their default action;
  nothing on a receiver sends them to a detached session.
- **The restore's result is never read from `wait`.** The restore writes its own exit status to a
  file in the script's directory as its last act (a finished file renamed into place). The
  finishing step waits until that file exists or the restore is gone - `kill -0`, and not a zombie
  in `/proc/<pid>/stat` - and reads the verdict from the file.
- **Order inside**: the settings block is restored first and `lastservice` written after it, each
  by an atomic rename, so a restore can never overwrite the channel; the finishing step writes the
  channel only after the restore has written its exit status or is gone.
- **Not measured**: which signal, if any, dropbear sends a command without a terminal when its
  connection closes. The detached start makes the answer not matter; the trap list covers each
  possibility that was measured.
- **What the trap cannot cover**: a `SIGKILL`, or power, between `init 4` and `init 3`. Power
  reboots the receiver, and a reboot reclaims every lock at once (§2.3 rule 3). A killed script
  leaves the receiver in runlevel 4 **with no picture until somebody switches it off and on
  again**: nothing on the receiver starts the interface by itself, and the next install cannot help,
  because its preflight needs OpenWebif, which runs only while the interface does. The R2 script
  does not keep the lock alive - the installer holds it, with no heartbeat - so the lock goes stale
  30 minutes after its claim, or at once with that power cycle. Integration main (unreleased)
  adds a forced reinstall that recognises runlevel 4 left by an interrupted stop of this
  project's as "ours" and recovers it with `init 3` and R3; in runlevel 4 **without** anything of
  ours it refuses, because somebody stopped the interface on purpose.
- **A shutdown** (sysvinit's rc 0 or rc 6: `TERM` to every process, then `KILL`) cannot be held up
  by the script: `KILL` ends it. Before it sends `init 3`, the script asks `runlevel`; when that
  prints runlevel 0 or 6 as the current level it says `started shutdown` and does not ask for
  runlevel 3 - the next start reads the restored files and the channel. Any other answer,
  including none, starts the interface as before. That `runlevel` works on the receiver is
  measured (it read `4 3` after an `init 4` / `init 3`); that it reads 0 or 6 while rc 0 or rc 6
  runs follows from sysvinit writing its utmp runlevel record on every change and is **not
  measured on a receiver**, nor is the effect of a `telinit 3` that does reach init in the middle
  of a shutdown. A drill on a receiver is outstanding.
- A signal delays the picture by at most the bounds of a run without one - the 30 s stop wait and
  the 90 s restore limit, plus 10 s before a restore that ignores the watchdog is killed - and
  never starts the interface over a tree the restore has not finished with. `started` without
  `restored` is no longer reachable; integration main still reports it as `rollback_failed`.
- A restore cut off part-way - by the 90 s watchdog, or by a signal to the whole process group,
  which the detached start is there to prevent - says `restored lost` (or its own non-zero
  status). The interface is still started, integration main reports `rollback_failed` and
  releases the lock. Restoring the same snapshot again by hand is safe.
- **Tests**, integration main, with stand-ins for `init`, `pidof`, `runlevel` and the restore,
  under the host's `sh`, busybox `sh` where installed, bash run as `sh`, and bash: the connection
  closed between `init 4` and `init 3`; each of `HUP`, `INT`, `TERM`, `PIPE` sent from inside the
  command the script runs at each step (`init 4`, the stop wait, the last look before the stop is
  recorded, the restore, the channel, `init 3`); `INT` with `TERM` or `HUP` during one foreground
  command; a random flood of the four; signals every 0.3 s during the stop wait; the fork of the
  restore hit by an `LD_PRELOAD` shim (dynamically linked shells) and by strace syscall injection
  (every shell, skipped where strace is missing); a shutdown in runlevel 0 and 6; the script's exit
  status; a restore that hangs and one that ignores the watchdog. None of it has run on a
  receiver.

### 5.3 The SSH path has no doors - a bounded residual (R1)

With the R1 restart (integration main, unreleased 0.4.0), the plugin running during an SSH update -
0.2.0, 0.3.x, or any plugin that is not itself driving the transaction - keeps running with the new
files on disk from `opkg` until the restart: a few seconds normally, **up to 60 seconds** when the
image asks a question, plus the time the withdraw takes to put the old files back, which includes
up to 40 s of waiting for opkg's lock (with `init 4` it was a few seconds). A module that plugin
imports for the first time in that window is new code in an old process. This is accepted as
bounded. When the withdraw fails (`withdraw_failed`, §5.1) the bound does not hold: the new files
stay under the running plugin until the next restart, which then starts the new version unchecked.
The self-update path does not have it: from the moment the package manager starts (`installing`),
the plugin answers every command, its setup screen and its OpenWebif page with "an update is being
applied on the receiver" until the transaction ends. §7 says when the doors stay closed past the
end, and with which sentence: a restore that did not complete, a process R2 could not stop, and a
process whose build is not the one on disk.

---

## 6. Proof that the new plugin started

| Path | Proof |
|---|---|
| SSH installer (released 0.3.1, unchanged on integration main) | Within 120 s of the restart: the plugin's `availability` back `online` as a live message (a retained replay does not count) - preceded by a live `offline` only when the plugin was running before the install; then a live `info` with the expected `info.plugin` and `ha_mode: integration`. After that, a new SSH connection must find an enigma2 pid that was not running before the restart. Planned: `info.build.commit` too, when the target publishes one |
| Self-update, a target that knows the marker - one whose signed index entry says `self_update: true` (helper written, and the plugin's half) | The new plugin writes `started.json` (§7), with its version and build commit, into the transaction directory; both must be the signed entry's. Whether the new process also held the log open is recorded beside it, and decides nothing |
| Self-update, a target that does not (0.2.0, 0.3.x - helper written) | The **new** enigma2 pid holds the plugin's log file open (`/proc/<pid>/fd`), polled every 2 s through the whole window, because a log rotation closes the file for a moment. Both released plugins configure logging before anything else at start, whether or not they are switched on and whether or not the broker answers. When neither log path was writable before the restart, those plugins hold no file, and the proof is the OpenWebif hook answering anything but 404 after the pid change. The transaction's record says which proof it used. The helper does not read the log's lines at all: a line is something a broker client can put there, and a timestamp it can forge |

No proof within the window: R2 (§5.1), and the restored plugin puts the reason on `last_error`.
For the self-update the window is 120 s from the restart, and ends earlier when the forward
path's 15-minute deadline comes first (§2.4): a restart that lands late is given what is left.
The reason then says which it was: `not_started` after a whole window, `time_limit` when the
deadline cut it short - the forward path's time ran out, which says nothing against the release.
Both are `rolled_back`, and both sentences say the previous version is back; only `not_started`
says the new one did not start. Every other `time_limit` that ends `rolled_back` - the deadline
passing while the package manager ran, with the interface restarting on its own in the meantime -
says the same as the cut window: the previous version is back. An R2 that ends `failed` keeps its
own sentence, with `time_limit` as its `cause`. `time_limit` has a second sentence, with `failed`, for a forward path that ran out before any
restart: nothing it changed stays, and nothing is said to be back.

---

## 7. The self-update's transaction directory (helper and plugin written, plugin main, unreleased)

The plugin and its helper talk through files in `/home/root/mqttbridge-backups/update-<id>/`
(0700) and nothing else: the helper outlives the plugin's process, and a file is the one thing both
sides of a restart can read. Each file has **one writer**, and every file is written whole and
renamed into place.

| File | Writer | What |
|---|---|---|
| `request.json` (0600) | the plugin, before it starts the helper | `id`; `target` (a release number - `latest` is resolved by the plugin); `sha256` or `null`; `relay` `{"url", "expires"}` or `null`; `started_by`; `downgrade` (true only for a lower version chosen at the television or on the page); `from` `{"version", "commit"}`; `enigma2_pid` (the plugin's own process - the one whose end §5's restart rule waits for); `keys`, `acceptance` and `origin` - the index keys, lineage and origin of the build that asks, so the helper judges by what the running build trusts; `contract`; `integration` (`enigma2mqtt/integration/<node>` as read, or `null`) and `integration_mode`. A request the helper cannot read ends as `failed`, reason `bad_request` |
| `helper.py`, `trust.py`, `ed25519.py`, `trustfile.py`, `netfetch.py` | the plugin | The helper and the four standard-library modules it imports, copied from the plugin directory, so the package manager replacing that directory takes nothing from under it |
| `status.json` (0600) | the helper that holds the lock | `id`, `started_by`, `target`, `from`, `phase`, `started`, `finished`, `result`, `reason`, `error` - the shape of `update.transaction` - a `heartbeat` stamp, `restart` once the plugin asked, and at the end `record`: which proof passed (`marker`, `log_fd`, `webif_hook` or `none`), `restart` (`clean` or `stopped`), `rollback: cut short` when something no handler expects cut R2 short after `init 4` and its `finally` finished the steps, `init_3` (every status of R2's `init 3` calls when one did not answer 0: 127 for a program that could not be started, `null` for one that did not answer in time), `start: again` when `init 3` was sent once more because nothing started after the stop, `stop` (`seen` when R2 saw no enigma2 running after its `init 4`, else `not seen`), `unstopped` (when the stop was not seen: the pids R2 could not stop, from its last look at `/proc` that answered - a plugin compares its own pid with them), `channel` and `standby` (`unconfirmed` when R3 itself failed, and `channel` `unconfirmed` when the interface was not restarted and R3 did not run), `bouquet`, `restore` (`done`; `partial: <what is missing>` when the code is back and opkg's records or the settings block are not; `failed: <error>` when the code is not back; `interrupted`), `cause` (the reason the end had before `restore_failed`, `restore_incomplete`, `not_stopped` or `interface_not_started` replaced it), `lastservice`, `digest` (`matched`, `unavailable` or `not_checked`), `index_verdict` and `index_kept` when the helper fetched the index, `origin` (`unreachable` when a fetch from the release origin got no answer at all, `reachable` when the package download from it got any answer; absent when the package came from a relay address - the plugin keeps `unreachable` as `update.origin`, TOPICS.md §2), `interface` - `not started` when no enigma2 came back after R2's stop and `init 3`, `not restarted` when the stop was never seen, no start was counted after `init 3` - no enigma2 other than the ones still running appeared, or one appeared while one of them still ran - and something still runs (or `/proc` could not say) - `marker` when a marker write after the package manager failed, and `internal_error` for an error nothing expected. A second helper started for the same `id` that finds the lock held by its own `id` - or cannot read the owner yet - writes nothing here; one refused by another transaction's lock writes its `busy` |
| `<filename>.ipk` | the helper | The package, after its size and sha256 matched the signed entry |
| `helper.pid` | `start-stop-daemon -m` | The helper's pid, written for the process that became the helper. BusyBox's `start-stop-daemon -b` forks twice, so the helper runs in a new session and process group - not enigma2's, with init as its parent - but is not their leader: the leader is the intermediate child, and the helper's pid is that one's plus one on the receiver it was accepted on. Nothing depends on leadership - no group signal, no `getsid` - and `-m` records the helper's own pid. 🔴 `-p` is what makes the launch work at all: without a pid file busybox's `start-stop-daemon -S -x /usr/bin/python3` matches **any** running python3 and starts nothing. The plugin also reads it to tell a helper that stopped (`/proc/<pid>` gone, or its command line no longer holding this directory's `helper.py` as one whole argument - the integration's `installer_helper.py`, or another transaction's helper, on a pid used again is not it) from one that is still at work: a helper killed outright never writes `finished`, and `status.json`'s stamp moves only with a phase |
| `restart.json` | the plugin | It has asked the image to restart (R1); `{"pid"}`. From here the helper waits 180 s for a new enigma2, or until the forward path's 15-minute deadline when that comes first (§2.4) |
| `withdraw` | the plugin | Put the old files back: `{"reason": "question"}` - the image's question was answered "no" or timed out - or `{"reason": "retraction"}` - a downgrade's retraction was not acknowledged within 15 s - or `{"reason": "standby"}`, `{"reason": "recording"}`, `{"reason": "epg_import"}` - asked again right before the restart, that guard now refuses (a recording due within ten minutes, or a receiver that will not say, is `recording`). Anything else, an empty file included, is read as `question` |
| `started.json` | the new plugin, at its start | `{"version", "commit", "pid"}` - the tier-1 proof; both must be the target's signed ones |

**The helper's reason codes** (with `result: failed` unless named): `busy`, `bad_request`,
`unreachable` (no index could be fetched and none is kept), the rule's own `unknown_version`,
`withdrawn`, `below_floor`, `incompatible`, `depends`, `downgrade`, `checksum`, `relay`, then
`download`, `bad_package` (size, sha256, the `ar` layout, the control file, anything in the
payload other than a directory or a regular file - a link, a device, a pipe - a path outside the
plugin, or the release page's digest), `no_space`, `opkg_busy`, `snapshot_failed`, `opkg_failed`,
`manifest`, `time_limit`; `question`, `retraction`, `standby`, `recording` and `epg_import`
with `withdrawn_before_restart`; `not_started` with `rolled_back`, and `time_limit` with
`rolled_back` when the forward deadline cut the proof window short (§6); `interrupted` (a
signal, the lock taken, or the interface that asked restarting before the package manager ran)
with `interrupted`, and with `rolled_back` when the interface
restarted after the package manager started and before `restarting`; `internal_error` (an error nothing expected, the package
or the first marker not written) with `failed`, or with `rolled_back` when it came after the
restart and R2 put the old version back; `drill` with `rolled_back`, only for an acceptance
build (below); `restore_failed` and `restore_incomplete` with `failed`, below; `not_stopped` and
`interface_not_started` with `failed`, below. After the package
manager ran, `installed` comes only after the proof, and every other result only once the old
files are back - with two exceptions that say so. The first is a restore that did not complete,
which replaces the end's reason (the first one is kept as `record.cause`) and whose sentence names
the integration's **Force plugin reinstall (SSH)**, the repair for both: `restore_failed`
(`record.restore` `failed: ...`) when the old code could not be put back - the new files, or a
mix, are on disk, and opkg's records still name the new version, because the helper puts the code
back first (§3.1) - and `restore_incomplete` (`record.restore` `partial: ...`) when the old code
is back but opkg's records or the settings block are not: a full flash, or an I/O error on opkg's
status file. After either, the plugin keeps its doors closed (below), and a withdraw or an
undo still goes to R2 when the interface restarted meanwhile. The second is `interrupted` because
the lock was taken, after which the helper touches nothing of the receiver.

**R2's end says what runs, not only what is on disk.** `rolled_back` means the old files are back
**and** an enigma2 that R2 had not seen before started on them, **with every process R2 could not
stop gone**. With the files back (`record.restore` `done`) and no such start, R2 ends `failed`, the
reason it had kept as `record.cause`:

- `not_stopped` (`record.stop` `not seen`, `record.interface` `not restarted`): `init 4` had no
  effect that R2 could see within its 30 s, and at the end something still runs - or `/proc` could
  not be read to say it does not. Either `init 3` started nothing, because the runlevel never left,
  or it started a second enigma2 beside the one R2 could not stop; that second process is never
  counted as the start while one of those still runs. `record.unstopped` lists the pids R2 could
  not stop, from its last look that answered. That process - the one started by the forward
  restart, holding the new code, or a mix - runs on over the previous version's files until the
  interface restarts. The settings block and the channel were left alone, because a running
  interface writes its own settings over them when it quits.
- `interface_not_started` (`record.interface` `not started`): the old files went back and no
  enigma2 runs at the end - after the stop was seen (`record.stop` `seen`), or after the process
  R2 could not stop quit by itself (`record.stop` `not seen`, `record.unstopped` set) - although
  `init 3` was sent once more (`record.start` `again`) and given another 60 s. Nothing runs when
  the helper ends.

A restore that did not complete keeps its own reason (`restore_failed`, `restore_incomplete`)
over both. When the stop was not seen but the processes R2 could not stop had all gone and an
enigma2 other than them appeared after `init 3` - the old process quit late and the start took, at
once or after the second `init 3` - the end is `rolled_back`, with `record.stop` `not seen` saying
that the settings block and the channel were not put back.

**The plugin's side.** `cmd/update` runs every refusal of TOPICS.md §2 before anything changes, makes
this directory, writes `request.json`, copies the files and runs
`/sbin/start-stop-daemon -S -b -m -p <dir>/helper.pid -x /usr/bin/python3 -- <dir>/helper.py <id>`
through `eConsoleAppContainer`. It reads `status.json` once a second into `update.transaction`. A
launch that exits non-zero, or no `status.json` within 60 s, is `failed` (`internal_error`) and the
directory is removed. At `installing` it closes its doors: the package manager is replacing the
files under it. They stay closed through `rolling_back` (the acceptance drill goes there
straight from `installing`) until the end, which reopens them with a fresh session - except a
`failed` end whose `record.restore` is not `done` - `restore_failed` or `restore_incomplete`:
the files under the running process may then be the new release's or a mix, or the old code
with opkg's records naming the new version, a fresh session would import them, so the doors
stay closed and every command, the page and the setup screen say to install the plugin again
(the companion integration's forced reinstall over SSH). `last_error` carries the helper's
sentence as it is, since it names that repair already. That is decided from the end's record alone - the
helper tries a restore only once the package manager has run - so an end the plugin reads
without having seen `installing` (the whole failure between two reads) closes the doors then.
After `not_stopped` they stay closed in the process R2 could not stop, and after any end in a
process whose build is not the one on disk - see "What the plugin does with these ends" below.
The request's `acceptance`, `keys` and `origin` are
the running build's own, never anything a command, the page or the integration's topic says. At `restarting` it asks the standby, recording and EPG-import guards again and,
when one holds, writes `withdraw` with that reason instead of asking; otherwise it retracts first
for a downgrade, writes `restart.json` and asks the image to restart. When the helper stops
without an end, the plugin reports `interrupted` itself - reading `status.json` once more first,
so a helper that wrote its end and exited is reported as it ended - and leaves the lock to go
stale; from `installing` on it also keeps the marker, so the next start judges the transaction by
the build that runs. A helper of its own transaction that stops from `installing` on is treated
like a restore that failed: a helper killed outright leaves its package manager running as an
orphan that may still be writing the files, so the doors stay closed (or close) and say to
install the plugin again. The one exception is `installing` with no marker of this transaction:
the helper writes the marker before it runs the package manager and runs nothing without it, so
nothing changed, and the doors reopen with a fresh session. A plugin that only follows the
transaction - the one its restart started - closes its doors at `rolling_back`: R2 is putting the
previous version's files back under it, for as long as three minutes when the interface does not
stop. The end opens them again on the same conditions as for the process that asked. A helper
that stops during `rolling_back`, a followed transaction that passes the marker's deadline while
they are closed, and one whose status, marker and last-transaction record all go missing while
they are closed, are judged as a helper that stopped in the phase last seen: the reinstall
sentence for the build the forward restart started, since the files went back under it; for a
process R2 itself started - one that began following at `rolling_back`, after the files went
back - the build rule alone, so on its own build it opens.
Until the lock is stale `cmd/update` is refused `busy` with "the previous
update stopped without finishing; a new one is possible in about <n> minutes, when its lock on
the receiver expires" - said only for a self-update's record of this boot whose helper is
provably gone; the lock is not taken back. While a transaction runs or the lock is held,
`cmd/uninstall` is refused `busy`, and `cmd/update` while an uninstall runs. A followed
transaction past the marker's deadline is let go - with its doors closed, as a helper that
stopped. The plugin that starts after a restart writes
`started.json` - never the process whose pid is the request's `enigma2_pid` - and follows the
marker to the end.

**What the plugin does with these ends.** Neither end may be read as "the previous version is
running":

- After `not_stopped`, a plugin first compares its own pid - the enigma2 process it runs in,
  `os.getpid()` - with `record.unstopped`.
  - **Listed**: it is the process R2 could not stop, and its files changed under it: they are the
    previous version's now. That is the case the plugin's doors exist for: a fresh session would
    import the previous version's modules into a process holding the new one's. So it keeps the
    doors closed - closing them if no poll had, which is the case for a process that only
    followed the transaction - never reloads, and never reports itself as the previous version.
    The repair is a restart of the interface, not a reinstall: the files and opkg's records agree
    on the previous version, so the sentence says to restart the receiver's interface, and
    `restart_gui` stays possible through the closed doors, since it is exactly that repair: over
    MQTT and from the page - which offers it under the sentence - with its own guards (a
    recording, an EPG import, a job that holds the quit), while every other command, the settings
    and the setup screen answer the sentence. The image's own restart from the television was
    never the plugin's to refuse. `last_error` carries the helper's sentence as it is. After the
    restart the previous version starts and reads the end from the last-transaction record like
    any other. The process that asked is held too when it is listed, although it runs `from`
    over `from`'s files again: it survived the quit R1 asked for and R2's `init 4`, so its quit
    hung somewhere, and a process in that state is not one to open a fresh session in. The
    restart the sentence asks for ends it, and costs nothing that is not already lost.
  - **Not listed** (a process started since - by R2's own `init 3` beside the one it could not
    stop, after the repair or a reboot): it started on the files on disk, which agree with opkg's
    records, so it reports the end on `last_error` and opens as after any end - when the build
    rule below agrees.
  - **No list** (no look at `/proc` answered): the pid proves nothing either way, and the version
    decides, as for a marker that outlived its helper. A process that runs the transaction's
    `from` - from the marker, else this transaction's `request.json`, else the status file's
    bare number - runs the files that were put back and opens, when the build rule agrees; any
    other, and one nothing shows to run `from`, is held as if it were listed.
- After `interface_not_started`, no plugin is running to read it. Whatever starts the interface
  next starts the previous version, which reads the finished marker at its start, reports the end
  on `last_error` and opens as after any end: its files and its process agree, so nothing stays
  closed. Home Assistant says the sentence and does not announce a rollback that runs.
- So "`record.restore` is `done`" alone does not mean nothing is stuck: a plugin that opens its
  doors on every such end reopens them over changed files after `not_stopped`. The check is the
  reason, or `record.interface` `not restarted`, together with the plugin's own pid in
  `record.unstopped` - in the process that asked and in one that follows alike - and, after
  every end, the build rule below. With a restore that did not complete as well, the reinstall
  stays the repair and the doors say so.

**The build rule: the files decide last.** The pid list, the reason and `from` are the helper's and
the request's account, and a look at `/proc` that went wrong - one that could not open a process's
files and took that for no process - or a `from` built without a commit, which matches any build of
its number, can make them say "this process runs the files" when it does not. So before a process
that ran through a transaction - the one that asked, or one that followed it - opens its doors again
or reloads, after **any** end and whatever the reason, the result or `record.unstopped` say, it
compares the build it loaded at its start (`info.build`: the commit, its time, `dirty` and the
flavour) with the build id on disk (`buildinfo.py`, read as literals, never imported). When they
differ, it runs other code than the files underneath it, and it is held as a listed process is - the
doors closed, no reload, `restart_gui` let through - with a sentence of its own, since nothing needs
to have been undone (a failed launch, a withdrawn update, an `installed` end): "the receiver's
interface runs a different build of the plugin than the one now installed; restart the receiver's
interface". The rollback's restart sentence stays for `not_stopped`, where the pid or the version
holds the process. When the old files were not all put back as well (`restore_failed`,
`restore_incomplete`, or a helper that stopped during `rolling_back`), the reinstall sentence stays,
and a restart is not let through: it would start a mix. The pid and the version remain the cheaper
first signal and still hold a process by themselves; they can no longer open one whose build is not
the one on disk.

A build id on disk that cannot be read is not the running build. A process that loaded one at its
start and finds none now - the file missing, unreadable, or not what the builder writes - had its
files changed under it, or damaged, and is held with the build rule's sentence: the conservative
side, since the restart runs whatever is on disk, and a process that starts is never held. Only a
copy nobody built, which never had a build id, finding none either cannot tell, and the pid list and
the version decide alone. A process that starts loads its build id from the files it started on, so
at a start there is nothing to compare: the rule is for a process that was already running when the
files changed.

**What it re-judges**: the index is read again - fetched from the origin only when the request
carries no relay address (an install Home Assistant drives needs no internet on the receiver and
asks for none), otherwise the index the receiver already holds - and every rule of the index is
applied again, whatever the plugin already checked. An index fetched from the origin that the
rule accepts but that cannot be kept (`index_verdict` `write_failed` or `trust_busy`,
`index_kept: false`) still decides: it is the newest the receiver has seen, and the one kept
earlier may offer a version it has since withdrawn. `--force-downgrade` is added only when the
target is lower than the version installed and the television or the page started it - never
because the request says `downgrade`. The relay address is judged again as well, before anything
is fetched: `http` or `https`, a host name or IPv4 address without a user part, a port if any,
exactly the path `/api/enigma2_mqtt/relay/` and a 43-character URL-safe token, nothing after it,
and an integer `expires` that has not passed by the receiver's clock - otherwise `relay`. It is
one function, `updatehelper.relay_ok`, which the plugin also asks before it writes the request -
for a `cmd/update` that carries the address, and for Home Assistant's answer to the receiver's own
`relay_request` (TOPICS.md, `cmd/update`), which is where the address of an install started at
the television or on the page comes from when the receiver has no internet. The
relay is **IPv4 only**, on both sides: the integration binds each relay address to the receiver's
IPv4 address, offers one only to a receiver that reported such an address, and names its own IPv4
address on the receiver's subnet, else its internal URL - so a host written as an IPv6 literal
(an internal URL configured that way) is refused as `relay` here, before a download the
integration's binding would refuse anyway. That is a rule about the address as written, not about
the one connected to: a host name may resolve to any address, IPv6 included. The
host is not checked against anything else: a broker client can name any host, and what it serves is
verified against the signed entry before `opkg` sees it. A receiver whose clock still stands in
1970 cannot tell an expired address from a fresh one; Home Assistant's own expiry of the token
bounds that case.

**The acceptance drill's hook.** The hardware acceptance has to prove R2's stop, restore and
`lastservice` write on a receiver in one restart, without a forward restart and a failed proof
first. The planned hardware acceptance proves R2 with a deliberately broken build; this hook is
an **acceptance-only addition** to it, for the same proof without building one, and it
exists only in the `acceptance` flavour. So a helper whose request says `acceptance: true` - which
only an `acceptance`-flavour build writes; release and development builds always write `false` -
looks, once the package is installed and verified and before it hands the restart to the plugin,
for the empty regular file `/home/root/mqttbridge-backups/drill-r2`. When it is there, the helper
removes it and goes straight into R2: the result is `rolled_back`, reason `drill`, and the record
says `drill: r2`. Only an empty regular file counts: a link is never followed, and a directory or
a file with something in it is ignored and left where it is. Any other build ignores the file and
leaves it in place, and it changes nothing else: an acceptance build without the file runs the
transaction as any other.

---

## 8. Hardware spike (2026-09)

The self-update ran on a receiver once before its merge: a Vu+ Uno 4K SE with OpenViX 6.6
(Python 3.12, BusyBox 1.36.1), with acceptance builds signed by throwaway test keys, the test
index delivered over MQTT and the package served by a relay running on the receiver itself. The
builds were made from the self-update's branches as they stood before their last pre-merge
follow-up, so what that follow-up added - `update.transaction`'s `reason` and the sentences for a
`time_limit` rollback - and what changed after the merge have not run on a receiver. What it
showed:

- A self-update over MQTT to a build of the same version and another commit ended `installed`:
  the helper survived the interface restart, the new start confirmed itself (tier 1, §6) and was
  also seen holding the plugin log (tier 2), the channel was kept and saved, and no question was
  asked. 47 s end to end, under 2 s without an interface process.
- A package with one changed byte was refused (`failed`, `bad_package`) with nothing changed on
  the receiver.
- With a client streaming from the receiver, the image asked before restarting (default No);
  nobody answered, the question timed out as "no" after 60 s, and the update was withdrawn
  (`withdrawn_before_restart`, `question`) with the files put back and no restart.
- The acceptance drill (§7) sent an update straight into R2: enigma2 stopped, the files restored,
  `lastservice` written while it was stopped, the interface started once; the image came up on
  the written service (`rolled_back`, `drill`, channel kept) although it had saved another one -
  hypothesis H2 of §5, observed. There were never two interface processes at once.
- BusyBox's `start-stop-daemon -b` forks twice: the helper runs in a new session and process
  group, not as its leader (§7, `helper.pid`); nothing in the plugin depends on leadership.
- The helper's command line carries the script path as one argument followed by the transaction
  id - the shape the plugin's check of `helper.pid` reads (§7).
- The marker is gone once the plugin has reported the end, as §4 says; the end is read from
  `mqttbridge-update-last.json`.

Not covered by this run, and left for the joint acceptance with the integration: the checks on
the television screen, the integration-side relay (Home Assistant's part was played by scripts),
a power loss, the rollback of a release that does not start (`not_started`, and `time_limit`),
and a downgrade. The owner record's heartbeat was seen advancing once, 60 s after the record was
written, while the question waited, but no beat fell inside the few seconds of a clean restart.
H1 of §5 was not measured.
